<?php

require 'config/db.php';


// ==========================================================
// AUTHENTICATION
// ==========================================================

if (!isset($_SESSION['user'])) {

    header("Location: login.php");

    exit;
}


// ==========================================================
// PAGINATION
// ==========================================================

$recordsPerPage = 3;


// Get current page
$page = isset($_GET['page'])
    ? (int) $_GET['page']
    : 1;


// Prevent invalid page
if ($page < 1) {
    $page = 1;
}


// ==========================================================
// COUNT ACTIVE RESOURCES
// ==========================================================

$countStmt = $connect->query("
    SELECT COUNT(*)
    FROM resources
    WHERE status = 'Active'
");

$totalResources = (int) $countStmt->fetchColumn();


// ==========================================================
// TOTAL PAGES
// ==========================================================

$totalPages = max(
    1,
    (int) ceil(
        $totalResources / $recordsPerPage
    )
);


// Prevent page greater than total pages
if ($page > $totalPages) {

    $page = $totalPages;
}


// ==========================================================
// OFFSET
// ==========================================================

$offset = (
    $page - 1
) * $recordsPerPage;


// ==========================================================
// FETCH ACTIVE RESOURCES
// ==========================================================

$stmt = $connect->prepare("
    SELECT *
    FROM resources
    WHERE status = 'Active'
    ORDER BY resource_id DESC
    LIMIT :limit OFFSET :offset
");

$stmt->bindValue(
    ':limit',
    $recordsPerPage,
    PDO::PARAM_INT
);

$stmt->bindValue(
    ':offset',
    $offset,
    PDO::PARAM_INT
);

$stmt->execute();

$resources = $stmt->fetchAll(PDO::FETCH_ASSOC);


// ==========================================================
// SHOWING RANGE
// ==========================================================

if ($totalResources > 0) {

    $showingFrom = $offset + 1;

    $showingTo = min(
        $offset + $recordsPerPage,
        $totalResources
    );
} else {

    $showingFrom = 0;

    $showingTo = 0;
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <title>Resource Booking : Nkanyiso Consulting</title>

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1">

    <?php include 'includes/header.php'; ?>


    <style>
        /* =====================================================
           RESOURCE CARDS
        ====================================================== */

        .resource-card .card {

            transition: all 0.2s ease;

        }


        .resource-card .card:hover {

            transform: translateY(-3px);

            box-shadow:
                0 0.5rem 1rem rgba(0, 0, 0, 0.15) !important;

        }


        /* =====================================================
           SEARCH
        ====================================================== */

        .resource-search {

            width: 100%;

            max-width: 400px;

        }


        /*
         * IMPORTANT:
         * Do NOT use display:flex here.
         * Bootstrap .input-group already handles the layout.
         */

        .resource-search .form-control {

            min-width: 0;

        }


        .resource-search .btn {

            flex-shrink: 0;

            white-space: nowrap;

        }


        /* =====================================================
           PAGINATION
        ====================================================== */

        .pagination {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 4px;
            margin-bottom: 0;
            padding: 0;
        }

        .pagination .page-item {
            margin: 0;
        }

        .pagination .page-link {
            display: flex;
            align-items: center;
            justify-content: center;
            min-width: 32px;
            height: 32px;
            padding: 0 9px;
            font-size: 13px;
            font-weight: 500;
            color: #0d6efd;
            background-color: #ffffff;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            text-decoration: none;
            transition: all 0.2s ease;
        }

        .pagination .page-link:hover {
            color: #ffffff;
            background-color: #0d6efd;
            border-color: #0d6efd;
        }

        .pagination .page-item.active .page-link {
            color: #ffffff !important;
            background-color: #0d6efd !important;
            border-color: #0d6efd !important;
        }

        .pagination .page-item.disabled .page-link {
            color: #adb5bd;
            background-color: #f8f9fa;
            border-color: #dee2e6;
            cursor: not-allowed;
        }

        .pagination .page-link:focus {
            box-shadow: none;
            outline: none;
        }


        /* =====================================================
           FOOTER ALIGNMENT
        ====================================================== */

        .page-footer {

            width: 100%;

        }


        /* =====================================================
           MOBILE
        ====================================================== */

        @media (max-width: 576px) {

            .resource-header {

                flex-direction: column !important;

                align-items: stretch !important;

                gap: 15px;

            }


            /*
             * Keep the entire search bar together.
             */

            .resource-search {

                width: 100% !important;

                max-width: 100% !important;

            }


            /*
             * Allow the input to shrink.
             */

            .resource-search .form-control {

                min-width: 0 !important;

            }


            /*
             * Keep buttons attached to the input.
             */

            .resource-search .btn {

                flex: 0 0 auto;

                min-width: 44px;

                padding-left: 10px;

                padding-right: 10px;

            }


            /*
             * Resource cards.
             */

            .resource-card {

                width: 100%;

            }


            /*
             * Pagination.
             */

            .pagination-section {

                flex-direction: column !important;

                align-items: flex-start !important;

                gap: 15px;

            }


            /*
             * Allow pagination to fit small screens.
             */

            .pagination-section nav {

                max-width: 100%;

                overflow-x: auto;

            }


            .pagination {
                flex-wrap: nowrap;
                justify-content: center;
                gap: 3px;
                width: 100%;
            }

            .pagination .page-link {
                min-width: 29px;
                height: 29px;
                padding: 0 7px;
                font-size: 12px;
            }

        }


        /* =====================================================
           VERY SMALL PHONES
        ====================================================== */

        @media (max-width: 360px) {

            .resource-search .btn {

                min-width: 40px;

                padding-left: 8px;

                padding-right: 8px;

            }


            .resource-search .form-control {

                font-size: 14px;

            }

        }


        /* =====================================================
           MODAL
        ====================================================== */

        /*
         * Prevent the page from being blurred when modal opens.
         */

        .modal-backdrop {

            backdrop-filter: none !important;

            -webkit-backdrop-filter: none !important;

        }


        body.modal-open {

            filter: none !important;

            backdrop-filter: none !important;

            -webkit-backdrop-filter: none !important;

        }


        .modal {

            filter: none !important;

        }


        .modal-dialog {

            filter: none !important;

        }


        .modal-content {

            filter: none !important;

        }


        /* =====================================================
           MODAL SIZE
        ====================================================== */

        .resource-modal .modal-dialog {

            max-width: 900px;

            width: 95%;

        }


        .resource-modal .modal-content {

            min-height: 600px;

        }


        /* =====================================================
           TAB CONTENT
        ====================================================== */

        .resource-modal .tab-content {

            min-height: 350px;

        }


        /* =====================================================
           PILL TABS
        ====================================================== */

        .resource-tabs {

            display: flex;

            gap: 8px;

            border-bottom: none !important;

            margin-bottom: 15px;

        }


        .resource-tabs .nav-item {

            margin: 0;

        }


        .resource-tabs .nav-link {

            border: none !important;

            border-radius: 50px !important;

            padding: 10px 20px;

            font-weight: 500;

            color: #495057;

            background-color: #f1f3f5;

            transition: all 0.2s ease;

        }


        .resource-tabs .nav-link:hover {

            background-color: #e2e6ea;

            color: #212529;

        }


        .resource-tabs .nav-link.active {

            color: #ffffff !important;

            background-color: #0d6efd !important;

            box-shadow:
                0 2px 6px rgba(13, 110, 253, 0.25);

        }


        .resource-tabs .nav-link i {

            margin-right: 5px;

        }


        /* =====================================================
           MOBILE MODAL
        ====================================================== */

        @media (max-width: 576px) {

            .resource-modal .modal-dialog {

                width: 95%;

                max-width: 95%;

                margin: 10px auto;

            }


            .resource-modal .modal-content {

                min-height: auto;

            }


            .resource-modal .tab-content {

                min-height: 300px;

            }


            /* -------------------------------------------------
               MOBILE PILL TABS
            -------------------------------------------------- */

            .resource-tabs {

                width: 100%;

                gap: 6px;

            }


            .resource-tabs .nav-item {

                flex: 1;

            }


            .resource-tabs .nav-link {

                width: 100%;

                padding: 9px 10px;

                font-size: 14px;

                text-align: center;

            }

        }
    </style>

</head>


<body>


    <!-- ==========================================================
     MAIN CONTAINER
=========================================================== -->

    <div class="container mt-5">


        <!-- ======================================================
         NAVBAR / HEADER
    ======================================================= -->

        <?php include 'includes/navbar.php'; ?>


        <!-- ======================================================
         SESSION ERROR
    ======================================================= -->

        <?php if (isset($_SESSION['error'])): ?>

            <div
                class="alert alert-warning alert-dismissible fade show"
                role="alert">

                <?= htmlspecialchars($_SESSION['error']) ?>


                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="alert"
                    aria-label="Close">
                </button>

            </div>


            <?php unset($_SESSION['error']); ?>

        <?php endif; ?>


        <br>


        <!-- ======================================================
         PAGE HEADER
    ======================================================= -->

        <div
            class="d-flex justify-content-between align-items-center mb-3 resource-header">


            <!-- TITLE -->

            <h4 class="mb-0">

                <i class="bi bi-eye"></i>

                View / Book Resources

            </h4>


            <!-- ==================================================
             SEARCH
        =================================================== -->

            <div
                class="input-group resource-search">

                <input
                    type="text"
                    class="form-control"
                    placeholder="Resources..."
                    id="searchInput"
                    autocomplete="off">


                <!-- CLEAR -->

                <button
                    class="btn btn-secondary"
                    type="button"
                    id="clearBtn"
                    style="display:none;">

                    <i class="bi bi-x-lg"></i>

                </button>


                <!-- SEARCH -->

                <button
                    class="btn btn-primary"
                    type="button"
                    id="searchBtn">

                    <i class="bi bi-search"></i>

                </button>

            </div>

        </div>


        <!-- ======================================================
         RESOURCE CARDS
    ======================================================= -->

        <div
            class="row"
            id="resourceContainer">


            <?php if (count($resources) > 0): ?>


                <?php foreach ($resources as $res): ?>


                    <!-- RESOURCE CARD -->

                    <div class="col-md-4 mb-4 resource-card">


                        <div class="card shadow h-100">


                            <div class="card-body d-flex flex-column">


                                <!-- RESOURCE NAME -->

                                <h5 class="card-title">

                                    <?= htmlspecialchars(
                                        $res['resource_name']
                                    ) ?>

                                </h5>


                                <!-- LOCATION -->

                                <p class="card-text mb-2">

                                    <strong>
                                        Location:
                                    </strong>

                                    <?= htmlspecialchars(
                                        $res['location']
                                    ) ?>

                                </p>


                                <!-- CAPACITY -->

                                <p class="card-text mb-3">

                                    <strong>
                                        Capacity:
                                    </strong>

                                    <?= htmlspecialchars(
                                        $res['capacity']
                                    ) ?>

                                </p>


                                <!-- BUTTONS -->

                                <div
                                    class="d-flex justify-content-between mt-auto">


                                    <!-- VIEW -->

                                    <button
                                        type="button"
                                        class="btn btn-outline-info btn-sm view-resource"
                                        data-bs-toggle="modal"
                                        data-bs-target="#resourceModal<?= (int)$res['resource_id'] ?>">

                                        <i class="bi bi-eye"></i>

                                        View

                                    </button>


                                    <!-- BOOK -->

                                    <button
                                        type="button"
                                        class="btn btn-success btn-sm book-resource"
                                        data-bs-toggle="modal"
                                        data-bs-target="#resourceModal<?= (int)$res['resource_id'] ?>">

                                        <i class="bi bi-calendar-check"></i>

                                        Book

                                    </button>


                                </div>


                            </div>


                        </div>


                    </div>


                <?php endforeach; ?>


            <?php else: ?>


                <!-- NO RESOURCES -->

                <div class="col-12">

                    <div class="alert alert-info text-center">

                        <i class="bi bi-info-circle"></i>

                        No active resources are currently available.

                    </div>

                </div>


            <?php endif; ?>


        </div>


        <!-- ======================================================
         SHOWING + PAGINATION
    ======================================================= -->

        <?php if ($totalResources > 0): ?>


            <div
                class="d-flex justify-content-between align-items-center mt-2 mb-4 pagination-section">


                <!-- LEFT -->

                <div class="text-muted">

                    Showing

                    <strong>
                        <?= $showingFrom ?>
                    </strong>

                    -

                    <strong>
                        <?= $showingTo ?>
                    </strong>

                    of

                    <strong>
                        <?= $totalResources ?>
                    </strong>

                    active resources

                </div>


                <!-- RIGHT -->

                <?php if ($totalPages > 1): ?>


                    <nav aria-label="Resource pagination">


                        <ul class="pagination mb-0">


                            <!-- FIRST -->

                            <li
                                class="page-item
                            <?= ($page <= 1) ? 'disabled' : '' ?>">

                                <?php if ($page > 1): ?>

                                    <a
                                        class="page-link"
                                        href="?page=1"
                                        title="First page"
                                        aria-label="First page">
                                        «
                                    </a>

                                <?php else: ?>

                                    <span class="page-link">
                                        «
                                    </span>

                                <?php endif; ?>

                            </li>


                            <!-- PREVIOUS -->

                            <li
                                class="page-item
                            <?= ($page <= 1) ? 'disabled' : '' ?>">

                                <?php if ($page > 1): ?>

                                    <a
                                        class="page-link"
                                        href="?page=<?= $page - 1 ?>"
                                        title="Previous page"
                                        aria-label="Previous page">
                                        ‹
                                    </a>

                                <?php else: ?>

                                    <span class="page-link">
                                        ‹
                                    </span>

                                <?php endif; ?>

                            </li>


                            <!-- PAGE NUMBERS -->

                            <?php for (
                                $i = 1;
                                $i <= $totalPages;
                                $i++
                            ): ?>

                                <li
                                    class="page-item
                                <?= ($i == $page) ? 'active' : '' ?>">

                                    <a
                                        class="page-link"
                                        href="?page=<?= $i ?>">

                                        <?= $i ?>

                                    </a>

                                </li>

                            <?php endfor; ?>


                            <!-- NEXT -->

                            <li
                                class="page-item
                            <?= ($page >= $totalPages) ? 'disabled' : '' ?>">

                                <?php if ($page < $totalPages): ?>

                                    <a
                                        class="page-link"
                                        href="?page=<?= $page + 1 ?>"
                                        title="Next page"
                                        aria-label="Next page">
                                        ›
                                    </a>

                                <?php else: ?>

                                    <span class="page-link">
                                        ›
                                    </span>

                                <?php endif; ?>

                            </li>


                            <!-- LAST -->

                            <li
                                class="page-item
                            <?= ($page >= $totalPages) ? 'disabled' : '' ?>">

                                <?php if ($page < $totalPages): ?>

                                    <a
                                        class="page-link"
                                        href="?page=<?= $totalPages ?>"
                                        title="Last page"
                                        aria-label="Last page">
                                        »
                                    </a>

                                <?php else: ?>

                                    <span class="page-link">
                                        »
                                    </span>

                                <?php endif; ?>

                            </li>


                        </ul>

                    </nav>


                <?php endif; ?>


            </div>


        <?php endif; ?>


        <!-- ======================================================
         FOOTER
    ======================================================= -->

        <div class="page-footer">

            <?php include 'includes/footer.php'; ?>

        </div>


    </div>
    <!-- END .container -->



    <!-- ==========================================================
     RESOURCE MODALS
=========================================================== -->

    <?php foreach ($resources as $res): ?>


        <div
            class="modal fade resource-modal"
            id="resourceModal<?= (int)$res['resource_id'] ?>"
            tabindex="-1"
            aria-labelledby="resourceModalLabel<?= (int)$res['resource_id'] ?>"
            aria-hidden="true">


            <div
                class="modal-dialog modal-lg modal-dialog-centered">


                <div class="modal-content">


                    <form
                        method="POST"
                        action="actions/handle_booking.php"
                        class="booking-form">


                        <!-- RESOURCE ID -->

                        <input
                            type="hidden"
                            name="resource_id"
                            value="<?= (int)$res['resource_id'] ?>">


                        <!-- ==================================================
                         MODAL HEADER
                    =================================================== -->

                        <div class="modal-header">


                            <h5
                                class="modal-title"
                                id="resourceModalLabel<?= (int)$res['resource_id'] ?>">

                                <?= htmlspecialchars(
                                    $res['resource_name']
                                ) ?>

                            </h5>


                            <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close">
                            </button>


                        </div>


                        <!-- ==================================================
                         MODAL BODY
                    =================================================== -->

                        <div class="modal-body">


                            <!-- ==================================================
                             PILL TABS
                        =================================================== -->

                            <ul
                                class="nav nav-pills resource-tabs"
                                role="tablist">


                                <!-- RESOURCE INFO -->

                                <li
                                    class="nav-item"
                                    role="presentation">


                                    <button
                                        class="nav-link active details-tab"
                                        type="button"
                                        data-bs-toggle="tab"
                                        data-bs-target="#details<?= (int)$res['resource_id'] ?>"
                                        role="tab"
                                        aria-controls="details<?= (int)$res['resource_id'] ?>"
                                        aria-selected="true">

                                        <i class="bi bi-info-circle"></i>

                                        Resource Info

                                    </button>


                                </li>


                                <!-- BOOK NOW -->

                                <li
                                    class="nav-item"
                                    role="presentation">


                                    <button
                                        class="nav-link book-tab"
                                        type="button"
                                        data-bs-toggle="tab"
                                        data-bs-target="#book<?= (int)$res['resource_id'] ?>"
                                        role="tab"
                                        aria-controls="book<?= (int)$res['resource_id'] ?>"
                                        aria-selected="false">

                                        <i class="bi bi-calendar-check"></i>

                                        Book Now

                                    </button>


                                </li>


                            </ul>


                            <!-- ==================================================
                             TAB CONTENT
                        =================================================== -->

                            <div class="tab-content pt-3">


                                <!-- ==================================================
                                 RESOURCE INFORMATION
                            =================================================== -->

                                <div
                                    class="tab-pane fade show active details-pane"
                                    id="details<?= (int)$res['resource_id'] ?>"
                                    role="tabpanel">


                                    <div class="row">


                                        <!-- LOCATION -->

                                        <div class="col-md-3 mb-3">


                                            <p class="mb-0">

                                                <strong>
                                                    Location:
                                                </strong>

                                                <br>

                                                <?= htmlspecialchars(
                                                    $res['location']
                                                ) ?>

                                            </p>


                                        </div>


                                        <!-- CAPACITY -->

                                        <div class="col-md-2 mb-3">


                                            <p class="mb-0">

                                                <strong>
                                                    Capacity:
                                                </strong>

                                                <br>

                                                <?= htmlspecialchars(
                                                    $res['capacity']
                                                ) ?>

                                            </p>


                                        </div>


                                        <!-- STATUS -->

                                        <div class="col-md-2 mb-3">


                                            <p class="mb-0">

                                                <strong>
                                                    Status:
                                                </strong>

                                                <br>


                                                <span
                                                    class="badge bg-success">

                                                    <?= htmlspecialchars(
                                                        $res['status']
                                                    ) ?>

                                                </span>


                                            </p>


                                        </div>


                                        <!-- DESCRIPTION -->

                                        <div class="col-md-5 mb-3">


                                            <p>

                                                <strong>
                                                    Description:
                                                </strong>

                                                <br>

                                                <?= nl2br(
                                                    htmlspecialchars(
                                                        $res['description'] ?? ''
                                                    )
                                                ) ?>

                                            </p>


                                        </div>


                                    </div>


                                    <!-- IMAGE -->

                                    <?php if (!empty($res['picture'])): ?>


                                        <div class="text-center mt-3">


                                            <img
                                                src="uploads/<?= htmlspecialchars(
                                                                    $res['picture']
                                                                ) ?>"
                                                alt="<?= htmlspecialchars(
                                                            $res['resource_name']
                                                        ) ?>"
                                                class="img-fluid rounded shadow resource-image">


                                        </div>


                                    <?php else: ?>


                                        <div
                                            class="text-center text-muted py-4">


                                            <i
                                                class="bi bi-image"
                                                style="font-size:50px;">
                                            </i>


                                            <p class="mt-2">

                                                No image available.

                                            </p>


                                        </div>


                                    <?php endif; ?>


                                </div>


                                <!-- ==================================================
                                 BOOKING
                            =================================================== -->

                                <div
                                    class="tab-pane fade book-pane"
                                    id="book<?= (int)$res['resource_id'] ?>"
                                    role="tabpanel">


                                    <div class="row">


                                        <!-- BOOKING DATE -->

                                        <div class="col-md-6 mb-3">


                                            <label class="form-label">

                                                <i
                                                    class="bi bi-calendar"></i>

                                                Booking Date

                                            </label>


                                            <input
                                                type="date"
                                                name="booking_date"
                                                class="form-control booking-date"
                                                min="<?= date('Y-m-d') ?>"
                                                required>


                                        </div>


                                        <!-- START TIME -->

                                        <div class="col-md-3 mb-3">


                                            <label class="form-label">

                                                <i
                                                    class="bi bi-clock"></i>

                                                Starting Time

                                            </label>


                                            <input
                                                type="time"
                                                name="start_time"
                                                id="start_time<?= (int)$res['resource_id'] ?>"
                                                class="form-control start-time"
                                                required>


                                        </div>


                                        <!-- END TIME -->

                                        <div class="col-md-3 mb-3">


                                            <label class="form-label">

                                                <i
                                                    class="bi bi-clock-history"></i>

                                                Ending Time

                                            </label>


                                            <input
                                                type="time"
                                                name="end_time"
                                                id="end_time<?= (int)$res['resource_id'] ?>"
                                                class="form-control end-time"
                                                disabled
                                                required>


                                        </div>


                                    </div>


                                    <!-- PURPOSE -->

                                    <div class="mb-3">


                                        <label class="form-label">

                                            <i
                                                class="bi bi-chat-left-text"></i>

                                            Purpose

                                        </label>


                                        <textarea
                                            name="purpose"
                                            id="purpose<?= (int)$res['resource_id'] ?>"
                                            class="form-control"
                                            rows="3"
                                            placeholder="We will be hosting our..."
                                            required></textarea>


                                    </div>


                                    <!-- INFORMATION -->

                                    <div class="alert alert-info">


                                        <i
                                            class="bi bi-info-circle"></i>

                                        <strong>
                                            Booking Information
                                        </strong>


                                        <br>


                                        The default booking duration is
                                        <strong>2 hours</strong>.

                                        You can change the ending time after
                                        selecting your starting time.


                                    </div>


                                    <!-- SUBMIT -->

                                    <div class="d-grid">


                                        <button
                                            type="submit"
                                            class="btn btn-primary submit-booking">

                                            <i
                                                class="bi bi-calendar-check"></i>

                                            Submit Booking

                                        </button>


                                    </div>


                                </div>


                            </div>


                        </div>


                        <!-- ==================================================
                         MODAL FOOTER
                    =================================================== -->

                        <div class="modal-footer">


                            <button
                                type="button"
                                class="btn btn-secondary"
                                data-bs-dismiss="modal">

                                <i
                                    class="bi bi-x-circle"></i>

                                Close

                            </button>


                        </div>


                    </form>


                </div>


            </div>


        </div>


    <?php endforeach; ?>



    <!-- ==========================================================
     JAVASCRIPT
=========================================================== -->

    <script>
        document.addEventListener(
            "DOMContentLoaded",
            function() {


                // =====================================================
                // SEARCH
                // =====================================================

                const searchInput =
                    document.getElementById(
                        "searchInput"
                    );


                const searchBtn =
                    document.getElementById(
                        "searchBtn"
                    );


                const clearBtn =
                    document.getElementById(
                        "clearBtn"
                    );


                function searchResources() {


                    const value =
                        searchInput.value
                        .toLowerCase()
                        .trim();


                    document
                        .querySelectorAll(
                            ".resource-card"
                        )
                        .forEach(
                            function(card) {


                                const text =
                                    card.textContent
                                    .toLowerCase();


                                if (
                                    text.includes(value)
                                ) {


                                    card.style.display =
                                        "";


                                } else {


                                    card.style.display =
                                        "none";


                                }

                            }
                        );


                    if (value.length > 0) {


                        clearBtn.style.display =
                            "flex";


                    } else {


                        clearBtn.style.display =
                            "none";

                    }

                }


                if (searchInput) {


                    searchInput.addEventListener(
                        "input",
                        searchResources
                    );

                }


                if (searchBtn) {


                    searchBtn.addEventListener(
                        "click",
                        searchResources
                    );

                }


                if (clearBtn) {


                    clearBtn.addEventListener(
                        "click",
                        function() {


                            searchInput.value =
                                "";


                            document
                                .querySelectorAll(
                                    ".resource-card"
                                )
                                .forEach(
                                    function(card) {


                                        card.style.display =
                                            "";


                                    }
                                );


                            clearBtn.style.display =
                                "none";


                            searchInput.focus();


                        }
                    );

                }



                // =====================================================
                // VIEW BUTTON
                // =====================================================

                document
                    .querySelectorAll(
                        ".view-resource"
                    )
                    .forEach(
                        function(button) {


                            button.addEventListener(
                                "click",
                                function() {


                                    const selector =
                                        this.getAttribute(
                                            "data-bs-target"
                                        );


                                    const modal =
                                        document.querySelector(
                                            selector
                                        );


                                    if (!modal) {

                                        return;

                                    }


                                    const detailsTab =
                                        modal.querySelector(
                                            ".details-tab"
                                        );


                                    if (detailsTab) {


                                        bootstrap.Tab
                                            .getOrCreateInstance(
                                                detailsTab
                                            )
                                            .show();


                                    }


                                }
                            );


                        }
                    );



                // =====================================================
                // BOOK BUTTON
                // =====================================================

                document
                    .querySelectorAll(
                        ".book-resource"
                    )
                    .forEach(
                        function(button) {


                            button.addEventListener(
                                "click",
                                function() {


                                    const selector =
                                        this.getAttribute(
                                            "data-bs-target"
                                        );


                                    const modal =
                                        document.querySelector(
                                            selector
                                        );


                                    if (!modal) {

                                        return;

                                    }


                                    const bookTab =
                                        modal.querySelector(
                                            ".book-tab"
                                        );


                                    if (bookTab) {


                                        bootstrap.Tab
                                            .getOrCreateInstance(
                                                bookTab
                                            )
                                            .show();


                                    }


                                }
                            );


                        }
                    );



                // =====================================================
                // START TIME
                // =====================================================

                document
                    .querySelectorAll(
                        ".start-time"
                    )
                    .forEach(
                        function(startInput) {


                            startInput.addEventListener(
                                "change",
                                function() {


                                    const startTime =
                                        this.value;


                                    const resourceId =
                                        this.id.replace(
                                            "start_time",
                                            ""
                                        );


                                    const endInput =
                                        document.getElementById(
                                            "end_time" +
                                            resourceId
                                        );


                                    if (!endInput) {

                                        return;

                                    }


                                    if (!startTime) {


                                        endInput.disabled =
                                            true;


                                        endInput.value =
                                            "";


                                        endInput.removeAttribute(
                                            "min"
                                        );


                                        return;

                                    }


                                    const parts =
                                        startTime.split(":");


                                    const hours =
                                        parseInt(
                                            parts[0],
                                            10
                                        );


                                    const minutes =
                                        parseInt(
                                            parts[1],
                                            10
                                        );


                                    const endHours =
                                        hours + 2;


                                    // Prevent midnight crossing

                                    if (endHours >= 24) {


                                        alert(
                                            "The booking cannot continue past midnight. Please select an earlier starting time."
                                        );


                                        this.value =
                                            "";


                                        endInput.disabled =
                                            true;


                                        endInput.value =
                                            "";


                                        endInput.removeAttribute(
                                            "min"
                                        );


                                        return;

                                    }


                                    const formattedEndTime =
                                        String(
                                            endHours
                                        ).padStart(
                                            2,
                                            "0"
                                        ) +
                                        ":" +
                                        String(
                                            minutes
                                        ).padStart(
                                            2,
                                            "0"
                                        );


                                    endInput.disabled =
                                        false;


                                    endInput.min =
                                        startTime;


                                    endInput.value =
                                        formattedEndTime;


                                }
                            );


                        }
                    );



                // =====================================================
                // BOOKING VALIDATION
                // =====================================================

                document
                    .querySelectorAll(
                        ".booking-form"
                    )
                    .forEach(
                        function(form) {


                            form.addEventListener(
                                "submit",
                                function(event) {


                                    const startInput =
                                        form.querySelector(
                                            ".start-time"
                                        );


                                    const endInput =
                                        form.querySelector(
                                            ".end-time"
                                        );


                                    const dateInput =
                                        form.querySelector(
                                            ".booking-date"
                                        );


                                    if (
                                        !startInput ||
                                        !endInput ||
                                        !dateInput
                                    ) {

                                        return;

                                    }


                                    if (
                                        !startInput.value ||
                                        !endInput.value ||
                                        !dateInput.value
                                    ) {

                                        return;

                                    }


                                    const startParts =
                                        startInput.value
                                        .split(":");


                                    const endParts =
                                        endInput.value
                                        .split(":");


                                    const startMinutes =
                                        parseInt(
                                            startParts[0],
                                            10
                                        ) * 60 +
                                        parseInt(
                                            startParts[1],
                                            10
                                        );


                                    const endMinutes =
                                        parseInt(
                                            endParts[0],
                                            10
                                        ) * 60 +
                                        parseInt(
                                            endParts[1],
                                            10
                                        );


                                    if (
                                        endMinutes <=
                                        startMinutes
                                    ) {


                                        event.preventDefault();


                                        alert(
                                            "Ending time must be later than the starting time."
                                        );


                                        endInput.focus();


                                    }


                                }
                            );


                        }
                    );



                // =====================================================
                // RESET MODALS
                // =====================================================

                document
                    .querySelectorAll(
                        ".resource-modal"
                    )
                    .forEach(
                        function(modal) {


                            modal.addEventListener(
                                "hidden.bs.modal",
                                function() {


                                    // Reset form

                                    const form =
                                        this.querySelector(
                                            ".booking-form"
                                        );


                                    if (form) {

                                        form.reset();

                                    }


                                    // Reset ending time

                                    const endInput =
                                        this.querySelector(
                                            ".end-time"
                                        );


                                    if (endInput) {


                                        endInput.disabled =
                                            true;


                                        endInput.value =
                                            "";


                                        endInput.removeAttribute(
                                            "min"
                                        );


                                    }


                                    // Reset Resource Info tab

                                    const detailsTab =
                                        this.querySelector(
                                            ".details-tab"
                                        );


                                    if (detailsTab) {


                                        bootstrap.Tab
                                            .getOrCreateInstance(
                                                detailsTab
                                            )
                                            .show();


                                    }


                                }
                            );


                        }
                    );


            }
        );
    </script>


</body>

</html>