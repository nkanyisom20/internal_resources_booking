<?php

require 'config/db.php';


/*
|--------------------------------------------------------------------------
| Check Login
|--------------------------------------------------------------------------
*/

if (
    !isset($_SESSION['user']) ||
    empty($_SESSION['user']['employee_id'])
) {

    header("Location: login.php");
    exit;
}


/*
|--------------------------------------------------------------------------
| Get Logged-In Employee ID
|--------------------------------------------------------------------------
*/

$employeeId = $_SESSION['user']['employee_id'];



/*
|--------------------------------------------------------------------------
| Handle Form Submission
|--------------------------------------------------------------------------
*/

if ($_SERVER["REQUEST_METHOD"] === "POST") {


    /*
    |--------------------------------------------------------------------------
    | UPDATE PROFILE
    |--------------------------------------------------------------------------
    */

    if (isset($_POST['update_profile'])) {


        /*
        |--------------------------------------------------------------------------
        | Get Submitted Values
        |--------------------------------------------------------------------------
        */

        $surname =
            trim($_POST['surname'] ?? '');

        $fullnames =
            trim($_POST['fullnames'] ?? '');

        $email =
            trim($_POST['email_address'] ?? '');

        $newPassword =
            $_POST['new_password'] ?? '';

        $confirmPassword =
            $_POST['confirm_password'] ?? '';



        /*
        |--------------------------------------------------------------------------
        | Validate Required Fields
        |--------------------------------------------------------------------------
        */

        if (
            $surname === '' ||
            $fullnames === '' ||
            $email === ''
        ) {

            $_SESSION['error'] =
                "Please complete all required fields.";

            header("Location: profile.php");
            exit;
        }



        /*
        |--------------------------------------------------------------------------
        | Validate Email
        |--------------------------------------------------------------------------
        */

        if (
            !filter_var(
                $email,
                FILTER_VALIDATE_EMAIL
            )
        ) {

            $_SESSION['error'] =
                "Please enter a valid email address.";

            header("Location: profile.php");
            exit;
        }



        /*
        |--------------------------------------------------------------------------
        | Check Duplicate Email
        |--------------------------------------------------------------------------
        */

        $stmt = $connect->prepare("SELECT employee_id FROM employees WHERE email_address = ? AND employee_id != ? LIMIT 1 ");

        $stmt->execute([
            $email,
            $employeeId
        ]);


        if ($stmt->fetch()) {

            $_SESSION['error'] =
                "That email address is already being used.";

            header("Location: profile.php");
            exit;
        }



        /*
        |--------------------------------------------------------------------------
        | Check Password
        |--------------------------------------------------------------------------
        */

        $changingPassword =
            $newPassword !== '' ||
            $confirmPassword !== '';



        /*
        |--------------------------------------------------------------------------
        | Update With Password
        |--------------------------------------------------------------------------
        */

        if ($changingPassword) {


            /*
            | Both password fields must be completed
            */

            if (
                $newPassword === '' ||
                $confirmPassword === ''
            ) {

                $_SESSION['error'] =
                    "Please enter and confirm your new password.";

                header("Location: profile.php");
                exit;
            }



            /*
            | Minimum Password Length
            */

            if (strlen($newPassword) < 8) {

                $_SESSION['error'] =
                    "New password must contain at least 8 characters.";

                header("Location: profile.php");
                exit;
            }



            /*
            | Confirm Password
            */

            if ($newPassword !== $confirmPassword) {

                $_SESSION['error'] =
                    "The new passwords do not match.";

                header("Location: profile.php");
                exit;
            }



            /*
            | Hash Password
            */

            $hashedPassword =
                password_hash(
                    $newPassword,
                    PASSWORD_DEFAULT
                );



            /*
            | Update Everything
            */

            $stmt = $connect->prepare("
                UPDATE employees SET
                    surname = ?,
                    fullnames = ?,
                    email_address = ?,
                    password = ?
                WHERE employee_id = ?
            ");


            $stmt->execute([
                $surname,
                $fullnames,
                $email,
                $hashedPassword,
                $employeeId
            ]);



            $_SESSION['success'] =
                "Profile and password updated successfully.";
        } else {


            /*
            |--------------------------------------------------------------------------
            | Update Personal Information Only
            |--------------------------------------------------------------------------
            */

            $stmt = $connect->prepare("
                UPDATE employees
                SET
                    surname = ?,
                    fullnames = ?,
                    email_address = ?
                WHERE employee_id = ?
            ");


            $stmt->execute([
                $surname,
                $fullnames,
                $email,
                $employeeId
            ]);


            $_SESSION['success'] =
                "Profile updated successfully.";
        }



        /*
        |--------------------------------------------------------------------------
        | Update Session Information
        |--------------------------------------------------------------------------
        */

        $_SESSION['user']['surname'] =
            $surname;

        $_SESSION['user']['fullnames'] =
            $fullnames;

        $_SESSION['user']['email_address'] =
            $email;



        /*
        |--------------------------------------------------------------------------
        | Redirect
        |--------------------------------------------------------------------------
        */

        header("Location: profile.php");
        exit;
    }
}



/*
|--------------------------------------------------------------------------
| Fetch Employee
|--------------------------------------------------------------------------
*/

$stmt = $connect->prepare("
    SELECT
        employee_id,
        employee_no,
        surname,
        fullnames,
        email_address,
        role
    FROM employees
    WHERE employee_id = ?
    LIMIT 1
");

$stmt->execute([
    $employeeId
]);


$employee = $stmt->fetch(PDO::FETCH_ASSOC);



/*
|--------------------------------------------------------------------------
| Employee Not Found
|--------------------------------------------------------------------------
*/

if (!$employee) {

    unset($_SESSION['user']);

    session_destroy();

    header("Location: login.php");
    exit;
}



/*
|--------------------------------------------------------------------------
| Create Display Name
|--------------------------------------------------------------------------
*/

$displayName =
    trim(
        $employee['fullnames'] .
            ' ' .
            $employee['surname']
    );



/*
|--------------------------------------------------------------------------
| Create Initials
|--------------------------------------------------------------------------
*/

$initials = '';


if (!empty($employee['fullnames'])) {

    $nameParts =
        preg_split(
            '/\s+/',
            trim($employee['fullnames'])
        );


    foreach ($nameParts as $part) {

        if ($part !== '') {

            $initials .=
                strtoupper(
                    substr($part, 0, 1)
                );
        }
    }
}


if (
    $initials === '' &&
    !empty($employee['surname'])
) {

    $initials =
        strtoupper(
            substr(
                $employee['surname'],
                0,
                1
            )
        );
}


$initials =
    substr($initials, 0, 2);

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <title>
        My Profile : Nkanyiso Consulting
    </title>


    <meta charset="utf-8">


    <meta
        name="viewport"
        content="width=device-width, initial-scale=1">


    <?php include 'includes/header.php'; ?>


    <style>
        /*
        |--------------------------------------------------------------------------
        | Profile Card
        |--------------------------------------------------------------------------
        */

        .profile-card {

            border: none;

            border-radius: 12px;

            overflow: hidden;

        }


        .profile-card-header {

            height: 100px;

            background:
                linear-gradient(135deg,
                    #0d6efd,
                    #084298);

        }


        .profile-avatar {

            width: 110px;

            height: 110px;

            margin-top: -55px;

            border: 5px solid #fff;

            border-radius: 50%;

            background: #0d6efd;

            color: #fff;

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 38px;

            font-weight: 600;

            margin-left: auto;

            margin-right: auto;

        }


        .profile-name {

            font-size: 22px;

            font-weight: 600;

        }


        .profile-detail {

            padding: 10px 0;

            border-bottom: 1px solid #eee;

        }


        .profile-detail:last-child {

            border-bottom: none;

        }


        .profile-detail-label {

            font-size: 13px;

            color: #6c757d;

            margin-bottom: 3px;

        }


        .profile-detail-value {

            font-size: 15px;

            word-break: break-word;

        }


        /*
        |--------------------------------------------------------------------------
        | Edit Card
        |--------------------------------------------------------------------------
        */

        .edit-profile-card {

            border: none;

            border-radius: 12px;

            overflow: hidden;

        }


        .edit-profile-card .card-header {

            background: #fff;

            padding: 18px 20px;

            border-bottom: 1px solid #dee2e6;

        }


        .edit-profile-card .card-body {

            padding: 24px;

        }


        .edit-profile-card .card-footer {

            background: #fff;

            padding: 15px 20px;

            border-top: 1px solid #dee2e6;

        }


        .form-label {

            font-weight: 500;

        }


        @media (max-width: 991px) {

            .profile-card {

                margin-bottom: 20px;

            }

        }
    </style>

</head>


<body>


    <div class="container mt-5">


        <?php include 'includes/navbar.php'; ?>



        <!--
    |--------------------------------------------------------------------------
    | Success Message
    |--------------------------------------------------------------------------
    -->

        <?php if (isset($_SESSION['success'])): ?>

            <div
                class="alert alert-success alert-dismissible fade show"
                role="alert">

                <i class="bi bi-check-circle-fill me-1"></i>

                <?= htmlspecialchars(
                    $_SESSION['success']
                ) ?>


                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="alert"></button>

            </div>


            <?php unset($_SESSION['success']); ?>

        <?php endif; ?>



        <!--
    |--------------------------------------------------------------------------
    | Error Message
    |--------------------------------------------------------------------------
    -->

        <?php if (isset($_SESSION['error'])): ?>

            <div
                class="alert alert-danger alert-dismissible fade show"
                role="alert">

                <i class="bi bi-exclamation-triangle-fill me-1"></i>

                <?= htmlspecialchars(
                    $_SESSION['error']
                ) ?>


                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="alert"></button>

            </div>


            <?php unset($_SESSION['error']); ?>

        <?php endif; ?>



        <!--
    |--------------------------------------------------------------------------
    | Page Header
    |--------------------------------------------------------------------------
    -->

        <div
            class="d-flex justify-content-between align-items-center mb-4">

            <h4 class="mb-0">

                <i class="bi bi-person-circle"></i>

                My Profile

            </h4>

        </div>



        <!--
    |--------------------------------------------------------------------------
    | Main Profile Layout
    |--------------------------------------------------------------------------
    -->

        <div class="row g-4">


            <!--
        ======================================================================
        LEFT PROFILE CARD
        ======================================================================
        -->

            <div class="col-lg-4">


                <div class="card shadow-sm profile-card">


                    <!-- Blue Header -->

                    <div
                        class="profile-card-header"></div>



                    <div class="card-body text-center">


                        <!--
                    ----------------------------------------------------------
                    | Avatar
                    ----------------------------------------------------------
                    -->

                        <div class="profile-avatar">

                            <?= htmlspecialchars(
                                $initials
                            ) ?>

                        </div>



                        <!--
                    ----------------------------------------------------------
                    | Name
                    ----------------------------------------------------------
                    -->

                        <div class="profile-name mt-3">

                            <?= htmlspecialchars(
                                $displayName
                            ) ?>

                        </div>



                        <!--
                    ----------------------------------------------------------
                    | Employee Number
                    ----------------------------------------------------------
                    -->

                        <div class="text-muted mb-2">

                            <?= htmlspecialchars(
                                $employee['employee_no']
                            ) ?>

                        </div>



                        <!--
                    ----------------------------------------------------------
                    | Role Badge
                    ----------------------------------------------------------
                    -->

                        <?php if (
                            $employee['role'] === 'Admin'
                        ): ?>

                            <span
                                class="badge bg-secondary">

                                <i class="bi bi-shield-check me-1"></i>

                                Admin

                            </span>

                        <?php else: ?>

                            <span
                                class="badge bg-warning text-dark">

                                <i class="bi bi-person-badge me-1"></i>

                                Clerk

                            </span>

                        <?php endif; ?>



                        <hr class="my-4">



                        <!--
                    ----------------------------------------------------------
                    | Profile Details
                    ----------------------------------------------------------
                    -->

                        <div class="text-start">


                            <!-- Email -->

                            <div class="profile-detail">

                                <div class="profile-detail-label">

                                    <i class="bi bi-envelope me-1"></i>

                                    Email Address

                                </div>


                                <div class="profile-detail-value">

                                    <?= htmlspecialchars(
                                        $employee['email_address']
                                    ) ?>

                                </div>

                            </div>



                            <!-- Employee Number -->

                            <div class="profile-detail">

                                <div class="profile-detail-label">

                                    <i class="bi bi-person-vcard me-1"></i>

                                    Employee Number

                                </div>


                                <div class="profile-detail-value">

                                    <?= htmlspecialchars(
                                        $employee['employee_no']
                                    ) ?>

                                </div>

                            </div>



                            <!-- Role -->

                            <div class="profile-detail">

                                <div class="profile-detail-label">

                                    <i class="bi bi-shield me-1"></i>

                                    Account Role

                                </div>


                                <div class="profile-detail-value">

                                    <?= htmlspecialchars(
                                        $employee['role']
                                    ) ?>

                                </div>

                            </div>


                        </div>


                    </div>

                </div>


            </div>



            <!--
        ======================================================================
        RIGHT EDIT PROFILE CARD
        ======================================================================
        -->

            <div class="col-lg-8">


                <div
                    class="card shadow-sm edit-profile-card">


                    <!--
                --------------------------------------------------------------
                | Card Header
                --------------------------------------------------------------
                -->

                    <div class="card-header">


                        <h5 class="mb-0">

                            <i class="bi bi-pencil-square me-1"></i>

                            View / Edit Employee

                        </h5>


                    </div>



                    <!--
                --------------------------------------------------------------
                | ONE FORM
                --------------------------------------------------------------
                -->

                    <form
                        method="post"
                        id="profileForm">


                        <div class="card-body">


                            <!--
                        ======================================================
                        EMPLOYEE NUMBER / ROLE
                        ======================================================
                        -->

                            <div class="row">


                                <!-- Employee Number -->

                                <div class="col-md-9 mb-3">

                                    <label
                                        for="employee_no"
                                        class="form-label">

                                        Employee Number

                                    </label>


                                    <input
                                        type="text"
                                        id="employee_no"
                                        class="form-control"
                                        value="<?= htmlspecialchars(
                                                    $employee['employee_no']
                                                ) ?>"
                                        readonly>

                                </div>



                                <!-- Role -->

                                <div class="col-md-3 mb-3">

                                    <label
                                        for="role"
                                        class="form-label">

                                        Role

                                    </label>


                                    <input
                                        type="text"
                                        id="role"
                                        class="form-control"
                                        value="<?= htmlspecialchars(
                                                    $employee['role']
                                                ) ?>"
                                        readonly>

                                </div>


                            </div>



                            <!--
                        ======================================================
                        SURNAME / FULL NAMES
                        ======================================================
                        -->

                            <div class="row">


                                <!-- Surname -->

                                <div class="col-md-6 mb-3">

                                    <label
                                        for="surname"
                                        class="form-label">

                                        Surname

                                    </label>


                                    <input
                                        type="text"
                                        name="surname"
                                        id="surname"
                                        class="form-control"
                                        value="<?= htmlspecialchars(
                                                    $employee['surname']
                                                ) ?>"
                                        required>

                                </div>



                                <!-- Full Names -->

                                <div class="col-md-6 mb-3">

                                    <label
                                        for="fullnames"
                                        class="form-label">

                                        Full Names

                                    </label>


                                    <input
                                        type="text"
                                        name="fullnames"
                                        id="fullnames"
                                        class="form-control"
                                        value="<?= htmlspecialchars(
                                                    $employee['fullnames']
                                                ) ?>"
                                        required>

                                </div>


                            </div>



                            <!--
                        ======================================================
                        EMAIL ADDRESS
                        ======================================================
                        -->

                            <div class="mb-3">

                                <label
                                    for="email_address"
                                    class="form-label">

                                    Email Address

                                </label>


                                <input
                                    type="email"
                                    name="email_address"
                                    id="email_address"
                                    class="form-control"
                                    value="<?= htmlspecialchars(
                                                $employee['email_address']
                                            ) ?>"
                                    required>

                            </div>



                            <!-- Divider -->

                            <hr class="my-4">



                            <!--
                        ======================================================
                        CHANGE PASSWORD
                        ======================================================
                        -->

                            <h5 class="mb-2">

                                Change Password

                            </h5>


                            <small class="text-muted">

                                <i>

                                    Leave the password fields blank if
                                    you don't want to change the current
                                    password.

                                </i>

                            </small>



                            <!--
                        ======================================================
                        PASSWORD ROW
                        ======================================================
                        -->

                            <div class="row mt-3">


                                <!-- New Password -->

                                <div class="col-md-6 mb-3">

                                    <label
                                        for="new_password"
                                        class="form-label">

                                        New Password

                                    </label>


                                    <input
                                        type="password"
                                        name="new_password"
                                        id="new_password"
                                        class="form-control"
                                        minlength="8"
                                        autocomplete="new-password">

                                </div>



                                <!-- Confirm Password -->

                                <div class="col-md-6 mb-3">

                                    <label
                                        for="confirm_password"
                                        class="form-label">

                                        Confirm Password

                                    </label>


                                    <input
                                        type="password"
                                        name="confirm_password"
                                        id="confirm_password"
                                        class="form-control"
                                        minlength="8"
                                        autocomplete="new-password">

                                </div>


                            </div>



                            <!--
                        ======================================================
                        SHOW PASSWORDS
                        ======================================================
                        -->

                            <div class="form-check mt-1">

                                <input
                                    class="form-check-input"
                                    type="checkbox"
                                    id="showPasswords">


                                <label
                                    class="form-check-label"
                                    for="showPasswords">

                                    Show Passwords

                                </label>

                            </div>


                        </div>



                        <!--
                    ----------------------------------------------------------
                    | Card Footer
                    ----------------------------------------------------------
                    -->

                        <div
                            class="card-footer d-flex justify-content-end gap-2">


                            <!-- Cancel -->

                            <button
                                type="button"
                                class="btn btn-secondary"
                                onclick="window.history.back();">

                                Cancel

                            </button>



                            <!-- Save Changes -->

                            <button
                                type="submit"
                                name="update_profile"
                                class="btn btn-primary">

                                <i class="bi bi-save me-1"></i>

                                Save Changes

                            </button>


                        </div>


                    </form>


                </div>


            </div>


        </div>



        <?php include 'includes/footer.php'; ?>


    </div>



    <!--
|--------------------------------------------------------------------------
| Show / Hide Passwords
|--------------------------------------------------------------------------
-->

    <script>
        document.addEventListener(
            'DOMContentLoaded',
            function() {


                const showPasswords =
                    document.getElementById(
                        'showPasswords'
                    );


                const newPassword =
                    document.getElementById(
                        'new_password'
                    );


                const confirmPassword =
                    document.getElementById(
                        'confirm_password'
                    );


                /*
                |--------------------------------------------------------------------------
                | Show / Hide Passwords
                |--------------------------------------------------------------------------
                */

                showPasswords.addEventListener(
                    'change',
                    function() {


                        if (this.checked) {

                            newPassword.type =
                                'text';

                            confirmPassword.type =
                                'text';

                        } else {

                            newPassword.type =
                                'password';

                            confirmPassword.type =
                                'password';

                        }

                    }
                );



                /*
                |--------------------------------------------------------------------------
                | Form Validation
                |--------------------------------------------------------------------------
                */

                document
                    .getElementById('profileForm')
                    .addEventListener(
                        'submit',
                        function(event) {


                            const password =
                                newPassword.value;


                            const confirm =
                                confirmPassword.value;



                            /*
                            ----------------------------------------------------------
                            | Password entered
                            ----------------------------------------------------------
                            */

                            if (
                                password !== '' ||
                                confirm !== ''
                            ) {


                                /*
                                | Check minimum length
                                */

                                if (
                                    password.length < 8
                                ) {

                                    alert(
                                        'New password must contain at least 8 characters.'
                                    );

                                    event.preventDefault();

                                    return;

                                }



                                /*
                                | Check passwords match
                                */

                                if (
                                    password !== confirm
                                ) {

                                    alert(
                                        'The new passwords do not match.'
                                    );

                                    event.preventDefault();

                                    return;

                                }

                            }

                        }
                    );

            }
        );
    </script>


</body>

</html>