<?php

require 'config/db.php';

/*
|--------------------------------------------------------------------------
| Session
|--------------------------------------------------------------------------
*/
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}


/*
|--------------------------------------------------------------------------
| Admin authorization
|--------------------------------------------------------------------------
*/
if (
    !isset($_SESSION['user']) ||
    !isset($_SESSION['user']['role']) ||
    $_SESSION['user']['role'] !== 'Admin'
) {
    header("Location: login.php");
    exit;
}


/*
|--------------------------------------------------------------------------
| Helper functions
|--------------------------------------------------------------------------
*/
function redirectToEmployees(): never
{
    header("Location: admin_manage_employees.php");
    exit;
}


function setFlash(string $type, string $message): void
{
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message
    ];
}


function e($value): string
{
    return htmlspecialchars(
        (string)($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}


/*
|--------------------------------------------------------------------------
| CSRF token
|--------------------------------------------------------------------------
*/
if (empty($_SESSION['csrf_token'])) {

    $_SESSION['csrf_token'] = bin2hex(
        random_bytes(32)
    );
}

$csrfToken = $_SESSION['csrf_token'];


/*
|--------------------------------------------------------------------------
| Handle POST requests
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    /*
    |--------------------------------------------------------------------------
    | CSRF validation
    |--------------------------------------------------------------------------
    */
    $submittedToken = $_POST['csrf_token'] ?? '';

    if (
        empty($submittedToken) ||
        !hash_equals(
            $_SESSION['csrf_token'],
            $submittedToken
        )
    ) {

        setFlash(
            'danger',
            'Invalid security token. Please try again.'
        );

        redirectToEmployees();
    }


    /*
    |--------------------------------------------------------------------------
    | ADD EMPLOYEE
    |--------------------------------------------------------------------------
    */
    if (isset($_POST['add_new_user'])) {

        $employeeNo = trim(
            $_POST['employee_no'] ?? ''
        );

        $surname = trim(
            $_POST['surname'] ?? ''
        );

        $fullnames = trim(
            $_POST['fullnames'] ?? ''
        );

        $email = trim(
            $_POST['email_address'] ?? ''
        );

        $role = trim(
            $_POST['role'] ?? ''
        );

        $password = $_POST['password'] ?? '';

        $confirmPassword =
            $_POST['confirm_password'] ?? '';


        /*
        |--------------------------------------------------------------------------
        | Validate employee number
        |--------------------------------------------------------------------------
        */
        if ($employeeNo === '') {

            setFlash(
                'danger',
                'Employee number is required.'
            );

            redirectToEmployees();
        }


        if (!preg_match('/^\d{1,20}$/', $employeeNo)) {

            setFlash(
                'danger',
                'Employee number must contain numbers only.'
            );

            redirectToEmployees();
        }


        /*
        |--------------------------------------------------------------------------
        | Validate names
        |--------------------------------------------------------------------------
        */
        if (
            $surname === '' ||
            $fullnames === ''
        ) {

            setFlash(
                'danger',
                'Surname and full names are required.'
            );

            redirectToEmployees();
        }


        /*
        |--------------------------------------------------------------------------
        | Validate email
        |--------------------------------------------------------------------------
        */
        if (!filter_var(
            $email,
            FILTER_VALIDATE_EMAIL
        )) {

            setFlash(
                'danger',
                'Please enter a valid email address.'
            );

            redirectToEmployees();
        }


        /*
        |--------------------------------------------------------------------------
        | Validate role
        |--------------------------------------------------------------------------
        */
        $allowedRoles = [
            'Admin',
            'Clerk'
        ];

        if (!in_array(
            $role,
            $allowedRoles,
            true
        )) {

            setFlash(
                'danger',
                'Please select a valid employee role.'
            );

            redirectToEmployees();
        }


        /*
        |--------------------------------------------------------------------------
        | Validate password
        |--------------------------------------------------------------------------
        */
        if ($password === '') {

            setFlash(
                'danger',
                'Password is required.'
            );

            redirectToEmployees();
        }


        if (strlen($password) < 8) {

            setFlash(
                'danger',
                'Password must be at least 8 characters long.'
            );

            redirectToEmployees();
        }


        if ($password !== $confirmPassword) {

            setFlash(
                'danger',
                'Password and confirm password do not match.'
            );

            redirectToEmployees();
        }


        /*
        |--------------------------------------------------------------------------
        | Check employee number
        |--------------------------------------------------------------------------
        */
        $checkEmployee = $connect->prepare(
            "SELECT employee_id
             FROM employees
             WHERE employee_no = ?
             LIMIT 1"
        );

        $checkEmployee->execute([
            $employeeNo
        ]);


        if ($checkEmployee->fetch()) {

            setFlash(
                'danger',
                'An employee with that employee number already exists.'
            );

            redirectToEmployees();
        }


        /*
        |--------------------------------------------------------------------------
        | Check email
        |--------------------------------------------------------------------------
        */
        $checkEmail = $connect->prepare(
            "SELECT employee_id
             FROM employees
             WHERE email_address = ?
             LIMIT 1"
        );

        $checkEmail->execute([
            $email
        ]);


        if ($checkEmail->fetch()) {

            setFlash(
                'danger',
                'An employee with that email address already exists.'
            );

            redirectToEmployees();
        }


        /*
        |--------------------------------------------------------------------------
        | Create employee
        |--------------------------------------------------------------------------
        */
        try {

            $hashedPassword = password_hash(
                $password,
                PASSWORD_DEFAULT
            );


            $stmt = $connect->prepare(
                "INSERT INTO employees
                (
                    employee_no,
                    surname,
                    fullnames,
                    email_address,
                    password,
                    role
                )
                VALUES (?, ?, ?, ?, ?, ?)"
            );


            $stmt->execute([
                $employeeNo,
                $surname,
                $fullnames,
                $email,
                $hashedPassword,
                $role
            ]);


            setFlash(
                'success',
                'Employee added successfully.'
            );
        } catch (PDOException $e) {

            error_log(
                $e->getMessage()
            );


            setFlash(
                'danger',
                'Unable to add the employee. Please try again.'
            );
        }


        redirectToEmployees();
    }


    /*
    |--------------------------------------------------------------------------
    | EDIT EMPLOYEE
    |--------------------------------------------------------------------------
    */
    if (isset($_POST['edit_infor_user'])) {

        $employeeId = filter_var(
            $_POST['employee_id'] ?? '',
            FILTER_VALIDATE_INT
        );


        $surname = trim(
            $_POST['surname'] ?? ''
        );


        $fullnames = trim(
            $_POST['fullnames'] ?? ''
        );


        $email = trim(
            $_POST['email_address'] ?? ''
        );


        $role = trim(
            $_POST['role'] ?? ''
        );


        $password =
            $_POST['password'] ?? '';


        $confirmPassword =
            $_POST['confirm_password'] ?? '';


        /*
        |--------------------------------------------------------------------------
        | Validate employee ID
        |--------------------------------------------------------------------------
        */
        if (!$employeeId) {

            setFlash(
                'danger',
                'Invalid employee selected.'
            );

            redirectToEmployees();
        }


        /*
        |--------------------------------------------------------------------------
        | Validate names
        |--------------------------------------------------------------------------
        */
        if (
            $surname === '' ||
            $fullnames === ''
        ) {

            setFlash(
                'danger',
                'Surname and full names are required.'
            );

            redirectToEmployees();
        }


        /*
        |--------------------------------------------------------------------------
        | Validate email
        |--------------------------------------------------------------------------
        */
        if (!filter_var(
            $email,
            FILTER_VALIDATE_EMAIL
        )) {

            setFlash(
                'danger',
                'Please enter a valid email address.'
            );

            redirectToEmployees();
        }


        /*
        |--------------------------------------------------------------------------
        | Validate role
        |--------------------------------------------------------------------------
        */
        $allowedRoles = [
            'Admin',
            'Clerk'
        ];


        if (!in_array(
            $role,
            $allowedRoles,
            true
        )) {

            setFlash(
                'danger',
                'Please select a valid employee role.'
            );

            redirectToEmployees();
        }


        /*
        |--------------------------------------------------------------------------
        | Make sure employee exists
        |--------------------------------------------------------------------------
        */
        $checkEmployee = $connect->prepare(
            "SELECT
                employee_id,
                role
             FROM employees
             WHERE employee_id = ?
             LIMIT 1"
        );


        $checkEmployee->execute([
            $employeeId
        ]);


        $existingEmployee =
            $checkEmployee->fetch(
                PDO::FETCH_ASSOC
            );


        if (!$existingEmployee) {

            setFlash(
                'danger',
                'The selected employee could not be found.'
            );

            redirectToEmployees();
        }


        /*
        |--------------------------------------------------------------------------
        | Check email belongs to another employee
        |--------------------------------------------------------------------------
        */
        $checkEmail = $connect->prepare(
            "SELECT employee_id
             FROM employees
             WHERE email_address = ?
             AND employee_id != ?
             LIMIT 1"
        );


        $checkEmail->execute([
            $email,
            $employeeId
        ]);


        if ($checkEmail->fetch()) {

            setFlash(
                'danger',
                'That email address is already being used by another employee.'
            );

            redirectToEmployees();
        }


        /*
        |--------------------------------------------------------------------------
        | Password is optional when editing
        |--------------------------------------------------------------------------
        */
        if ($password !== '') {

            if (strlen($password) < 8) {

                setFlash(
                    'danger',
                    'New password must be at least 8 characters long.'
                );

                redirectToEmployees();
            }


            if ($password !== $confirmPassword) {

                setFlash(
                    'danger',
                    'New password and confirm password do not match.'
                );

                redirectToEmployees();
            }
        }


        /*
        |--------------------------------------------------------------------------
        | Current logged-in employee
        |--------------------------------------------------------------------------
        */
        $currentEmployeeId =
            $_SESSION['user']['employee_id']
            ?? null;


        /*
        |--------------------------------------------------------------------------
        | Prevent admin from removing own Admin role
        |--------------------------------------------------------------------------
        */
        if (
            $currentEmployeeId &&
            (int)$currentEmployeeId === (int)$employeeId &&
            $role !== 'Admin'
        ) {

            setFlash(
                'danger',
                'You cannot change your own role from Admin.'
            );

            redirectToEmployees();
        }


        /*
        |--------------------------------------------------------------------------
        | Update employee
        |--------------------------------------------------------------------------
        */
        try {

            if ($password !== '') {

                $hashedPassword =
                    password_hash(
                        $password,
                        PASSWORD_DEFAULT
                    );


                $stmt = $connect->prepare(
                    "UPDATE employees
                     SET
                        surname = ?,
                        fullnames = ?,
                        email_address = ?,
                        role = ?,
                        password = ?
                     WHERE employee_id = ?"
                );


                $stmt->execute([
                    $surname,
                    $fullnames,
                    $email,
                    $role,
                    $hashedPassword,
                    $employeeId
                ]);
            } else {

                $stmt = $connect->prepare(
                    "UPDATE employees
                     SET
                        surname = ?,
                        fullnames = ?,
                        email_address = ?,
                        role = ?
                     WHERE employee_id = ?"
                );


                $stmt->execute([
                    $surname,
                    $fullnames,
                    $email,
                    $role,
                    $employeeId
                ]);
            }


            /*
            |--------------------------------------------------------------------------
            | Keep session information synchronized
            |--------------------------------------------------------------------------
            */
            if (
                $currentEmployeeId &&
                (int)$currentEmployeeId === (int)$employeeId
            ) {

                $_SESSION['user']['surname'] =
                    $surname;

                $_SESSION['user']['fullnames'] =
                    $fullnames;

                $_SESSION['user']['email_address'] =
                    $email;

                $_SESSION['user']['role'] =
                    $role;
            }


            setFlash(
                'success',
                'Employee information updated successfully.'
            );
        } catch (PDOException $e) {

            error_log(
                $e->getMessage()
            );


            setFlash(
                'danger',
                'Unable to update the employee. Please try again.'
            );
        }


        redirectToEmployees();
    }


    /*
    |--------------------------------------------------------------------------
    | DELETE EMPLOYEE
    |--------------------------------------------------------------------------
    */
    if (isset($_POST['delete'])) {

        $employeeId = filter_var(
            $_POST['employee_id'] ?? '',
            FILTER_VALIDATE_INT
        );


        if (!$employeeId) {

            setFlash(
                'danger',
                'Invalid employee selected.'
            );

            redirectToEmployees();
        }


        /*
        |--------------------------------------------------------------------------
        | Prevent deleting yourself
        |--------------------------------------------------------------------------
        */
        $currentEmployeeId =
            $_SESSION['user']['employee_id']
            ?? null;


        if (
            $currentEmployeeId &&
            (int)$currentEmployeeId === (int)$employeeId
        ) {

            setFlash(
                'danger',
                'You cannot delete your own account while logged in.'
            );

            redirectToEmployees();
        }


        try {

            /*
            |--------------------------------------------------------------------------
            | Check employee exists
            |--------------------------------------------------------------------------
            */
            $checkEmployee = $connect->prepare(
                "SELECT employee_id
                 FROM employees
                 WHERE employee_id = ?
                 LIMIT 1"
            );


            $checkEmployee->execute([
                $employeeId
            ]);


            if (!$checkEmployee->fetch()) {

                setFlash(
                    'danger',
                    'The selected employee could not be found.'
                );

                redirectToEmployees();
            }


            /*
            |--------------------------------------------------------------------------
            | Delete
            |--------------------------------------------------------------------------
            */
            $stmt = $connect->prepare(
                "DELETE FROM employees
                 WHERE employee_id = ?"
            );


            $stmt->execute([
                $employeeId
            ]);


            setFlash(
                'success',
                'Employee deleted successfully.'
            );
        } catch (PDOException $e) {

            error_log(
                $e->getMessage()
            );


            setFlash(
                'danger',
                'Unable to delete the employee. The employee may be linked to other records.'
            );
        }


        redirectToEmployees();
    }


    /*
    |--------------------------------------------------------------------------
    | Unknown POST
    |--------------------------------------------------------------------------
    */
    setFlash(
        'danger',
        'Invalid request.'
    );


    redirectToEmployees();
}


/*
|--------------------------------------------------------------------------
| Flash message
|--------------------------------------------------------------------------
*/
$flash =
    $_SESSION['flash']
    ?? null;


unset(
    $_SESSION['flash']
);


/*
|--------------------------------------------------------------------------
| Get employees
|--------------------------------------------------------------------------
*/
try {

    $stmt = $connect->query(
        "SELECT
            employee_id,
            employee_no,
            surname,
            fullnames,
            email_address,
            role
         FROM employees
         ORDER BY employee_id DESC"
    );


    $employees =
        $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
} catch (PDOException $e) {

    error_log(
        $e->getMessage()
    );


    $employees = [];


    $flash = [
        'type' => 'danger',
        'message' => 'Unable to load employees.'
    ];
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <title>
        Resource Booking : Nkanyiso Consulting
    </title>

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1">

    <?php include 'includes/header.php'; ?>


    <style>
        /* Match the Admin Manage Resources modal */

        #addUserModal .modal-header,
        #editUserModal .modal-header {

            border-top:
                5px solid #0d6efd;
            transition:
                border-color 0.2s ease;
        }

        #addUserModal .modal-dialog,
        #editUserModal .modal-dialog {
            max-width: 800px;
        }

        #addUserModal .modal-content,
        #editUserModal .modal-content {
            min-height: 600px;
        }

        #addUserModal .modal-body,
        #editUserModal .modal-body {
            overflow-y: auto;
        }
    </style>

</head>


<body>


    <div class="container mt-5">


        <?php include 'includes/navbar.php'; ?>


        <!-- =========================================================
         PAGE HEADING
    ========================================================== -->

        <div
            class="d-flex justify-content-between align-items-center mb-3 add-employees">

            <h4 class="mb-0">

                <i class="bi bi-people-fill"></i>

                Manage Employees

            </h4>


            <button
                type="button"
                class="btn btn-success"
                data-bs-toggle="modal"
                data-bs-target="#addUserModal">

                <i class="bi bi-person-plus"></i>

                Add Employee

            </button>

        </div>


        <!-- =========================================================
         FLASH
    ========================================================== -->

        <?php if ($flash): ?>

            <div
                class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show"
                role="alert">

                <?= e($flash['message']) ?>


                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="alert"
                    aria-label="Close"></button>

            </div>

        <?php endif; ?>


        <!-- =========================================================
         EMPLOYEE TABLE
    ========================================================== -->

        <div class="card shadow-sm">

            <div class="card-body">

                <div class="table-responsive">

                    <table
                        class="table table-bordered table-striped table-hover align-middle"
                        id="employees_table"
                        style="width:100%;">

                        <thead class="table-dark">

                            <tr>

                                <th>
                                    No.
                                </th>

                                <th>
                                    Employee No
                                </th>

                                <th>
                                    Surname
                                </th>

                                <th>
                                    Full Names
                                </th>

                                <th>
                                    Email Address
                                </th>

                                <th>
                                    Role
                                </th>

                                <th>
                                    Actions
                                </th>

                            </tr>

                        </thead>


                        <tbody>

                            <?php foreach (
                                $employees
                                as $index => $user
                            ): ?>

                                <tr>

                                    <td>

                                        <strong>
                                            <?= $index + 1 ?>
                                        </strong>

                                    </td>


                                    <td>
                                        <?= e(
                                            $user['employee_no']
                                        ) ?>
                                    </td>


                                    <td>
                                        <?= e(
                                            $user['surname']
                                        ) ?>
                                    </td>


                                    <td>
                                        <?= e(
                                            $user['fullnames']
                                        ) ?>
                                    </td>


                                    <td>
                                        <?= e(
                                            $user['email_address']
                                        ) ?>
                                    </td>


                                    <td>

                                        <?php if (
                                            $user['role'] === 'Admin'
                                        ): ?>

                                            <span
                                                class="badge bg-secondary">
                                                Admin
                                            </span>

                                        <?php elseif (
                                            $user['role'] === 'Clerk'
                                        ): ?>

                                            <span
                                                class="badge bg-warning text-dark">
                                                Clerk
                                            </span>

                                        <?php else: ?>

                                            <span
                                                class="badge bg-danger">
                                                No Role
                                            </span>

                                        <?php endif; ?>

                                    </td>


                                    <td class="text-nowrap">

                                        <!-- EDIT -->

                                        <button
                                            type="button"
                                            class="btn btn-primary btn-sm editUser"

                                            data-bs-toggle="modal"
                                            data-bs-target="#editUserModal"

                                            data-id="<?= e(
                                                            $user['employee_id']
                                                        ) ?>"

                                            data-employee="<?= e(
                                                                $user['employee_no']
                                                            ) ?>"

                                            data-surname="<?= e(
                                                                $user['surname']
                                                            ) ?>"

                                            data-fullnames="<?= e(
                                                                $user['fullnames']
                                                            ) ?>"

                                            data-email="<?= e(
                                                            $user['email_address']
                                                        ) ?>"

                                            data-role="<?= e(
                                                            $user['role']
                                                        ) ?>"

                                            title="View / Edit employee">

                                            <i
                                                class="bi bi-eye"></i>

                                        </button>


                                        <!-- DELETE -->

                                        <form
                                            method="post"
                                            class="d-inline deleteEmployeeForm">

                                            <input
                                                type="hidden"
                                                name="csrf_token"
                                                value="<?= e(
                                                            $csrfToken
                                                        ) ?>">


                                            <input
                                                type="hidden"
                                                name="employee_id"
                                                value="<?= e(
                                                            $user['employee_id']
                                                        ) ?>">


                                            <button
                                                type="submit"
                                                name="delete"
                                                class="btn btn-danger btn-sm"
                                                title="Delete employee">

                                                <i
                                                    class="bi bi-trash"></i>

                                            </button>

                                        </form>

                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            </div>

        </div>


        <br>


        <!-- ============================================================
         FOOTER
    ============================================================ -->

        <div class="site-footer">

            <?php include 'includes/footer.php'; ?>

        </div>


    </div>



    <!-- ============================================================
     ADD EMPLOYEE MODAL
============================================================ -->

    <div
        class="modal fade employees-modal"
        id="addUserModal"
        tabindex="-1"
        aria-labelledby="addUserLabel"
        aria-hidden="true">

        <div class="modal-dialog modal-lg modal-dialog-centered">

            <form
                method="post"
                class="modal-content"
                id="addEmployeeForm">

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= e($csrfToken) ?>">


                <div class="modal-header">

                    <h5
                        class="modal-title"
                        id="addUserLabel">

                        <i class="bi bi-person-plus"></i>

                        Add Employee

                    </h5>


                    <button
                        type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"></button>

                </div>


                <div class="modal-body">

                    <div class="row">

                        <div class="col-md-9 mb-3">

                            <label
                                for="reg_employee_no"
                                class="form-label">
                                Employee Number
                            </label>


                            <input
                                type="text"
                                name="employee_no"
                                id="reg_employee_no"
                                maxlength="20"
                                inputmode="numeric"
                                class="form-control"
                                autocomplete="off"
                                required>


                            <div
                                id="employee_no_for_registration"
                                class="form-text"></div>

                        </div>


                        <div class="col-md-3 mb-3">

                            <label
                                for="reg_role"
                                class="form-label">
                                Role
                            </label>


                            <select
                                name="role"
                                id="reg_role"
                                class="form-select"
                                required>

                                <option value="">
                                    - Select -
                                </option>

                                <option value="Clerk">
                                    Clerk
                                </option>

                                <option value="Admin">
                                    Admin
                                </option>

                            </select>

                        </div>

                    </div>


                    <div class="row">

                        <div class="col-md-6 mb-3">

                            <label
                                for="reg_surname"
                                class="form-label">
                                Surname
                            </label>


                            <input
                                type="text"
                                name="surname"
                                id="reg_surname"
                                class="form-control"
                                required>

                        </div>


                        <div class="col-md-6 mb-3">

                            <label
                                for="reg_fullnames"
                                class="form-label">
                                Full Names
                            </label>


                            <input
                                type="text"
                                name="fullnames"
                                id="reg_fullnames"
                                class="form-control"
                                required>

                        </div>

                    </div>


                    <div class="mb-3">

                        <label
                            for="reg_email"
                            class="form-label">
                            Email Address
                        </label>


                        <input
                            type="email"
                            name="email_address"
                            id="reg_email"
                            class="form-control"
                            required>

                    </div>


                    <hr>


                    <div class="row">

                        <div class="col-md-6 mb-3">

                            <label
                                for="password"
                                class="form-label">
                                Password
                            </label>


                            <input
                                type="password"
                                name="password"
                                id="password"
                                class="form-control"
                                minlength="8"
                                autocomplete="new-password"
                                required>

                        </div>


                        <div class="col-md-6 mb-3">

                            <label
                                for="confirm_password"
                                class="form-label">
                                Confirm Password
                            </label>


                            <input
                                type="password"
                                name="confirm_password"
                                id="confirm_password"
                                class="form-control"
                                minlength="8"
                                autocomplete="new-password"
                                required>


                            <div
                                id="addPasswordMessage"
                                class="form-text"></div>

                        </div>

                    </div>


                    <div class="form-check">

                        <input
                            class="form-check-input"
                            type="checkbox"
                            id="showAddPassword">


                        <label
                            class="form-check-label"
                            for="showAddPassword">
                            Show Passwords
                        </label>

                    </div>

                </div>


                <div class="modal-footer">

                    <button
                        type="button"
                        class="btn btn-secondary"
                        data-bs-dismiss="modal">
                        Cancel
                    </button>


                    <button
                        type="submit"
                        name="add_new_user"
                        class="btn btn-success"
                        id="add_new_user">

                        <i class="bi bi-check-lg"></i>

                        Save Employee

                    </button>

                </div>

            </form>

        </div>

    </div>



    <!-- ============================================================
     EDIT EMPLOYEE MODAL
============================================================ -->

    <div
        class="modal fade employees-modal"
        id="editUserModal"
        tabindex="-1"
        aria-labelledby="editUserLabel"
        aria-hidden="true">

        <div class="modal-dialog modal-lg modal-dialog-centered">

            <form
                method="post"
                class="modal-content"
                id="editEmployeeForm">

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= e($csrfToken) ?>">


                <div class="modal-header">

                    <h5
                        class="modal-title"
                        id="editUserLabel">

                        <i class="bi bi-person-gear"></i>

                        View / Edit Employee

                    </h5>


                    <button
                        type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"></button>

                </div>


                <div class="modal-body">

                    <input
                        type="hidden"
                        name="employee_id"
                        id="edit_id">


                    <div class="row">

                        <div class="col-md-9 mb-3">

                            <label
                                for="edit_employee"
                                class="form-label">
                                Employee Number
                            </label>


                            <input
                                type="text"
                                id="edit_employee"
                                class="form-control"
                                readonly>

                        </div>


                        <div class="col-md-3 mb-3">

                            <label
                                for="edit_role"
                                class="form-label">
                                Role
                            </label>


                            <select
                                name="role"
                                id="edit_role"
                                class="form-select"
                                required>

                                <option value="">
                                    - Select Role -
                                </option>

                                <option value="Clerk">
                                    Clerk
                                </option>

                                <option value="Admin">
                                    Admin
                                </option>

                            </select>


                            <div
                                id="editRoleMessage"
                                class="form-text"></div>

                        </div>

                    </div>


                    <div class="row">

                        <div class="col-md-6 mb-3">

                            <label
                                for="edit_surname"
                                class="form-label">
                                Surname
                            </label>


                            <input
                                type="text"
                                name="surname"
                                id="edit_surname"
                                class="form-control"
                                required>

                        </div>


                        <div class="col-md-6 mb-3">

                            <label
                                for="edit_fullnames"
                                class="form-label">
                                Full Names
                            </label>


                            <input
                                type="text"
                                name="fullnames"
                                id="edit_fullnames"
                                class="form-control"
                                required>

                        </div>

                    </div>


                    <div class="mb-3">

                        <label
                            for="edit_email_address"
                            class="form-label">
                            Email Address
                        </label>


                        <input
                            type="email"
                            name="email_address"
                            id="edit_email_address"
                            class="form-control"
                            required>

                    </div>


                    <hr>


                    <h6>

                        <i class="bi bi-key"></i>

                        Change Password

                    </h6>


                    <small class="text-muted">

                        <em>
                            Leave the password fields blank if you do not
                            want to change the current password.
                        </em>

                    </small>


                    <div class="row mt-3">

                        <div class="col-md-6 mb-3">

                            <label
                                for="edit_password"
                                class="form-label">
                                New Password
                            </label>


                            <input
                                type="password"
                                name="password"
                                id="edit_password"
                                class="form-control"
                                minlength="8"
                                autocomplete="new-password">

                        </div>


                        <div class="col-md-6 mb-3">

                            <label
                                for="edit_confirm_password"
                                class="form-label">
                                Confirm Password
                            </label>


                            <input
                                type="password"
                                name="confirm_password"
                                id="edit_confirm_password"
                                class="form-control"
                                minlength="8"
                                autocomplete="new-password">


                            <div
                                id="editPasswordMessage"
                                class="form-text"></div>

                        </div>

                    </div>


                    <div class="form-check">

                        <input
                            class="form-check-input"
                            type="checkbox"
                            id="showPasswords">


                        <label
                            class="form-check-label"
                            for="showPasswords">
                            Show Passwords
                        </label>

                    </div>

                </div>


                <div class="modal-footer">

                    <button
                        type="button"
                        class="btn btn-secondary"
                        data-bs-dismiss="modal">
                        Cancel
                    </button>


                    <button
                        type="submit"
                        name="edit_infor_user"
                        class="btn btn-primary"
                        id="saveEditEmployee">

                        <i class="bi bi-save"></i>

                        Save Changes

                    </button>

                </div>

            </form>

        </div>

    </div>



    <!-- ============================================================
     JAVASCRIPT
============================================================ -->

    <script>
        $(document).ready(function() {


            /*
            |--------------------------------------------------------------------------
            | DATA TABLE
            |--------------------------------------------------------------------------
            |
            | The table ALWAYS displays 2 employees per page.
            |
            | The "Show 2 entries" dropdown has been removed.
            |
            | dom:
            |
            | f = Search
            | r = Processing
            | t = Table
            | i = Information
            | p = Pagination
            |
            | There is NO "l" because "l" creates the page-length dropdown.
            |
            */

            const table =
                $('#employees_table').DataTable({

                    /*
                    |--------------------------------------------------------------------------
                    | Always show 10 rows
                    |--------------------------------------------------------------------------
                    */

                    pageLength: 10,


                    /*
                    |--------------------------------------------------------------------------
                    | Remove "Show 10 entries"
                    |--------------------------------------------------------------------------
                    */

                    dom: 'frtip',


                    /*
                    |--------------------------------------------------------------------------
                    | Disable ordering
                    |--------------------------------------------------------------------------
                    */

                    ordering: false,


                    /*
                    |--------------------------------------------------------------------------
                    | Search
                    |--------------------------------------------------------------------------
                    */

                    searching: true,


                    /*
                    |--------------------------------------------------------------------------
                    | Pagination
                    |--------------------------------------------------------------------------
                    */

                    paging: true,


                    /*
                    |--------------------------------------------------------------------------
                    | Full pagination buttons
                    |--------------------------------------------------------------------------
                    */

                    pagingType: 'full_numbers',


                    /*
                    |--------------------------------------------------------------------------
                    | Information
                    |--------------------------------------------------------------------------
                    */

                    info: true,


                    /*
                    |--------------------------------------------------------------------------
                    | Language
                    |--------------------------------------------------------------------------
                    */

                    language: {

                        emptyTable: 'No employees found.',

                        zeroRecords: 'No matching employees found.',

                        info: 'Showing _START_ to _END_ of _TOTAL_ employees',

                        infoEmpty: 'Showing 0 to 0 of 0 employees',

                        search: 'Search:',

                        paginate: {

                            first: '«',

                            previous: '‹',

                            next: '›',

                            last: '»'

                        }

                    },


                    /*
                    |--------------------------------------------------------------------------
                    | Actions column
                    |--------------------------------------------------------------------------
                    */

                    columnDefs: [

                        {
                            orderable: false,
                            targets: 6
                        }

                    ]

                });


            /*
            |--------------------------------------------------------------------------
            | RESTORE DATATABLE STATE
            |--------------------------------------------------------------------------
            |
            | We restore:
            |
            | 1. Current page
            | 2. Current search
            |
            | Page length is NOT restored because it is permanently 10.
            |
            */


            const savedPage =
                sessionStorage.getItem(
                    'employees_table_page'
                );


            const savedSearch =
                sessionStorage.getItem(
                    'employees_table_search'
                );


            /*
            |--------------------------------------------------------------------------
            | Restore search
            |--------------------------------------------------------------------------
            */

            if (
                savedSearch !== null
            ) {

                table.search(savedSearch);

            }


            /*
            |--------------------------------------------------------------------------
            | Draw after restoring search
            |--------------------------------------------------------------------------
            */

            table.draw(false);


            /*
            |--------------------------------------------------------------------------
            | Restore page
            |--------------------------------------------------------------------------
            */

            if (
                savedPage !== null &&
                !isNaN(parseInt(savedPage, 10))
            ) {

                let page =
                    parseInt(savedPage, 10);


                const pages =
                    table.page.info().pages;


                /*
                |--------------------------------------------------------------------------
                | Prevent invalid page
                |--------------------------------------------------------------------------
                */

                if (pages > 0) {

                    if (page >= pages) {

                        page = pages - 1;

                    }


                    if (page < 0) {

                        page = 0;

                    }


                    table
                        .page(page)
                        .draw(false);

                }

            }


            /*
            |--------------------------------------------------------------------------
            | Save current page whenever pagination changes
            |--------------------------------------------------------------------------
            */

            $('#employees_table').on(
                'page.dt',
                function() {

                    const info =
                        table.page.info();


                    sessionStorage.setItem(
                        'employees_table_page',
                        info.page
                    );

                }
            );


            /*
            |--------------------------------------------------------------------------
            | Save search whenever search changes
            |--------------------------------------------------------------------------
            */

            $('#employees_table').on(
                'search.dt',
                function() {

                    sessionStorage.setItem(
                        'employees_table_search',
                        table.search()
                    );


                    /*
                    |--------------------------------------------------------------------------
                    | New search starts from page 1
                    |--------------------------------------------------------------------------
                    */

                    sessionStorage.setItem(
                        'employees_table_page',
                        0
                    );

                }
            );


            /*
            |--------------------------------------------------------------------------
            | EDIT EMPLOYEE MODAL
            |--------------------------------------------------------------------------
            */

            $(document).on(
                'click',
                '.editUser',
                function() {

                    const button =
                        $(this);


                    const employeeId =
                        button.attr('data-id');


                    const employeeNo =
                        button.attr('data-employee');


                    const surname =
                        button.attr('data-surname');


                    const fullnames =
                        button.attr('data-fullnames');


                    const email =
                        button.attr('data-email');


                    const databaseRole =
                        $.trim(
                            button.attr('data-role') || ''
                        );


                    /*
                    |--------------------------------------------------------------------------
                    | Fill employee details
                    |--------------------------------------------------------------------------
                    */

                    $('#edit_id')
                        .val(employeeId);


                    $('#edit_employee')
                        .val(employeeNo);


                    $('#edit_surname')
                        .val(surname);


                    $('#edit_fullnames')
                        .val(fullnames);


                    $('#edit_email_address')
                        .val(email);


                    /*
                    |--------------------------------------------------------------------------
                    | Load database role
                    |--------------------------------------------------------------------------
                    */

                    $('#edit_role')
                        .val(databaseRole);


                    if (
                        databaseRole !== 'Admin' &&
                        databaseRole !== 'Clerk'
                    ) {

                        $('#edit_role')
                            .val('');


                        $('#editRoleMessage')
                            .removeClass(
                                'text-success text-danger'
                            )
                            .addClass(
                                'text-danger'
                            )
                            .text(
                                'This employee has no role assigned in the database.'
                            );

                    } else {

                        $('#editRoleMessage')
                            .removeClass(
                                'text-success text-danger'
                            )
                            .text('');

                    }


                    /*
                    |--------------------------------------------------------------------------
                    | Clear password
                    |--------------------------------------------------------------------------
                    */

                    $('#edit_password')
                        .val('');


                    $('#edit_confirm_password')
                        .val('');


                    $('#edit_password')
                        .removeClass(
                            'is-invalid is-valid'
                        );


                    $('#edit_confirm_password')
                        .removeClass(
                            'is-invalid is-valid'
                        );


                    $('#editPasswordMessage')
                        .removeClass(
                            'text-success text-danger'
                        )
                        .text('');

                }
            );


            /*
            |--------------------------------------------------------------------------
            | SHOW/HIDE ADD PASSWORD
            |--------------------------------------------------------------------------
            */

            $('#showAddPassword').on(
                'change',
                function() {

                    const type =
                        this.checked ?
                        'text' :
                        'password';


                    $('#password')
                        .attr(
                            'type',
                            type
                        );


                    $('#confirm_password')
                        .attr(
                            'type',
                            type
                        );

                }
            );


            /*
            |--------------------------------------------------------------------------
            | SHOW/HIDE EDIT PASSWORD
            |--------------------------------------------------------------------------
            */

            $('#showPasswords').on(
                'change',
                function() {

                    const type =
                        this.checked ?
                        'text' :
                        'password';


                    $('#edit_password')
                        .attr(
                            'type',
                            type
                        );


                    $('#edit_confirm_password')
                        .attr(
                            'type',
                            type
                        );

                }
            );


            /*
            |--------------------------------------------------------------------------
            | ADD PASSWORD CHECK
            |--------------------------------------------------------------------------
            */

            function checkAddPasswords() {

                const password =
                    $('#password').val();


                const confirm =
                    $('#confirm_password').val();


                const message =
                    $('#addPasswordMessage');


                if (confirm === '') {

                    $('#confirm_password')
                        .removeClass(
                            'is-valid is-invalid'
                        );


                    message
                        .removeClass(
                            'text-success text-danger'
                        )
                        .text('');


                    return false;
                }


                if (password === confirm) {

                    $('#password, #confirm_password')
                        .removeClass(
                            'is-invalid'
                        )
                        .addClass(
                            'is-valid'
                        );


                    message
                        .removeClass(
                            'text-danger'
                        )
                        .addClass(
                            'text-success'
                        )
                        .text(
                            'Passwords match.'
                        );


                    return true;

                }


                $('#password, #confirm_password')
                    .removeClass(
                        'is-valid'
                    )
                    .addClass(
                        'is-invalid'
                    );


                message
                    .removeClass(
                        'text-success'
                    )
                    .addClass(
                        'text-danger'
                    )
                    .text(
                        'Passwords do not match.'
                    );


                return false;
            }


            $('#password, #confirm_password').on(
                'input',
                checkAddPasswords
            );


            /*
            |--------------------------------------------------------------------------
            | EDIT PASSWORD CHECK
            |--------------------------------------------------------------------------
            */

            function checkEditPasswords() {

                const password =
                    $('#edit_password').val();


                const confirm =
                    $('#edit_confirm_password').val();


                const message =
                    $('#editPasswordMessage');


                /*
                |--------------------------------------------------------------------------
                | Both blank
                |--------------------------------------------------------------------------
                */

                if (
                    password === '' &&
                    confirm === ''
                ) {

                    $('#edit_password, #edit_confirm_password')
                        .removeClass(
                            'is-valid is-invalid'
                        );


                    message
                        .removeClass(
                            'text-success text-danger'
                        )
                        .text('');


                    return true;
                }


                /*
                |--------------------------------------------------------------------------
                | One field filled
                |--------------------------------------------------------------------------
                */

                if (
                    password === '' ||
                    confirm === ''
                ) {

                    $('#edit_password, #edit_confirm_password')
                        .removeClass(
                            'is-valid'
                        )
                        .addClass(
                            'is-invalid'
                        );


                    message
                        .removeClass(
                            'text-success'
                        )
                        .addClass(
                            'text-danger'
                        )
                        .text(
                            'Please enter and confirm the new password.'
                        );


                    return false;
                }


                /*
                |--------------------------------------------------------------------------
                | Passwords match
                |--------------------------------------------------------------------------
                */

                if (password === confirm) {

                    $('#edit_password, #edit_confirm_password')
                        .removeClass(
                            'is-invalid'
                        )
                        .addClass(
                            'is-valid'
                        );


                    message
                        .removeClass(
                            'text-danger'
                        )
                        .addClass(
                            'text-success'
                        )
                        .text(
                            'Passwords match.'
                        );


                    return true;
                }


                /*
                |--------------------------------------------------------------------------
                | Passwords don't match
                |--------------------------------------------------------------------------
                */

                $('#edit_password, #edit_confirm_password')
                    .removeClass(
                        'is-valid'
                    )
                    .addClass(
                        'is-invalid'
                    );


                message
                    .removeClass(
                        'text-success'
                    )
                    .addClass(
                        'text-danger'
                    )
                    .text(
                        'Passwords do not match.'
                    );


                return false;
            }


            $('#edit_password, #edit_confirm_password').on(
                'input',
                checkEditPasswords
            );


            /*
            |--------------------------------------------------------------------------
            | ADD EMPLOYEE VALIDATION
            |--------------------------------------------------------------------------
            */

            $('#addEmployeeForm').on(
                'submit',
                function(event) {

                    if (!checkAddPasswords()) {

                        event.preventDefault();

                        $('#confirm_password')
                            .focus();

                        return false;
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | New employee goes to first page
                    |--------------------------------------------------------------------------
                    */

                    sessionStorage.setItem(
                        'employees_table_page',
                        0
                    );


                    sessionStorage.setItem(
                        'employees_table_search',
                        ''
                    );


                    return true;

                }
            );


            /*
            |--------------------------------------------------------------------------
            | EDIT EMPLOYEE SUBMIT
            |--------------------------------------------------------------------------
            */

            $('#editEmployeeForm').on(
                'submit',
                function(event) {

                    if (!checkEditPasswords()) {

                        event.preventDefault();

                        $('#edit_confirm_password')
                            .focus();

                        return false;
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | Save current page BEFORE PHP POST
                    |--------------------------------------------------------------------------
                    */

                    const info =
                        table.page.info();


                    sessionStorage.setItem(
                        'employees_table_page',
                        info.page
                    );


                    /*
                    |--------------------------------------------------------------------------
                    | Save current search
                    |--------------------------------------------------------------------------
                    */

                    sessionStorage.setItem(
                        'employees_table_search',
                        table.search()
                    );


                    return true;

                }
            );


            /*
            |--------------------------------------------------------------------------
            | DELETE EMPLOYEE
            |--------------------------------------------------------------------------
            */

            $('.deleteEmployeeForm').on(
                'submit',
                function(event) {

                    const confirmed =
                        confirm(
                            'Are you sure you want to delete this employee?'
                        );


                    if (!confirmed) {

                        event.preventDefault();

                        return false;

                    }


                    /*
                    |--------------------------------------------------------------------------
                    | Save current page BEFORE delete
                    |--------------------------------------------------------------------------
                    */

                    const info =
                        table.page.info();


                    sessionStorage.setItem(
                        'employees_table_page',
                        info.page
                    );


                    /*
                    |--------------------------------------------------------------------------
                    | Save current search
                    |--------------------------------------------------------------------------
                    */

                    sessionStorage.setItem(
                        'employees_table_search',
                        table.search()
                    );


                    return true;

                }
            );


            /*
            |--------------------------------------------------------------------------
            | EMPLOYEE NUMBER
            |--------------------------------------------------------------------------
            */

            $('#reg_employee_no').on(
                'input',
                function() {

                    this.value =
                        this.value.replace(
                            /\D/g,
                            ''
                        );


                    if (this.value.length > 20) {

                        this.value =
                            this.value.substring(
                                0,
                                20
                            );
                    }

                }
            );


            /*
            |--------------------------------------------------------------------------
            | EMPLOYEE NUMBER AJAX CHECK
            |--------------------------------------------------------------------------
            */

            $('#reg_employee_no').on(
                'blur',
                function() {

                    const value =
                        $.trim(this.value);


                    if (value === '') {

                        $('#employee_no_for_registration')
                            .html('');

                        return;
                    }


                    $.ajax({

                        type: 'POST',

                        url: 'includes/ajax/ajax_emp_no_for_register.php',

                        data: {

                            employee_no: value

                        },

                        success: function(data) {

                            $('#employee_no_for_registration')
                                .html(data);

                        },

                        error: function() {

                            $('#employee_no_for_registration')
                                .html(
                                    '<span class="text-danger">' +
                                    'Unable to check employee number.' +
                                    '</span>'
                                );

                        }

                    });

                }
            );


            /*
            |--------------------------------------------------------------------------
            | RESET ADD MODAL
            |--------------------------------------------------------------------------
            */

            $('#addUserModal').on(
                'hidden.bs.modal',
                function() {

                    const form =
                        $('#addEmployeeForm')[0];


                    form.reset();


                    $('#employee_no_for_registration')
                        .html('');


                    $('#addPasswordMessage')
                        .removeClass(
                            'text-success text-danger'
                        )
                        .text('');


                    $('#password, #confirm_password')
                        .removeClass(
                            'is-valid is-invalid'
                        )
                        .attr(
                            'type',
                            'password'
                        );


                    $('#showAddPassword')
                        .prop(
                            'checked',
                            false
                        );

                }
            );


            /*
            |--------------------------------------------------------------------------
            | RESET EDIT MODAL
            |--------------------------------------------------------------------------
            */

            $('#editUserModal').on(
                'hidden.bs.modal',
                function() {

                    $('#edit_password, #edit_confirm_password')
                        .val('')
                        .removeClass(
                            'is-valid is-invalid'
                        )
                        .attr(
                            'type',
                            'password'
                        );


                    $('#showPasswords')
                        .prop(
                            'checked',
                            false
                        );


                    $('#editPasswordMessage')
                        .removeClass(
                            'text-success text-danger'
                        )
                        .text('');


                    $('#editRoleMessage')
                        .removeClass(
                            'text-success text-danger'
                        )
                        .text('');

                }
            );


        });
    </script>


    <script
        type="text/javascript"
        src="js/jquery-key-restrictions.js"></script>


</body>

</html>