
<!-- Bootstrap 5.3 CSS (already in your page probably) -->
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/bootstrap-icons.css" rel="stylesheet">
<link href="assets/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">

<link rel='stylesheet' href='assets/dist/skeleton.css' />
<link rel='stylesheet' href='assets/dist/themes/classic/theme.css' />
<link rel='stylesheet' href='assets/dist/themes/classic/palette.css' />
 

<script src="assets/js/jquery-3.6.0.min.js"></script>

<script src="assets/js/bootstrap.bundle.min.js"></script>

<script src="assets/js/jquery.dataTables.min.js"></script>

<script src="assets/js/dataTables.bootstrap5.min.js"></script>

<script src='assets/dist/fullcalendar.global.js'></script>

<script src='assets/dist/themes/classic/global.js'></script>
    
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-K9X98C8R0Y"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-K9X98C8R0Y');
</script>