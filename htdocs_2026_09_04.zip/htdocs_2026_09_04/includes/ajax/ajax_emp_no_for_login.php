<?php
include '../../config/db.php';

$employee_no = $_POST["employee_no"];

if (empty($employee_no)) {
    echo "<span style='color:red'> Please enter Employee No.</span>";
    echo "<script>$('#password_login').prop('disabled',true);</script>";
    echo "<script>$('#submit_login').prop('disabled',true);</script>";
} elseif (!ctype_digit($employee_no)) {
    echo "<span style='color:red'> Enter Only Numbers as Employee No.</span>";
    echo "<script>$('#password_login').prop('disabled',true);</script>";
    echo "<script>$('#submit_login').prop('disabled',true);</script>";
} elseif (strlen($employee_no) < 9) {
    echo "<span style='color:red'> Employee No. must be 9 digits</span>";
    echo "<script>$('#password_login').prop('disabled',true);</script>";
    echo "<script>$('#submit_login').prop('disabled',true);</script>";
} else {
    $sql_select = $connect->prepare("SELECT employee_no FROM employees  WHERE employee_no = ?;");
    $sql_select->execute([$_POST['employee_no']]);
    $user = $sql_select->fetch();

    if ($user > 0) {
        echo "<span style='color:green'> Employee No. " . $employee_no . " exists, enter Password.</span>";
        echo "<script>$('#submit_login').prop('disabled',false);</script>";
        echo "<script>$('#password_login').prop('disabled',false);</script>";
    } else {
        echo "<span style='color:red'> Employee No. " . $employee_no . " does not exist, try again.</span>";
        echo "<script>$('#password_login').prop('disabled',true);</script>";
        echo "<script>$('#submit_login').prop('disabled',true);</script>";
    }
}
