<?php

require 'config/db.php';


/*
|--------------------------------------------------------------------------
| SESSION
|--------------------------------------------------------------------------
*/

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}


/*
|--------------------------------------------------------------------------
| ADMIN ACCESS
|--------------------------------------------------------------------------
*/

if (
    !isset($_SESSION['user']) ||
    !isset($_SESSION['user']['role']) ||
    $_SESSION['user']['role'] !== 'Admin'
) {
    header("Location: login.php");
    exit;
}


/*
|--------------------------------------------------------------------------
| HELPER FUNCTIONS
|--------------------------------------------------------------------------
*/

function redirectPage($page = 0, $search = '')
{
    $url = 'admin_manage_resources.php';

    $query = [];

    $page = max(0, (int)$page);

    $query['page'] = $page;

    if ($search !== '') {
        $query['search'] = $search;
    }

    if (!empty($query)) {
        $url .= '?' . http_build_query($query);
    }

    header("Location: " . $url);
    exit;
}


function e($value)
{
    return htmlspecialchars(
        (string)($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}


/*
|--------------------------------------------------------------------------
| CURRENT TABLE PAGE
|--------------------------------------------------------------------------
*/

$currentPage = isset($_POST['table_page'])
    ? max(0, (int)$_POST['table_page'])
    : (
        isset($_GET['page'])
        ? max(0, (int)$_GET['page'])
        : 0
    );


/*
|--------------------------------------------------------------------------
| CURRENT SEARCH
|--------------------------------------------------------------------------
*/

$currentSearch = '';

if (isset($_POST['table_search'])) {

    $currentSearch = trim(
        (string)$_POST['table_search']
    );
} elseif (isset($_GET['search'])) {

    $currentSearch = trim(
        (string)$_GET['search']
    );
}


/*
|--------------------------------------------------------------------------
| UPLOAD DIRECTORY
|--------------------------------------------------------------------------
*/

$uploadDirectory = __DIR__ . '/uploads/';

if (!is_dir($uploadDirectory)) {
    mkdir(
        $uploadDirectory,
        0755,
        true
    );
}


/*
|--------------------------------------------------------------------------
| POST REQUESTS
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {


    /*
    |--------------------------------------------------------------------------
    | ADD RESOURCE
    |--------------------------------------------------------------------------
    */

    if (isset($_POST['add_resource'])) {

        $resourceName = trim(
            $_POST['resource_name'] ?? ''
        );

        $description = trim(
            $_POST['description'] ?? ''
        );

        $location = trim(
            $_POST['location'] ?? ''
        );

        $capacity = (int)(
            $_POST['capacity'] ?? 0
        );

        $status = $_POST['status'] ?? 'Active';


        if (
            $resourceName === '' ||
            $description === '' ||
            $location === '' ||
            $capacity <= 0
        ) {

            $_SESSION['error'] =
                "Please complete all required fields.";

            redirectPage(
                $currentPage,
                $currentSearch
            );
        }


        if (
            !in_array(
                $status,
                ['Active', 'Inactive'],
                true
            )
        ) {

            $_SESSION['error'] =
                "Invalid resource status.";

            redirectPage(
                $currentPage,
                $currentSearch
            );
        }


        /*
        |--------------------------------------------------------------------------
        | PICTURE UPLOAD
        |--------------------------------------------------------------------------
        */

        $pictureName = null;

        if (
            isset($_FILES['picture']) &&
            $_FILES['picture']['error']
            !== UPLOAD_ERR_NO_FILE
        ) {

            if (
                $_FILES['picture']['error']
                !== UPLOAD_ERR_OK
            ) {

                $_SESSION['error'] =
                    "Unable to upload the resource picture.";

                redirectPage(
                    $currentPage,
                    $currentSearch
                );
            }


            if (
                $_FILES['picture']['size']
                > 5 * 1024 * 1024
            ) {

                $_SESSION['error'] =
                    "Picture must not exceed 5 MB.";

                redirectPage(
                    $currentPage,
                    $currentSearch
                );
            }


            $imageInfo = getimagesize(
                $_FILES['picture']['tmp_name']
            );


            if ($imageInfo === false) {

                $_SESSION['error'] =
                    "Please upload a valid image.";

                redirectPage(
                    $currentPage,
                    $currentSearch
                );
            }


            $allowedMimeTypes = [

                'image/jpeg' => 'jpg',

                'image/png' => 'png',

                'image/gif' => 'gif',

                'image/webp' => 'webp'

            ];


            $mimeType =
                $imageInfo['mime'] ?? '';


            if (
                !isset(
                    $allowedMimeTypes[$mimeType]
                )
            ) {

                $_SESSION['error'] =
                    "Only JPG, PNG, GIF and WEBP images are allowed.";

                redirectPage(
                    $currentPage,
                    $currentSearch
                );
            }


            $extension =
                $allowedMimeTypes[$mimeType];


            $pictureName =
                'resource_' .
                bin2hex(random_bytes(12)) .
                '.' .
                $extension;


            $destination =
                $uploadDirectory . $pictureName;


            if (
                !move_uploaded_file(
                    $_FILES['picture']['tmp_name'],
                    $destination
                )
            ) {

                $_SESSION['error'] =
                    "Unable to save the resource picture.";

                redirectPage(
                    $currentPage,
                    $currentSearch
                );
            }
        }


        /*
        |--------------------------------------------------------------------------
        | INSERT
        |--------------------------------------------------------------------------
        */

        try {

            $stmt = $connect->prepare("
                INSERT INTO resources
                (
                    resource_name,
                    description,
                    location,
                    capacity,
                    picture,
                    status
                )
                VALUES (?, ?, ?, ?, ?, ?)
            ");


            $stmt->execute([

                $resourceName,
                $description,
                $location,
                $capacity,
                $pictureName,
                $status

            ]);


            $_SESSION['success'] =
                "Resource added successfully.";
        } catch (PDOException $e) {

            error_log(
                $e->getMessage()
            );


            if (
                $pictureName !== null &&
                file_exists(
                    $uploadDirectory . $pictureName
                )
            ) {

                unlink(
                    $uploadDirectory . $pictureName
                );
            }


            $_SESSION['error'] =
                "Unable to add resource.";
        }


        redirectPage(
            $currentPage,
            $currentSearch
        );
    }



    /*
    |--------------------------------------------------------------------------
    | EDIT RESOURCE
    |--------------------------------------------------------------------------
    */

    if (isset($_POST['edit_resource'])) {

        $resourceId = (int)(
            $_POST['resource_id'] ?? 0
        );

        $resourceName = trim(
            $_POST['resource_name'] ?? ''
        );

        $description = trim(
            $_POST['description'] ?? ''
        );

        $location = trim(
            $_POST['location'] ?? ''
        );

        $capacity = (int)(
            $_POST['capacity'] ?? 0
        );

        $status = $_POST['status'] ?? 'Active';


        if ($resourceId <= 0) {

            $_SESSION['error'] =
                "Invalid resource.";

            redirectPage(
                $currentPage,
                $currentSearch
            );
        }


        if (
            $resourceName === '' ||
            $description === '' ||
            $location === '' ||
            $capacity <= 0
        ) {

            $_SESSION['error'] =
                "Please complete all required fields.";

            redirectPage(
                $currentPage,
                $currentSearch
            );
        }


        if (
            !in_array(
                $status,
                ['Active', 'Inactive'],
                true
            )
        ) {

            $_SESSION['error'] =
                "Invalid resource status.";

            redirectPage(
                $currentPage,
                $currentSearch
            );
        }


        /*
        |--------------------------------------------------------------------------
        | CURRENT RESOURCE
        |--------------------------------------------------------------------------
        */

        $stmt = $connect->prepare("
            SELECT
                resource_id,
                picture
            FROM resources
            WHERE resource_id = ?
            LIMIT 1
        ");


        $stmt->execute([
            $resourceId
        ]);


        $currentResource =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        if (!$currentResource) {

            $_SESSION['error'] =
                "Resource not found.";

            redirectPage(
                $currentPage,
                $currentSearch
            );
        }


        $oldPicture =
            $currentResource['picture'];


        $newPicture =
            $oldPicture;


        /*
        |--------------------------------------------------------------------------
        | NEW PICTURE
        |--------------------------------------------------------------------------
        */

        if (
            isset($_FILES['picture']) &&
            $_FILES['picture']['error']
            !== UPLOAD_ERR_NO_FILE
        ) {

            if (
                $_FILES['picture']['error']
                !== UPLOAD_ERR_OK
            ) {

                $_SESSION['error'] =
                    "Unable to upload the resource picture.";

                redirectPage(
                    $currentPage,
                    $currentSearch
                );
            }


            if (
                $_FILES['picture']['size']
                > 5 * 1024 * 1024
            ) {

                $_SESSION['error'] =
                    "Picture must not exceed 5 MB.";

                redirectPage(
                    $currentPage,
                    $currentSearch
                );
            }


            $imageInfo = getimagesize(
                $_FILES['picture']['tmp_name']
            );


            if ($imageInfo === false) {

                $_SESSION['error'] =
                    "Please upload a valid image.";

                redirectPage(
                    $currentPage,
                    $currentSearch
                );
            }


            $allowedMimeTypes = [

                'image/jpeg' => 'jpg',

                'image/png' => 'png',

                'image/gif' => 'gif',

                'image/webp' => 'webp'

            ];


            $mimeType =
                $imageInfo['mime'] ?? '';


            if (
                !isset(
                    $allowedMimeTypes[$mimeType]
                )
            ) {

                $_SESSION['error'] =
                    "Only JPG, PNG, GIF and WEBP images are allowed.";

                redirectPage(
                    $currentPage,
                    $currentSearch
                );
            }


            $extension =
                $allowedMimeTypes[$mimeType];


            $newPicture =
                'resource_' .
                bin2hex(random_bytes(12)) .
                '.' .
                $extension;


            $destination =
                $uploadDirectory . $newPicture;


            if (
                !move_uploaded_file(
                    $_FILES['picture']['tmp_name'],
                    $destination
                )
            ) {

                $_SESSION['error'] =
                    "Unable to save the new picture.";

                redirectPage(
                    $currentPage,
                    $currentSearch
                );
            }
        }


        /*
        |--------------------------------------------------------------------------
        | UPDATE
        |--------------------------------------------------------------------------
        */

        try {

            $stmt = $connect->prepare("
                UPDATE resources
                SET
                    resource_name = ?,
                    description = ?,
                    location = ?,
                    capacity = ?,
                    picture = ?,
                    status = ?
                WHERE resource_id = ?
            ");


            $stmt->execute([

                $resourceName,
                $description,
                $location,
                $capacity,
                $newPicture,
                $status,
                $resourceId

            ]);


            /*
            |--------------------------------------------------------------------------
            | REMOVE OLD PICTURE
            |--------------------------------------------------------------------------
            */

            if (
                $newPicture !== $oldPicture &&
                !empty($oldPicture) &&
                file_exists(
                    $uploadDirectory . $oldPicture
                )
            ) {

                unlink(
                    $uploadDirectory . $oldPicture
                );
            }


            $_SESSION['success'] =
                "Resource updated successfully.";
        } catch (PDOException $e) {

            error_log(
                $e->getMessage()
            );


            if (
                $newPicture !== $oldPicture &&
                file_exists(
                    $uploadDirectory . $newPicture
                )
            ) {

                unlink(
                    $uploadDirectory . $newPicture
                );
            }


            $_SESSION['error'] =
                "Unable to update resource.";
        }


        redirectPage(
            $currentPage,
            $currentSearch
        );
    }



    /*
    |--------------------------------------------------------------------------
    | DELETE RESOURCE
    |--------------------------------------------------------------------------
    */

    if (isset($_POST['delete_resource'])) {

        $resourceId = (int)(
            $_POST['resource_id'] ?? 0
        );


        if ($resourceId <= 0) {

            $_SESSION['error'] =
                "Invalid resource.";

            redirectPage(
                $currentPage,
                $currentSearch
            );
        }


        try {

            /*
            |--------------------------------------------------------------------------
            | GET PICTURE
            |--------------------------------------------------------------------------
            */

            $stmt = $connect->prepare("
                SELECT picture
                FROM resources
                WHERE resource_id = ?
                LIMIT 1
            ");


            $stmt->execute([
                $resourceId
            ]);


            $resource =
                $stmt->fetch(
                    PDO::FETCH_ASSOC
                );


            if (!$resource) {

                $_SESSION['error'] =
                    "Resource not found.";

                redirectPage(
                    $currentPage,
                    $currentSearch
                );
            }


            /*
            |--------------------------------------------------------------------------
            | DELETE DATABASE RECORD
            |--------------------------------------------------------------------------
            */

            $stmt = $connect->prepare("
                DELETE FROM resources
                WHERE resource_id = ?
            ");


            $stmt->execute([
                $resourceId
            ]);


            /*
            |--------------------------------------------------------------------------
            | DELETE PICTURE
            |--------------------------------------------------------------------------
            */

            if (
                !empty($resource['picture']) &&
                file_exists(
                    $uploadDirectory .
                        $resource['picture']
                )
            ) {

                unlink(
                    $uploadDirectory .
                        $resource['picture']
                );
            }


            $_SESSION['success'] =
                "Resource deleted successfully.";
        } catch (PDOException $e) {

            error_log(
                $e->getMessage()
            );


            $_SESSION['error'] =
                "Unable to delete resource. It may be linked to other records.";
        }


        redirectPage(
            $currentPage,
            $currentSearch
        );
    }
}


/*
|--------------------------------------------------------------------------
| FETCH RESOURCES
|--------------------------------------------------------------------------
*/

$stmt = $connect->query("
    SELECT
        resource_id,
        resource_name,
        description,
        location,
        capacity,
        picture,
        status
    FROM resources
    ORDER BY resource_id DESC
");


$resources =
    $stmt->fetchAll(
        PDO::FETCH_ASSOC
    );

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1">

    <title>
        Manage Resources : Nkanyiso Consulting
    </title>


    <?php include 'includes/header.php'; ?>


    <style>
        /* ==========================================================
           TOAST
        ========================================================== */

        .toast-container {
            position: fixed !important;
            top: 20px !important;
            right: 20px !important;
            bottom: auto !important;
            left: auto !important;
            z-index: 99999 !important;
        }


        .resource-toast {
            min-width: 320px;
            max-width: 420px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
        }


        .resource-toast .toast-body {
            padding: 14px 16px;
            font-size: 15px;
        }


        /* ==========================================================
           RESOURCE-STYLE TABS
        ========================================================== */

        .resource-tabs {
            display: flex;
            gap: 8px;
            border-bottom: none !important;
            margin-bottom: 15px;
        }


        .resource-tabs .nav-item {
            margin: 0;
        }


        .resource-tabs .nav-link {
            border: none !important;
            border-radius: 50px !important;
            padding: 10px 20px;
            font-weight: 500;
            color: #495057;
            background-color: #f1f3f5;
            transition: all 0.2s ease;
        }


        .resource-tabs .nav-link:hover {
            background-color: #e2e6ea;
            color: #212529;
        }


        .resource-tabs .nav-link.active {
            color: #ffffff !important;
            background-color: #0d6efd !important;
            box-shadow: 0 2px 6px rgba(13, 110, 253, 0.25);
        }


        .resource-tabs .nav-link i {
            margin-right: 5px;
        }


        /* ==========================================================
           FIXED MODAL HEIGHT
           THE HEIGHT WILL NOT CHANGE WHEN SWITCHING TABS
        ========================================================== */

        #addResourceModal .modal-dialog,
        #editResourceModal .modal-dialog {
            max-width: 900px;
            width: 95%;
        }


        #addResourceModal .modal-content,
        #editResourceModal .modal-content {
            height: 600px !important;
            min-height: 600px !important;
            max-height: 600px !important;
        }


        /*
        | Header stays fixed
        */

        #addResourceModal .modal-header,
        #editResourceModal .modal-header {
            flex-shrink: 0;
        }


        /*
        | Footer stays fixed
        */

        #addResourceModal .modal-footer,
        #editResourceModal .modal-footer {
            flex-shrink: 0;
        }


        /*
        | Body gets a fixed height
        */

        #addResourceModal .modal-body,
        #editResourceModal .modal-body {
            height: 480px !important;
            min-height: 480px !important;
            max-height: 480px !important;
            overflow-y: auto;
        }


        /*
        | Tab content remains stable
        */

        #addResourceModal .tab-content,
        #editResourceModal .tab-content {
            min-height: 350px;
        }


        /* ==========================================================
           NEVER BLUR PAGE WHEN MODAL OPENS
        ========================================================== */

        .modal-backdrop {
            backdrop-filter: none !important;
            -webkit-backdrop-filter: none !important;
        }


        body.modal-open {
            filter: none !important;
            backdrop-filter: none !important;
            -webkit-backdrop-filter: none !important;
        }


        .modal,
        .modal-dialog,
        .modal-content {
            filter: none !important;
        }


        /* ==========================================================
           MOBILE
        ========================================================== */

        @media (max-width: 576px) {

            .toast-container {
                top: 10px !important;
                right: 10px !important;
                left: 10px !important;
                width: auto !important;
            }


            .resource-toast {
                min-width: 0;
                max-width: 100%;
                width: 100%;
            }


            .resource-tabs {
                width: 100%;
                gap: 6px;
            }


            .resource-tabs .nav-item {
                flex: 1;
            }


            .resource-tabs .nav-link {
                width: 100%;
                padding: 9px 10px;
                font-size: 14px;
                text-align: center;
            }


            #addResourceModal .modal-dialog,
            #editResourceModal .modal-dialog {
                width: 95%;
                max-width: 95%;
            }


            #addResourceModal .modal-content,
            #editResourceModal .modal-content {
                height: 600px !important;
                min-height: 600px !important;
                max-height: 600px !important;
            }


            #addResourceModal .modal-body,
            #editResourceModal .modal-body {
                height: 480px !important;
                min-height: 480px !important;
                max-height: 480px !important;
            }

        }
    </style>

</head>


<body>


    <div class="container mt-5">


        <?php include 'includes/navbar.php'; ?>


        <!-- ==========================================================
         PAGE HEADER
    =========================================================== -->

        <div
            class="d-flex justify-content-between align-items-center mb-3 add-resources">

            <h4 class="mb-0">

                <i class="bi bi-building"></i>

                Manage Resources

            </h4>


            <button
                type="button"
                class="btn btn-success"
                data-bs-toggle="modal"
                data-bs-target="#addResourceModal">

                <i class="bi bi-plus-circle"></i>

                Add Resource

            </button>

        </div>


        <!-- ==========================================================
         TOAST MESSAGES
    =========================================================== -->

        <div class="toast-container position-fixed top-0 end-0 p-3">

            <?php if (isset($_SESSION['success'])): ?>

                <div
                    id="successToast"
                    class="toast resource-toast align-items-center text-bg-success border-0"
                    role="alert"
                    aria-live="assertive"
                    aria-atomic="true">

                    <div class="d-flex">

                        <div class="toast-body">

                            <i class="bi bi-check-circle-fill me-2"></i>

                            <?= e($_SESSION['success']) ?>

                        </div>


                        <button
                            type="button"
                            class="btn-close btn-close-white me-2 m-auto"
                            data-bs-dismiss="toast"
                            aria-label="Close"></button>

                    </div>

                </div>

                <?php unset($_SESSION['success']); ?>

            <?php endif; ?>


            <?php if (isset($_SESSION['error'])): ?>

                <div
                    id="errorToast"
                    class="toast resource-toast align-items-center text-bg-danger border-0"
                    role="alert"
                    aria-live="assertive"
                    aria-atomic="true">

                    <div class="d-flex">

                        <div class="toast-body">

                            <i class="bi bi-exclamation-triangle-fill me-2"></i>

                            <?= e($_SESSION['error']) ?>

                        </div>


                        <button
                            type="button"
                            class="btn-close btn-close-white me-2 m-auto"
                            data-bs-dismiss="toast"
                            aria-label="Close"></button>

                    </div>

                </div>

                <?php unset($_SESSION['error']); ?>

            <?php endif; ?>

        </div>



        <!-- ==========================================================
         RESOURCE TABLE
    =========================================================== -->

        <?php if (empty($resources)): ?>

            <div class="alert alert-info">

                <i class="bi bi-info-circle"></i>

                No resources found.

            </div>

        <?php else: ?>


            <div class="card shadow-sm">

                <div class="card-body">

                    <div class="table-responsive">

                        <table
                            id="resources_table"
                            class="table table-bordered table-striped table-hover align-middle"
                            style="width:100%;">

                            <thead class="table-dark">

                                <tr>

                                    <th>No.</th>

                                    <th>Resource Name</th>

                                    <th>Description</th>

                                    <th>Location</th>

                                    <th>Capacity</th>

                                    <th>Picture</th>

                                    <th>Status</th>

                                    <th>Actions</th>

                                </tr>

                            </thead>


                            <tbody>

                                <?php

                                $count = 1;

                                foreach (
                                    $resources
                                    as $resource
                                ):

                                    $picture =
                                        $resource['picture'] ?? '';

                                ?>

                                    <tr>

                                        <td>

                                            <strong>
                                                <?= $count++ ?>
                                            </strong>

                                        </td>


                                        <td>

                                            <?= e(
                                                $resource['resource_name']
                                            ) ?>

                                        </td>


                                        <td>

                                            <?= e(
                                                $resource['description']
                                            ) ?>

                                        </td>


                                        <td>

                                            <?= e(
                                                $resource['location']
                                            ) ?>

                                        </td>


                                        <td>

                                            <?= e(
                                                $resource['capacity']
                                            ) ?>

                                        </td>


                                        <td>

                                            <?php if (!empty($picture)): ?>

                                                <a
                                                    href="uploads/<?= e($picture) ?>"
                                                    target="_blank">

                                                    <img
                                                        src="uploads/<?= e($picture) ?>"
                                                        alt="Resource picture"
                                                        class="img-thumbnail"
                                                        width="50"
                                                        height="50"
                                                        style="object-fit:cover;cursor:pointer;">

                                                </a>

                                            <?php else: ?>

                                                <span class="text-muted">

                                                    No picture

                                                </span>

                                            <?php endif; ?>

                                        </td>


                                        <td>

                                            <?php if (
                                                $resource['status']
                                                === 'Active'
                                            ): ?>

                                                <span class="badge bg-success">

                                                    Active

                                                </span>

                                            <?php else: ?>

                                                <span class="badge bg-secondary">

                                                    Inactive

                                                </span>

                                            <?php endif; ?>

                                        </td>


                                        <td class="text-nowrap">

                                            <!-- EDIT -->

                                            <button
                                                type="button"
                                                class="btn btn-primary btn-sm editResource"
                                                data-bs-toggle="modal"
                                                data-bs-target="#editResourceModal"
                                                data-id="<?= e(
                                                                $resource['resource_id']
                                                            ) ?>"
                                                data-name="<?= e(
                                                                $resource['resource_name']
                                                            ) ?>"
                                                data-description="<?= e(
                                                                        $resource['description']
                                                                    ) ?>"
                                                data-location="<?= e(
                                                                    $resource['location']
                                                                ) ?>"
                                                data-capacity="<?= e(
                                                                    $resource['capacity']
                                                                ) ?>"
                                                data-picture="<?= e(
                                                                    $picture
                                                                ) ?>"
                                                data-status="<?= e(
                                                                    $resource['status']
                                                                ) ?>"
                                                title="View / Edit Resource">

                                                <i class="bi bi-eye"></i>

                                            </button>


                                            <!-- DELETE -->

                                            <form
                                                method="post"
                                                class="d-inline deleteResourceForm">

                                                <input
                                                    type="hidden"
                                                    name="resource_id"
                                                    value="<?= e(
                                                                $resource['resource_id']
                                                            ) ?>">


                                                <input
                                                    type="hidden"
                                                    name="table_page"
                                                    class="delete_table_page"
                                                    value="0">


                                                <input
                                                    type="hidden"
                                                    name="table_search"
                                                    class="delete_table_search"
                                                    value="">


                                                <button
                                                    type="submit"
                                                    name="delete_resource"
                                                    class="btn btn-danger btn-sm"
                                                    title="Delete Resource">

                                                    <i class="bi bi-trash"></i>

                                                </button>

                                            </form>

                                        </td>

                                    </tr>


                                <?php endforeach; ?>

                            </tbody>

                        </table>

                    </div>

                </div>

            </div>


        <?php endif; ?>


        <br>


        <div class="site-footer">

            <?php include 'includes/footer.php'; ?>

        </div>


    </div>



    <!-- ============================================================
     ADD RESOURCE MODAL
============================================================ -->

    <div
        class="modal fade resource-modal"
        id="addResourceModal"
        tabindex="-1"
        aria-hidden="true">

        <div
            class="modal-dialog modal-lg modal-dialog-centered">

            <form
                method="post"
                enctype="multipart/form-data"
                class="modal-content"
                id="addResourceForm">

                <input
                    type="hidden"
                    name="table_page"
                    id="add_table_page"
                    value="0">


                <input
                    type="hidden"
                    name="table_search"
                    id="add_table_search"
                    value="">


                <div class="modal-header">

                    <h5 class="modal-title">

                        <i class="bi bi-plus-circle"></i>

                        Add Resource

                    </h5>


                    <button
                        type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"></button>

                </div>


                <div class="modal-body">


                    <!-- ==================================================
                     PILL TABS
                =================================================== -->

                    <ul
                        class="nav nav-pills resource-tabs"
                        role="tablist">

                        <li
                            class="nav-item"
                            role="presentation">

                            <button
                                class="nav-link active"
                                type="button"
                                data-bs-toggle="tab"
                                data-bs-target="#addResourceInformation"
                                role="tab">

                                <i class="bi bi-info-circle"></i>

                                Information

                            </button>

                        </li>


                        <li
                            class="nav-item"
                            role="presentation">

                            <button
                                class="nav-link"
                                type="button"
                                data-bs-toggle="tab"
                                data-bs-target="#addResourcePicture"
                                role="tab">

                                <i class="bi bi-image"></i>

                                Picture

                            </button>

                        </li>

                    </ul>


                    <div class="tab-content pt-4">


                        <!-- INFORMATION TAB -->

                        <div
                            class="tab-pane fade show active"
                            id="addResourceInformation"
                            role="tabpanel">

                            <div class="row">

                                <div class="col-md-8 mb-3">

                                    <label
                                        for="add_resource_name"
                                        class="form-label">

                                        Resource Name

                                    </label>


                                    <input
                                        type="text"
                                        name="resource_name"
                                        id="add_resource_name"
                                        class="form-control"
                                        required>

                                </div>


                                <div class="col-md-4 mb-3">

                                    <label
                                        for="add_status"
                                        class="form-label">

                                        Status

                                    </label>


                                    <select
                                        name="status"
                                        id="add_status"
                                        class="form-select"
                                        required>

                                        <option value="Active">
                                            Active
                                        </option>

                                        <option value="Inactive">
                                            Inactive
                                        </option>

                                    </select>

                                </div>

                            </div>


                            <div class="mb-3">

                                <label
                                    for="add_description"
                                    class="form-label">

                                    Description

                                </label>


                                <textarea
                                    name="description"
                                    id="add_description"
                                    class="form-control"
                                    rows="5"
                                    required></textarea>

                            </div>


                            <div class="row">

                                <div class="col-md-8 mb-3">

                                    <label
                                        for="add_location"
                                        class="form-label">

                                        Location

                                    </label>


                                    <input
                                        type="text"
                                        name="location"
                                        id="add_location"
                                        class="form-control"
                                        required>

                                </div>


                                <div class="col-md-4 mb-3">

                                    <label
                                        for="add_capacity"
                                        class="form-label">

                                        Capacity

                                    </label>


                                    <input
                                        type="number"
                                        name="capacity"
                                        id="add_capacity"
                                        class="form-control"
                                        min="1"
                                        required>

                                </div>

                            </div>

                        </div>



                        <!-- PICTURE TAB -->

                        <div
                            class="tab-pane fade"
                            id="addResourcePicture"
                            role="tabpanel">

                            <div class="text-center">


                                <div
                                    id="addPicturePlaceholder"
                                    class="border rounded p-5 mb-3 bg-light">

                                    <i
                                        class="bi bi-image"
                                        style="font-size:50px;"></i>


                                    <div>

                                        No picture selected

                                    </div>

                                </div>


                                <img
                                    id="addPicturePreview"
                                    src=""
                                    alt="Resource picture"
                                    class="img-fluid rounded mb-3"
                                    style="display:none;max-height:320px;">


                                <label
                                    for="add_picture"
                                    class="form-label d-block text-start">

                                    Resource Picture

                                </label>


                                <input
                                    type="file"
                                    name="picture"
                                    id="add_picture"
                                    class="form-control"
                                    accept="image/jpeg,image/png,image/gif,image/webp">


                                <small
                                    class="text-muted d-block text-start mt-2">

                                    JPG, PNG, GIF or WEBP.
                                    Maximum size: 5 MB.

                                </small>

                            </div>

                        </div>

                    </div>

                </div>


                <div class="modal-footer">

                    <button
                        type="button"
                        class="btn btn-secondary"
                        data-bs-dismiss="modal">

                        Cancel

                    </button>


                    <button
                        type="submit"
                        name="add_resource"
                        class="btn btn-success">

                        <i class="bi bi-save"></i>

                        Save Resource

                    </button>

                </div>

            </form>

        </div>

    </div>



    <!-- ============================================================
     EDIT RESOURCE MODAL
============================================================ -->

    <div
        class="modal fade resource-modal"
        id="editResourceModal"
        tabindex="-1"
        aria-hidden="true">

        <div
            class="modal-dialog modal-lg modal-dialog-centered">

            <form
                method="post"
                enctype="multipart/form-data"
                class="modal-content"
                id="editResourceForm">

                <input
                    type="hidden"
                    name="resource_id"
                    id="edit_resource_id">


                <input
                    type="hidden"
                    name="table_page"
                    id="edit_table_page"
                    value="0">


                <input
                    type="hidden"
                    name="table_search"
                    id="edit_table_search"
                    value="">


                <div class="modal-header">

                    <h5 class="modal-title">

                        <i class="bi bi-pencil-square"></i>

                        View / Edit Resource

                    </h5>


                    <button
                        type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"></button>

                </div>


                <div class="modal-body">


                    <!-- ==================================================
                     PILL TABS
                =================================================== -->

                    <ul
                        class="nav nav-pills resource-tabs"
                        role="tablist">

                        <li
                            class="nav-item"
                            role="presentation">

                            <button
                                class="nav-link active"
                                type="button"
                                data-bs-toggle="tab"
                                data-bs-target="#editResourceInformation"
                                role="tab">

                                <i class="bi bi-info-circle"></i>

                                Information

                            </button>

                        </li>


                        <li
                            class="nav-item"
                            role="presentation">

                            <button
                                class="nav-link"
                                type="button"
                                data-bs-toggle="tab"
                                data-bs-target="#editResourcePicture"
                                role="tab">

                                <i class="bi bi-image"></i>

                                Add Picture

                            </button>

                        </li>

                    </ul>


                    <div class="tab-content pt-4">


                        <!-- INFORMATION TAB -->

                        <div
                            class="tab-pane fade show active"
                            id="editResourceInformation"
                            role="tabpanel">

                            <div class="row">

                                <div class="col-md-8 mb-3">

                                    <label
                                        for="edit_resource_name"
                                        class="form-label">

                                        Resource Name

                                    </label>


                                    <input
                                        type="text"
                                        name="resource_name"
                                        id="edit_resource_name"
                                        class="form-control"
                                        required>

                                </div>


                                <div class="col-md-4 mb-3">

                                    <label
                                        for="edit_status"
                                        class="form-label">

                                        Status

                                    </label>


                                    <select
                                        name="status"
                                        id="edit_status"
                                        class="form-select"
                                        required>

                                        <option value="Active">
                                            Active
                                        </option>

                                        <option value="Inactive">
                                            Inactive
                                        </option>

                                    </select>

                                </div>

                            </div>


                            <div class="mb-3">

                                <label
                                    for="edit_description"
                                    class="form-label">

                                    Description

                                </label>


                                <textarea
                                    name="description"
                                    id="edit_description"
                                    class="form-control"
                                    rows="7"
                                    required></textarea>

                            </div>


                            <div class="row">

                                <div class="col-md-8 mb-3">

                                    <label
                                        for="edit_location"
                                        class="form-label">

                                        Location

                                    </label>


                                    <input
                                        type="text"
                                        name="location"
                                        id="edit_location"
                                        class="form-control"
                                        required>

                                </div>


                                <div class="col-md-4 mb-3">

                                    <label
                                        for="edit_capacity"
                                        class="form-label">

                                        Capacity

                                    </label>


                                    <input
                                        type="number"
                                        name="capacity"
                                        id="edit_capacity"
                                        class="form-control"
                                        min="1"
                                        required>

                                </div>

                            </div>

                        </div>



                        <!-- PICTURE TAB -->

                        <div
                            class="tab-pane fade"
                            id="editResourcePicture"
                            role="tabpanel">

                            <div class="text-center">


                                <div
                                    id="editPicturePlaceholder"
                                    class="border rounded p-5 mb-3 bg-light"
                                    style="display:none;">

                                    <i
                                        class="bi bi-image"
                                        style="font-size:50px;"></i>


                                    <div>

                                        No picture available

                                    </div>

                                </div>


                                <img
                                    id="editPicturePreview"
                                    src=""
                                    alt="Resource picture"
                                    class="img-fluid rounded mb-3"
                                    style="max-height:320px;">


                                <label
                                    for="edit_picture"
                                    class="form-label d-block text-start">

                                    Resource Picture

                                </label>


                                <input
                                    type="file"
                                    name="picture"
                                    id="edit_picture"
                                    class="form-control"
                                    accept="image/jpeg,image/png,image/gif,image/webp">


                                <small
                                    class="text-muted d-block text-start mt-2">

                                    Select a new picture only if you want
                                    to replace the current picture.
                                    Maximum size: 5 MB.

                                </small>

                            </div>

                        </div>

                    </div>

                </div>


                <div class="modal-footer">

                    <button
                        type="button"
                        class="btn btn-secondary"
                        data-bs-dismiss="modal">

                        Cancel

                    </button>


                    <button
                        type="submit"
                        name="edit_resource"
                        class="btn btn-primary">

                        <i class="bi bi-save"></i>

                        Save Changes

                    </button>

                </div>

            </form>

        </div>

    </div>



    <!-- ============================================================
     JAVASCRIPT
============================================================ -->

    <script>
        $(document).ready(function() {


            /*
            |--------------------------------------------------------------------------
            | DATATABLE
            |--------------------------------------------------------------------------
            */

            let table = null;


            if ($('#resources_table').length) {

                table = $('#resources_table').DataTable({

                    pageLength: 10,

                    lengthMenu: [
                        [2, 5, 10, 25, 50, -1],
                        [2, 5, 10, 25, 50, "All"]
                    ],

                    ordering: false,

                    searching: true,

                    paging: true,

                    info: true,

                    pagingType: 'full_numbers',

                    dom: 'frtip',

                    language: {

                        emptyTable: 'No resources found.',

                        zeroRecords: 'No matching resources found.',

                        info: 'Showing _START_ to _END_ of _TOTAL_ resources',

                        infoEmpty: 'Showing 0 to 0 of 0 resources',

                        paginate: {

                            first: '«',

                            last: '»',

                            next: '›',

                            previous: '‹'

                        }

                    },

                    columnDefs: [

                        {
                            orderable: false,
                            targets: 7
                        }

                    ]

                });


                /*
                |--------------------------------------------------------------------------
                | RESTORE PAGE
                |--------------------------------------------------------------------------
                */

                const urlParams =
                    new URLSearchParams(
                        window.location.search
                    );


                const savedPage =
                    parseInt(
                        urlParams.get('page') || '0',
                        10
                    );


                if (
                    !isNaN(savedPage) &&
                    savedPage >= 0
                ) {

                    const pageCount =
                        table.page.info().pages;


                    if (
                        pageCount > 0 &&
                        savedPage < pageCount
                    ) {

                        table
                            .page(savedPage)
                            .draw('page');

                    } else if (pageCount > 0) {

                        table
                            .page(pageCount - 1)
                            .draw('page');

                    }

                }


                /*
                |--------------------------------------------------------------------------
                | RESTORE SEARCH
                |--------------------------------------------------------------------------
                */

                const savedSearch =
                    urlParams.get('search') || '';


                if (savedSearch !== '') {

                    table
                        .search(savedSearch)
                        .draw();

                }

            }



            /*
            |--------------------------------------------------------------------------
            | EDIT RESOURCE
            |--------------------------------------------------------------------------
            */

            $(document).on(
                'click',
                '.editResource',
                function() {

                    const button =
                        $(this);


                    if (table) {

                        $('#edit_table_page')
                            .val(
                                table.page()
                            );


                        $('#edit_table_search')
                            .val(
                                table.search()
                            );

                    }


                    $('#edit_resource_id')
                        .val(
                            button.attr('data-id')
                        );


                    $('#edit_resource_name')
                        .val(
                            button.attr('data-name')
                        );


                    $('#edit_description')
                        .val(
                            button.attr('data-description')
                        );


                    $('#edit_location')
                        .val(
                            button.attr('data-location')
                        );


                    $('#edit_capacity')
                        .val(
                            button.attr('data-capacity')
                        );


                    $('#edit_status')
                        .val(
                            button.attr('data-status')
                        );


                    /*
                    |--------------------------------------------------------------------------
                    | PICTURE
                    |--------------------------------------------------------------------------
                    */

                    const picture =
                        button.attr('data-picture') || '';


                    $('#edit_picture').val('');


                    if (picture !== '') {

                        $('#editPicturePlaceholder')
                            .hide();


                        $('#editPicturePreview')
                            .attr(
                                'src',
                                'uploads/' + picture
                            )
                            .show();

                    } else {

                        $('#editPicturePreview')
                            .hide()
                            .attr(
                                'src',
                                ''
                            );


                        $('#editPicturePlaceholder')
                            .show();

                    }


                    /*
                    |--------------------------------------------------------------------------
                    | ALWAYS OPEN INFORMATION TAB
                    |--------------------------------------------------------------------------
                    */

                    const firstTab =
                        document.querySelector(
                            '#editResourceModal [data-bs-target="#editResourceInformation"]'
                        );


                    if (firstTab) {

                        bootstrap.Tab
                            .getOrCreateInstance(
                                firstTab
                            )
                            .show();

                    }

                }
            );



            /*
            |--------------------------------------------------------------------------
            | ADD RESOURCE
            |--------------------------------------------------------------------------
            */

            $('[data-bs-target="#addResourceModal"]')
                .on(
                    'click',
                    function() {

                        if (!table) {
                            return;
                        }


                        $('#add_table_page')
                            .val(
                                table.page()
                            );


                        $('#add_table_search')
                            .val(
                                table.search()
                            );

                    }
                );



            /*
            |--------------------------------------------------------------------------
            | DELETE RESOURCE
            |--------------------------------------------------------------------------
            */

            $(document).on(
                'submit',
                '.deleteResourceForm',
                function(event) {

                    if (table) {

                        $(this)
                            .find('.delete_table_page')
                            .val(
                                table.page()
                            );


                        $(this)
                            .find('.delete_table_search')
                            .val(
                                table.search()
                            );

                    }


                    const confirmed =
                        confirm(
                            'Are you sure you want to delete this resource?'
                        );


                    if (!confirmed) {

                        event.preventDefault();

                        return false;

                    }


                    return true;

                }
            );



            /*
            |--------------------------------------------------------------------------
            | ADD PICTURE PREVIEW
            |--------------------------------------------------------------------------
            */

            $('#add_picture').on(
                'change',
                function() {

                    const file =
                        this.files[0];


                    if (!file) {

                        $('#addPicturePreview')
                            .hide()
                            .attr(
                                'src',
                                ''
                            );


                        $('#addPicturePlaceholder')
                            .show();


                        return;

                    }


                    const reader =
                        new FileReader();


                    reader.onload =
                        function(event) {

                            $('#addPicturePreview')
                                .attr(
                                    'src',
                                    event.target.result
                                )
                                .show();


                            $('#addPicturePlaceholder')
                                .hide();

                        };


                    reader.readAsDataURL(file);

                }
            );



            /*
            |--------------------------------------------------------------------------
            | EDIT PICTURE PREVIEW
            |--------------------------------------------------------------------------
            */

            $('#edit_picture').on(
                'change',
                function() {

                    const file =
                        this.files[0];


                    if (!file) {
                        return;
                    }


                    const reader =
                        new FileReader();


                    reader.onload =
                        function(event) {

                            $('#editPicturePreview')
                                .attr(
                                    'src',
                                    event.target.result
                                )
                                .show();


                            $('#editPicturePlaceholder')
                                .hide();

                        };


                    reader.readAsDataURL(file);

                }
            );



            /*
            |--------------------------------------------------------------------------
            | RESET ADD MODAL
            |--------------------------------------------------------------------------
            */

            $('#addResourceModal').on(
                'hidden.bs.modal',
                function() {

                    const form =
                        document.getElementById(
                            'addResourceForm'
                        );


                    if (form) {
                        form.reset();
                    }


                    $('#addPicturePreview')
                        .hide()
                        .attr(
                            'src',
                            ''
                        );


                    $('#addPicturePlaceholder')
                        .show();


                    const firstTab =
                        document.querySelector(
                            '#addResourceModal [data-bs-target="#addResourceInformation"]'
                        );


                    if (firstTab) {

                        bootstrap.Tab
                            .getOrCreateInstance(
                                firstTab
                            )
                            .show();

                    }

                }
            );



            /*
            |--------------------------------------------------------------------------
            | RESET EDIT MODAL
            |--------------------------------------------------------------------------
            */

            $('#editResourceModal').on(
                'hidden.bs.modal',
                function() {

                    $('#edit_picture').val('');


                    const firstTab =
                        document.querySelector(
                            '#editResourceModal [data-bs-target="#editResourceInformation"]'
                        );


                    if (firstTab) {

                        bootstrap.Tab
                            .getOrCreateInstance(
                                firstTab
                            )
                            .show();

                    }

                }
            );



            /*
            |--------------------------------------------------------------------------
            | VALIDATE IMAGE SIZE
            |--------------------------------------------------------------------------
            */

            $('#add_picture, #edit_picture').on(
                'change',
                function() {

                    const file =
                        this.files[0];


                    if (!file) {
                        return;
                    }


                    const maxSize =
                        5 * 1024 * 1024;


                    if (file.size > maxSize) {

                        alert(
                            'Picture must not exceed 5 MB.'
                        );


                        $(this).val('');

                    }

                }
            );

        });
    </script>



    <!-- ============================================================
     TOAST JAVASCRIPT
============================================================ -->

    <script>
        $(document).ready(function() {


            const successToast =
                document.getElementById(
                    'successToast'
                );


            if (successToast) {

                const toast =
                    bootstrap.Toast.getOrCreateInstance(
                        successToast, {
                            delay: 4000
                        }
                    );


                toast.show();

            }


            const errorToast =
                document.getElementById(
                    'errorToast'
                );


            if (errorToast) {

                const toast =
                    bootstrap.Toast.getOrCreateInstance(
                        errorToast, {
                            delay: 5000
                        }
                    );


                toast.show();

            }

        });
    </script>


</body>

</html>