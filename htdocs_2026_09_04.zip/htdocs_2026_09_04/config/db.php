<?php
$hostname = 'localhost';
$database = 'b11_40994659_booksystem';
$username = 'root';
$password = '';
$dsn = "mysql:host=$hostname;dbname=$database;charset=utf8mb4";

try {
    $connect = new PDO($dsn, $username, $password);
} catch (PDOException $e) {
    die("DB Error: " . $e->getMessage());
}

session_start();
