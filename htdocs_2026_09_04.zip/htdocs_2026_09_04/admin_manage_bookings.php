<?php

require 'config/db.php';

/*
|--------------------------------------------------------------------------
| Session
|--------------------------------------------------------------------------
*/
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}


/*
|--------------------------------------------------------------------------
| Admin authorization
|--------------------------------------------------------------------------
*/
if (
    !isset($_SESSION['user']) ||
    !isset($_SESSION['user']['role']) ||
    $_SESSION['user']['role'] !== 'Admin'
) {
    header("Location: login.php");
    exit;
}


/*
|--------------------------------------------------------------------------
| Helper function
|--------------------------------------------------------------------------
*/
function e($value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}


/*
|--------------------------------------------------------------------------
| CSRF token
|--------------------------------------------------------------------------
*/
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(
        random_bytes(32)
    );
}

$csrfToken = $_SESSION['csrf_token'];


/*
|--------------------------------------------------------------------------
| Flash message helper
|--------------------------------------------------------------------------
*/
function setFlash(
    string $type,
    string $message
): void {

    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message
    ];
}


/*
|--------------------------------------------------------------------------
| Redirect helper
|--------------------------------------------------------------------------
|
| Always redirect back to this same page.
|
*/
function redirectToBookings(): never
{
    $currentPage = strtok(
        $_SERVER['REQUEST_URI'],
        '?'
    );

    if (!$currentPage) {
        $currentPage = $_SERVER['PHP_SELF'];
    }

    header(
        "Location: " . $currentPage
    );

    exit;
}


/*
|--------------------------------------------------------------------------
| Handle POST requests
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {


    /*
    |--------------------------------------------------------------------------
    | CSRF validation
    |--------------------------------------------------------------------------
    */
    $submittedToken =
        $_POST['csrf_token'] ?? '';


    if (
        empty($submittedToken) ||
        !hash_equals(
            $_SESSION['csrf_token'],
            $submittedToken
        )
    ) {

        setFlash(
            'danger',
            'Invalid security token. Please try again.'
        );

        redirectToBookings();
    }


    /*
    |--------------------------------------------------------------------------
    | Get POST data
    |--------------------------------------------------------------------------
    */
    $action =
        $_POST['action'] ?? '';


    $bookingId =
        filter_var(
            $_POST['booking_id'] ?? '',
            FILTER_VALIDATE_INT
        );


    /*
    |--------------------------------------------------------------------------
    | Validate booking ID
    |--------------------------------------------------------------------------
    */
    if (!$bookingId) {

        setFlash(
            'danger',
            'Invalid booking selected.'
        );

        redirectToBookings();
    }


    /*
    |--------------------------------------------------------------------------
    | Allowed actions
    |--------------------------------------------------------------------------
    */
    $allowedActions = [
        'approved',
        'rejected',
        'cancelled'
    ];


    if (
        !in_array(
            $action,
            $allowedActions,
            true
        )
    ) {

        setFlash(
            'danger',
            'Invalid booking action.'
        );

        redirectToBookings();
    }


    /*
    |--------------------------------------------------------------------------
    | Process booking
    |--------------------------------------------------------------------------
    */
    try {


        /*
        |--------------------------------------------------------------------------
        | Check booking exists
        |--------------------------------------------------------------------------
        */
        $checkBooking =
            $connect->prepare(
                "SELECT
                    booking_id,
                    status
                 FROM bookings
                 WHERE booking_id = ?
                 LIMIT 1"
            );


        $checkBooking->execute([
            $bookingId
        ]);


        $booking =
            $checkBooking->fetch(
                PDO::FETCH_ASSOC
            );


        /*
        |--------------------------------------------------------------------------
        | Booking not found
        |--------------------------------------------------------------------------
        */
        if (!$booking) {

            setFlash(
                'danger',
                'The selected booking could not be found.'
            );

            redirectToBookings();
        }


        /*
        |--------------------------------------------------------------------------
        | Current status
        |--------------------------------------------------------------------------
        */
        $currentStatus =
            $booking['status'];


        /*
        |--------------------------------------------------------------------------
        | Approve
        |--------------------------------------------------------------------------
        */
        if ($action === 'approved') {

            if (
                $currentStatus !== 'pending'
            ) {

                setFlash(
                    'danger',
                    'Only pending bookings can be approved.'
                );

                redirectToBookings();
            }
        }


        /*
        |--------------------------------------------------------------------------
        | Reject
        |--------------------------------------------------------------------------
        */
        if ($action === 'rejected') {

            if (
                $currentStatus !== 'pending'
            ) {

                setFlash(
                    'danger',
                    'Only pending bookings can be rejected.'
                );

                redirectToBookings();
            }
        }


        /*
        |--------------------------------------------------------------------------
        | Cancel
        |--------------------------------------------------------------------------
        */
        if ($action === 'cancelled') {

            if (
                !in_array(
                    $currentStatus,
                    [
                        'pending',
                        'approved'
                    ],
                    true
                )
            ) {

                setFlash(
                    'danger',
                    'This booking cannot be cancelled.'
                );

                redirectToBookings();
            }
        }


        /*
        |--------------------------------------------------------------------------
        | Update booking
        |--------------------------------------------------------------------------
        */
        $stmt =
            $connect->prepare(
                "UPDATE bookings
                 SET status = ?
                 WHERE booking_id = ?"
            );


        $stmt->execute([
            $action,
            $bookingId
        ]);


        /*
        |--------------------------------------------------------------------------
        | Success messages
        |--------------------------------------------------------------------------
        */
        $messages = [

            'approved' =>
            'Booking approved successfully.',

            'rejected' =>
            'Booking rejected successfully.',

            'cancelled' =>
            'Booking cancelled successfully.'

        ];


        setFlash(
            'success',
            $messages[$action]
        );
    } catch (PDOException $e) {


        /*
        |--------------------------------------------------------------------------
        | Log error
        |--------------------------------------------------------------------------
        */
        error_log(
            $e->getMessage()
        );


        setFlash(
            'danger',
            'Unable to update the booking. Please try again.'
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Return to same page
    |--------------------------------------------------------------------------
    */
    redirectToBookings();
}


/*
|--------------------------------------------------------------------------
| Flash message
|--------------------------------------------------------------------------
*/
$flash =
    $_SESSION['flash'] ?? null;


unset(
    $_SESSION['flash']
);


/*
|--------------------------------------------------------------------------
| Fetch bookings
|--------------------------------------------------------------------------
*/
try {

    $stmt =
        $connect->query(
            "SELECT
                b.booking_id,
                b.booking_date,
                b.start_time,
                b.end_time,
                b.purpose,
                b.status,
                u.employee_no,
                r.resource_name

             FROM bookings b

             INNER JOIN employees u
                ON b.user_id = u.employee_id

             INNER JOIN resources r
                ON b.resource_id = r.resource_id

             ORDER BY
                b.booking_date DESC,
                b.start_time DESC,
                b.booking_id DESC"
        );


    $bookings =
        $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
} catch (PDOException $e) {


    error_log(
        $e->getMessage()
    );


    $bookings = [];


    $flash = [
        'type' => 'danger',
        'message' => 'Unable to load bookings.'
    ];
}

?>

<!DOCTYPE html>

<html lang="en">


<head>


    <title>
        Resource Booking : Nkanyiso Consulting
    </title>


    <meta charset="utf-8">


    <meta
        name="viewport"
        content="width=device-width, initial-scale=1">


    <?php include 'includes/header.php'; ?>


</head>


<body>


    <div class="container mt-5">


        <?php include 'includes/navbar.php'; ?>


        <!-- =========================================================
         PAGE HEADING
    ========================================================== -->

        <div
            class="d-flex justify-content-between align-items-center mb-3 add-bookings">


            <h4 class="mb-0">

                <i class="bi bi-calendar-check-fill"></i>

                Manage Bookings

            </h4>


            <button
                type="button"
                class="btn btn-success"
                data-bs-toggle="modal"
                data-bs-target="#addUserModal">

                <i class="bi bi-calendar-check-fill"></i>

                Add Booking

            </button>


        </div>


        <!-- =========================================================
         FLASH
    ========================================================== -->

        <?php if ($flash): ?>


            <div
                class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show"
                role="alert">


                <?= e(
                    $flash['message']
                ); ?>


                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="alert"
                    aria-label="Close"></button>


            </div>


        <?php endif; ?>


        <!-- =========================================================
         BOOKINGS TABLE
    ========================================================== -->

        <div class="card shadow-sm">


            <div class="card-body">


                <div class="table-responsive">


                    <table
                        class="table table-bordered table-striped table-hover align-middle"
                        id="bookings_table"
                        style="width: 100%;">


                        <colgroup>

                            <col style="width: 4%;">

                            <col style="width: 18%;">

                            <col style="width: 10%;">

                            <col style="width: 12%;">

                            <col style="width: 26%;">

                            <col style="width: 10%;">

                            <col style="width: 10%;">

                            <col style="width: 10%;">

                        </colgroup>


                        <thead class="table-dark">


                            <tr>


                                <th>
                                    No.
                                </th>


                                <th>
                                    Resource Name
                                </th>


                                <th>
                                    Date
                                </th>


                                <th>
                                    Time
                                </th>


                                <th>
                                    Purpose
                                </th>


                                <th>
                                    Booked By
                                </th>


                                <th>
                                    Status
                                </th>


                                <th>
                                    Actions
                                </th>


                            </tr>


                        </thead>


                        <tbody>


                            <?php if (!empty($bookings)): ?>


                                <?php
                                $count = 1;
                                ?>


                                <?php foreach ($bookings as $booking): ?>


                                    <?php


                                    /*
                            |--------------------------------------------------------------------------
                            | Status class
                            |--------------------------------------------------------------------------
                            */
                                    $statusClass =
                                        match ($booking['status']) {

                                            'pending' =>
                                            'warning text-dark',

                                            'approved' =>
                                            'success',

                                            'rejected' =>
                                            'danger',

                                            'cancelled' =>
                                            'secondary',

                                            default =>
                                            'dark'
                                        };


                                    /*
                            |--------------------------------------------------------------------------
                            | Status text
                            |--------------------------------------------------------------------------
                            */
                                    $statusText =
                                        ucfirst(
                                            $booking['status']
                                        );


                                    /*
                            |--------------------------------------------------------------------------
                            | Approve / Reject
                            |--------------------------------------------------------------------------
                            */
                                    $canApproveReject =
                                        $booking['status'] === 'pending';


                                    /*
                            |--------------------------------------------------------------------------
                            | Cancel
                            |--------------------------------------------------------------------------
                            */
                                    $canCancel =
                                        in_array(
                                            $booking['status'],
                                            [
                                                'pending',
                                                'approved'
                                            ],
                                            true
                                        );


                                    ?>


                                    <tr>


                                        <td>

                                            <strong>
                                                <?= $count++; ?>
                                            </strong>

                                        </td>


                                        <td>

                                            <?= e(
                                                $booking['resource_name']
                                            ); ?>

                                        </td>


                                        <td>

                                            <?= e(
                                                date(
                                                    'Y-m-d',
                                                    strtotime(
                                                        $booking['booking_date']
                                                    )
                                                )
                                            ); ?>

                                        </td>


                                        <td>

                                            <?= e(
                                                date(
                                                    'H:i',
                                                    strtotime(
                                                        $booking['start_time']
                                                    )
                                                )
                                            ); ?>

                                            -

                                            <?= e(
                                                date(
                                                    'H:i',
                                                    strtotime(
                                                        $booking['end_time']
                                                    )
                                                )
                                            ); ?>

                                        </td>


                                        <td>

                                            <?= e(
                                                $booking['purpose']
                                            ); ?>

                                        </td>


                                        <td>

                                            <?= e(
                                                $booking['employee_no']
                                            ); ?>

                                        </td>


                                        <td>

                                            <span
                                                class="badge bg-<?= e($statusClass) ?>">

                                                <?= e(
                                                    $statusText
                                                ); ?>

                                            </span>

                                        </td>


                                        <td class="text-nowrap">


                                            <!-- =================================================
                                         APPROVE
                                    ================================================== -->

                                            <form
                                                method="post"
                                                class="d-inline bookingActionForm">


                                                <input
                                                    type="hidden"
                                                    name="csrf_token"
                                                    value="<?= e($csrfToken); ?>">


                                                <input
                                                    type="hidden"
                                                    name="booking_id"
                                                    value="<?= e($booking['booking_id']); ?>">


                                                <input
                                                    type="hidden"
                                                    name="action"
                                                    value="approved">


                                                <button
                                                    type="submit"
                                                    class="btn btn-success btn-sm"
                                                    title="Approve"
                                                    <?= !$canApproveReject ? 'disabled' : ''; ?>>


                                                    <i class="bi bi-check-circle"></i>


                                                </button>


                                            </form>


                                            <!-- =================================================
                                         REJECT
                                    ================================================== -->

                                            <form
                                                method="post"
                                                class="d-inline bookingActionForm">


                                                <input
                                                    type="hidden"
                                                    name="csrf_token"
                                                    value="<?= e($csrfToken); ?>">


                                                <input
                                                    type="hidden"
                                                    name="booking_id"
                                                    value="<?= e($booking['booking_id']); ?>">


                                                <input
                                                    type="hidden"
                                                    name="action"
                                                    value="rejected">


                                                <button
                                                    type="submit"
                                                    class="btn btn-danger btn-sm"
                                                    title="Reject"
                                                    <?= !$canApproveReject ? 'disabled' : ''; ?>>


                                                    <i class="bi bi-x-circle"></i>


                                                </button>


                                            </form>


                                            <!-- =================================================
                                         CANCEL
                                    ================================================== -->

                                            <form
                                                method="post"
                                                class="d-inline bookingActionForm">


                                                <input
                                                    type="hidden"
                                                    name="csrf_token"
                                                    value="<?= e($csrfToken); ?>">


                                                <input
                                                    type="hidden"
                                                    name="booking_id"
                                                    value="<?= e($booking['booking_id']); ?>">


                                                <input
                                                    type="hidden"
                                                    name="action"
                                                    value="cancelled">


                                                <button
                                                    type="submit"
                                                    class="btn btn-secondary btn-sm"
                                                    title="Cancel"
                                                    <?= !$canCancel ? 'disabled' : ''; ?>>


                                                    <i class="bi bi-x"></i>


                                                </button>


                                            </form>


                                        </td>


                                    </tr>


                                <?php endforeach; ?>


                            <?php endif; ?>


                        </tbody>


                    </table>


                </div>


            </div>


        </div>


        <br>


        <!-- =========================================================
         FOOTER
    ========================================================== -->

        <div class="site-footer">

            <?php include 'includes/footer.php'; ?>

        </div>


    </div>


    <!-- ============================================================
     JAVASCRIPT
============================================================ -->

    <script>
        $(document).ready(function() {


            /*
            |--------------------------------------------------------------------------
            | DataTables
            |--------------------------------------------------------------------------
            */

            const table =
                $('#bookings_table').DataTable({

                    /*
                    |--------------------------------------------------------------------------
                    | Rows per page
                    |--------------------------------------------------------------------------
                    */

                    pageLength: 10,


                    /*
                    |--------------------------------------------------------------------------
                    | IMPORTANT
                    |--------------------------------------------------------------------------
                    |
                    | DataTables automatically remembers:
                    |
                    | - Current page
                    | - Search
                    | - Sorting
                    | - Page length
                    |
                    | after the page reloads.
                    |
                    */

                    stateSave: true,


                    /*
                    |--------------------------------------------------------------------------
                    | State duration
                    |--------------------------------------------------------------------------
                    |
                    | 7200 seconds = 2 hours.
                    |
                    */

                    stateDuration: 7200,


                    /*
                    |--------------------------------------------------------------------------
                    | Disable sorting
                    |--------------------------------------------------------------------------
                    */

                    ordering: false,


                    /*
                    |--------------------------------------------------------------------------
                    | Searching
                    |--------------------------------------------------------------------------
                    */

                    searching: true,


                    /*
                    |--------------------------------------------------------------------------
                    | Pagination
                    |--------------------------------------------------------------------------
                    */

                    paging: true,


                    /*
                    |--------------------------------------------------------------------------
                    | Pagination type
                    |--------------------------------------------------------------------------
                    */

                    pagingType: 'full_numbers',


                    /*
                    |--------------------------------------------------------------------------
                    | Information
                    |--------------------------------------------------------------------------
                    */

                    info: true,


                    /*
                    |--------------------------------------------------------------------------
                    | Layout
                    |--------------------------------------------------------------------------
                    */

                    dom: 'frtip',


                    /*
                    |--------------------------------------------------------------------------
                    | Language
                    |--------------------------------------------------------------------------
                    */

                    language: {

                        emptyTable: 'No bookings found.',

                        zeroRecords: 'No matching bookings found.',

                        info: 'Showing _START_ to _END_ of _TOTAL_ bookings',

                        infoEmpty: 'Showing 0 to 0 of 0 bookings',

                        paginate: {

                            first: '«',

                            previous: '‹',

                            next: '›',

                            last: '»'

                        }

                    },


                    /*
                    |--------------------------------------------------------------------------
                    | Actions column
                    |--------------------------------------------------------------------------
                    */

                    columnDefs: [

                        {
                            orderable: false,
                            targets: 7
                        }

                    ]

                });


            /*
            |--------------------------------------------------------------------------
            | Custom search input
            |--------------------------------------------------------------------------
            */

            $('#searchInput').on(
                'keyup input',
                function() {

                    const value =
                        this.value;


                    table
                        .search(value)
                        .draw();


                    $('#clearBtn').toggle(
                        value.length > 0
                    );

                }
            );


            /*
            |--------------------------------------------------------------------------
            | Search button
            |--------------------------------------------------------------------------
            */

            $('#searchBtn').on(
                'click',
                function() {

                    const value =
                        $('#searchInput').val();


                    table
                        .search(value)
                        .draw();


                    $('#clearBtn').toggle(
                        value.length > 0
                    );

                }
            );


            /*
            |--------------------------------------------------------------------------
            | ENTER in search
            |--------------------------------------------------------------------------
            */

            $('#searchInput').on(
                'keypress',
                function(event) {

                    if (event.which === 13) {

                        event.preventDefault();


                        const value =
                            this.value;


                        table
                            .search(value)
                            .draw();

                    }

                }
            );


            /*
            |--------------------------------------------------------------------------
            | Clear search
            |--------------------------------------------------------------------------
            */

            $('#clearBtn').on(
                'click',
                function() {

                    $('#searchInput')
                        .val('');


                    table
                        .search('')
                        .draw();


                    $(this).hide();


                    $('#searchInput')
                        .focus();

                }
            );


            /*
            |--------------------------------------------------------------------------
            | Booking action confirmation
            |--------------------------------------------------------------------------
            */

            $('.bookingActionForm').on(
                'submit',
                function(event) {


                    const form = this;


                    const action =
                        $(form)
                        .find(
                            'input[name="action"]'
                        )
                        .val();


                    let message = '';


                    /*
                    |--------------------------------------------------------------------------
                    | Approve
                    |--------------------------------------------------------------------------
                    */

                    if (
                        action === 'approved'
                    ) {

                        message =
                            'Are you sure you want to approve this booking?';

                    }


                    /*
                    |--------------------------------------------------------------------------
                    | Reject
                    |--------------------------------------------------------------------------
                    */

                    if (
                        action === 'rejected'
                    ) {

                        message =
                            'Are you sure you want to reject this booking?';

                    }


                    /*
                    |--------------------------------------------------------------------------
                    | Cancel
                    |--------------------------------------------------------------------------
                    */

                    if (
                        action === 'cancelled'
                    ) {

                        message =
                            'Are you sure you want to cancel this booking?';

                    }


                    /*
                    |--------------------------------------------------------------------------
                    | Confirmation
                    |--------------------------------------------------------------------------
                    */

                    if (
                        message !== '' &&
                        !confirm(message)
                    ) {

                        event.preventDefault();

                        return;

                    }


                    /*
                    |--------------------------------------------------------------------------
                    | IMPORTANT
                    |--------------------------------------------------------------------------
                    |
                    | Force DataTables to save its current state before
                    | the browser submits the form.
                    |
                    */

                    table
                        .state
                        .save();

                }
            );


        });
    </script>


</body>

</html>