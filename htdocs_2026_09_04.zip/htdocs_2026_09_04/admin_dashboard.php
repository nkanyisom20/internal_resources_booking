<?php

require 'config/db.php';


/*
|--------------------------------------------------------------------------
| SESSION
|--------------------------------------------------------------------------
*/

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


/*
|--------------------------------------------------------------------------
| ADMIN AUTHORIZATION
|--------------------------------------------------------------------------
*/

if (
    !isset($_SESSION['user']) ||
    !isset($_SESSION['user']['role']) ||
    $_SESSION['user']['role'] !== 'Admin'
) {
    header("Location: login.php");
    exit;
}


/*
|--------------------------------------------------------------------------
| HELPER
|--------------------------------------------------------------------------
*/

function e($value): string
{
    return htmlspecialchars(
        (string)($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}


/*
|--------------------------------------------------------------------------
| FETCH BOOKINGS
|--------------------------------------------------------------------------
|
| IMPORTANT:
|
| LEFT JOIN employees is used instead of INNER JOIN.
|
| This prevents bookings from disappearing if bookings.user_id
| does not currently have a matching employee_id.
|
|--------------------------------------------------------------------------
*/

$sql = " SELECT b.booking_id, b.user_id, b.resource_id, b.booking_date, b.start_time, b.end_time, b.purpose, b.status, r.resource_name, r.picture, e.employee_no, e.surname, e.fullnames, e.email_address
    FROM bookings AS b INNER JOIN resources AS r ON b.resource_id = r.resource_id LEFT JOIN employees AS e ON b.user_id = e.employee_id ORDER BY b.booking_date ASC, b.start_time ASC";


try {

    $stmt = $connect->query($sql);

    $bookings = $stmt->fetchAll(
        PDO::FETCH_ASSOC
    );
} catch (PDOException $ex) {

    error_log(
        'Manage Bookings SQL Error: ' .
            $ex->getMessage()
    );

    $bookings = [];
}


/*
|--------------------------------------------------------------------------
| CONVERT BOOKINGS TO FULLCALENDAR EVENTS
|--------------------------------------------------------------------------
*/

$events = [];


foreach ($bookings as $booking) {


    /*
    |--------------------------------------------------------------------------
    | BOOKING DATE
    |--------------------------------------------------------------------------
    */

    $bookingDate = trim(
        $booking['booking_date'] ?? ''
    );


    /*
    |--------------------------------------------------------------------------
    | START TIME
    |--------------------------------------------------------------------------
    */

    $startTime = trim(
        $booking['start_time'] ?? ''
    );


    /*
    |--------------------------------------------------------------------------
    | END TIME
    |--------------------------------------------------------------------------
    */

    $endTime = trim(
        $booking['end_time'] ?? ''
    );


    /*
    |--------------------------------------------------------------------------
    | STATUS
    |--------------------------------------------------------------------------
    */

    $status = strtolower(
        trim(
            $booking['status'] ?? ''
        )
    );


    /*
    |--------------------------------------------------------------------------
    | IGNORE INVALID DATE
    |--------------------------------------------------------------------------
    */

    if (
        $bookingDate === '' ||
        $bookingDate === '0000-00-00'
    ) {
        continue;
    }


    /*
    |--------------------------------------------------------------------------
    | VALIDATE DATE
    |--------------------------------------------------------------------------
    */

    $dateObject = DateTime::createFromFormat(
        'Y-m-d',
        $bookingDate
    );


    if (
        !$dateObject ||
        $dateObject->format('Y-m-d') !== $bookingDate
    ) {
        continue;
    }


    /*
    |--------------------------------------------------------------------------
    | VALIDATE TIME
    |--------------------------------------------------------------------------
    */

    if (
        $startTime === '' ||
        $endTime === ''
    ) {
        continue;
    }


    /*
    |--------------------------------------------------------------------------
    | CREATE DATETIME
    |--------------------------------------------------------------------------
    */

    $startDateTime =
        $bookingDate . 'T' . $startTime;

    $endDateTime =
        $bookingDate . 'T' . $endTime;


    /*
    |--------------------------------------------------------------------------
    | BOOKING COLOR
    |--------------------------------------------------------------------------
    */

    switch ($status) {

        case 'pending':

            $color = '#f59e0b';

            break;


        case 'approved':

            $color = '#198754';

            break;


        case 'rejected':

            $color = '#dc3545';

            break;


        case 'cancelled':

            $color = '#6c757d';

            break;


        default:

            $color = '#0d6efd';

            break;
    }


    /*
    |--------------------------------------------------------------------------
    | RESOURCE NAME
    |--------------------------------------------------------------------------
    */

    $resourceName = trim(
        $booking['resource_name'] ?? ''
    );


    if ($resourceName === '') {

        $resourceName = 'Resource';
    }


    /*
    |--------------------------------------------------------------------------
    | PURPOSE
    |--------------------------------------------------------------------------
    */

    $purpose = trim(
        $booking['purpose'] ?? ''
    );


    /*
    |--------------------------------------------------------------------------
    | BOOKED BY
    |--------------------------------------------------------------------------
    |
    | Employee table:
    |
    | surname
    | fullnames
    |
    |--------------------------------------------------------------------------
    */

    $surname = trim(
        $booking['surname'] ?? ''
    );


    $fullnames = trim(
        $booking['fullnames'] ?? ''
    );


    $employeeNo = trim(
        $booking['employee_no'] ?? ''
    );


    $emailAddress = trim(
        $booking['email_address'] ?? ''
    );


    /*
    |--------------------------------------------------------------------------
    | CREATE EMPLOYEE NAME
    |--------------------------------------------------------------------------
    */

    $bookedBy = trim(
        $surname . ' ' . $fullnames
    );


    /*
    |--------------------------------------------------------------------------
    | FALLBACK IF NO EMPLOYEE MATCH
    |--------------------------------------------------------------------------
    */

    if ($bookedBy === '') {

        if ($employeeNo !== '') {

            $bookedBy =
                'Employee No. ' .
                $employeeNo;
        } else {

            $bookedBy =
                'Unknown Employee';
        }
    }


    /*
    |--------------------------------------------------------------------------
    | EVENT TITLE
    |--------------------------------------------------------------------------
    */

    $title = $resourceName;


    if ($purpose !== '') {

        $title .=
            ' - ' . $purpose;
    }


    /*
    |--------------------------------------------------------------------------
    | STATUS IN EVENT TITLE
    |--------------------------------------------------------------------------
    */

    if ($status !== '') {

        $title .=
            ' (' .
            ucfirst($status) .
            ')';
    }


    /*
    |--------------------------------------------------------------------------
    | RESOURCE PICTURE
    |--------------------------------------------------------------------------
    */

    $picture = trim(
        $booking['picture'] ?? ''
    );


    /*
    |--------------------------------------------------------------------------
    | CREATE FULLCALENDAR EVENT
    |--------------------------------------------------------------------------
    */

    $events[] = [

        'id' =>
        (string)$booking['booking_id'],


        'title' =>
        $title,


        'start' =>
        $startDateTime,


        'end' =>
        $endDateTime,


        'backgroundColor' =>
        $color,


        'borderColor' =>
        $color,


        'textColor' =>
        '#ffffff',


        /*
        |--------------------------------------------------------------------------
        | EXTENDED PROPERTIES
        |--------------------------------------------------------------------------
        */

        'extendedProps' => [

            'resource_name' =>
            $resourceName,


            'picture' =>
            $picture,


            'booking_date' =>
            $booking['booking_date'],


            'start_time' =>
            $booking['start_time'],


            'end_time' =>
            $booking['end_time'],


            'purpose' =>
            $booking['purpose'],


            'status' =>
            ucfirst($status),


            /*
            |--------------------------------------------------------------------------
            | BOOKED BY
            |--------------------------------------------------------------------------
            */

            'booked_by' =>
            $bookedBy,


            'employee_no' =>
            $employeeNo,


            'email_address' =>
            $emailAddress

        ]

    ];
}

?>


<!DOCTYPE html>

<html lang="en">


<head>

    <meta charset="UTF-8">


    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">


    <title>
        Manage Bookings : Nkanyiso Consulting
    </title>


    <?php include 'includes/header.php'; ?>


    <style>
        /*
|--------------------------------------------------------------------------
| PAGE
|--------------------------------------------------------------------------
*/

        /*
|--------------------------------------------------------------------------
| PAGE
|--------------------------------------------------------------------------
*/

        body {

            background-color:
                #f8f9fa;

        }


        /*
|--------------------------------------------------------------------------
| PAGE HEADER
|--------------------------------------------------------------------------
*/

        .booking-page-header {

            margin-bottom:
                20px;

        }


        .booking-page-header h4 {

            margin-bottom:
                5px;

            font-weight:
                600;

        }


        /*
|--------------------------------------------------------------------------
| CALENDAR CONTAINER
|--------------------------------------------------------------------------
*/

        .calendar-container {

            background:
                #ffffff;

            padding:
                20px;

            border-radius:
                12px;

            box-shadow:
                0 2px 10px rgba(0, 0, 0, 0.08);

        }


        /*
|--------------------------------------------------------------------------
| LEGEND
|--------------------------------------------------------------------------
*/

        .legend {

            display:
                flex;

            flex-wrap:
                wrap;

            gap:
                20px;

            margin-bottom:
                20px;

        }


        .legend-item {

            display:
                flex;

            align-items:
                center;

            gap:
                7px;

            font-size:
                14px;

        }


        .legend-dot {

            width:
                14px;

            height:
                14px;

            border-radius:
                50%;

            display:
                inline-block;

        }


        /*
|--------------------------------------------------------------------------
| LEGEND COLORS
|--------------------------------------------------------------------------
*/

        .legend-pending {

            background-color:
                #f59e0b;

        }


        .legend-approved {

            background-color:
                #198754;

        }


        .legend-rejected {

            background-color:
                #dc3545;

        }


        .legend-cancelled {

            background-color:
                #6c757d;

        }


        .legend-other {

            background-color:
                #0d6efd;

        }


        /*
|--------------------------------------------------------------------------
| CALENDAR
|--------------------------------------------------------------------------
*/

        #calendar {

            min-height:
                0 !important;

            height:
                auto !important;

        }


        /*
|--------------------------------------------------------------------------
| COMPACT CALENDAR DAY CELLS
|--------------------------------------------------------------------------
*/

        #calendar .fc-daygrid-day {

            height:
                auto !important;

        }


        #calendar .fc-daygrid-day-frame {

            min-height:
                45px !important;

            height:
                45px !important;

        }


        /*
|--------------------------------------------------------------------------
| PREVENT FULLCALENDAR FROM STRETCHING THE GRID
|--------------------------------------------------------------------------
*/

        #calendar .fc-daygrid-body {

            min-height:
                0 !important;

        }


        #calendar .fc-daygrid-body,

        #calendar .fc-daygrid-body table,

        #calendar .fc-scrollgrid-sync-table {

            height:
                auto !important;

        }


        /*
|--------------------------------------------------------------------------
| DAY NUMBER
|--------------------------------------------------------------------------
*/

        #calendar .fc-daygrid-day-number {

            padding:
                4px !important;

            font-size:
                11px;

        }


        /*
|--------------------------------------------------------------------------
| FULLCALENDAR EVENTS
|--------------------------------------------------------------------------
*/

        #calendar .fc-event {

            cursor:
                pointer;

            border-radius:
                5px !important;

            border-width:
                1px !important;

            padding:
                3px 5px !important;

            margin:
                2px 3px !important;

            font-weight:
                600 !important;

        }


        /*
|--------------------------------------------------------------------------
| REMOVE DEFAULT DOT
|--------------------------------------------------------------------------
*/

        #calendar .fc-daygrid-event-dot {

            display:
                none !important;

        }


        /*
|--------------------------------------------------------------------------
| EVENT TEXT
|--------------------------------------------------------------------------
*/

        #calendar .fc-event-title,

        #calendar .fc-event-time,

        #calendar .fc-event-main {

            color:
                #ffffff !important;

            font-weight:
                600 !important;

        }


        /*
|--------------------------------------------------------------------------
| PENDING
|--------------------------------------------------------------------------
*/

        #calendar .booking-pending {

            background-color:
                #f59e0b !important;

            border-color:
                #f59e0b !important;

            color:
                #ffffff !important;

        }


        /*
|--------------------------------------------------------------------------
| APPROVED
|--------------------------------------------------------------------------
*/

        #calendar .booking-approved {

            background-color:
                #198754 !important;

            border-color:
                #198754 !important;

            color:
                #ffffff !important;

        }


        /*
|--------------------------------------------------------------------------
| REJECTED
|--------------------------------------------------------------------------
*/

        #calendar .booking-rejected {

            background-color:
                #dc3545 !important;

            border-color:
                #dc3545 !important;

            color:
                #ffffff !important;

        }


        /*
|--------------------------------------------------------------------------
| CANCELLED
|--------------------------------------------------------------------------
*/

        #calendar .booking-cancelled {

            background-color:
                #6c757d !important;

            border-color:
                #6c757d !important;

            color:
                #ffffff !important;

        }


        /*
|--------------------------------------------------------------------------
| OTHER
|--------------------------------------------------------------------------
*/

        #calendar .booking-other {

            background-color:
                #0d6efd !important;

            border-color:
                #0d6efd !important;

            color:
                #ffffff !important;

        }


        /*
|--------------------------------------------------------------------------
| BOOKING DETAIL ROW
|--------------------------------------------------------------------------
*/

        .booking-detail {

            margin-bottom:
                0;

            padding:
                12px 0;

            border-bottom:
                1px solid #eeeeee;

        }


        .booking-detail:last-child {

            border-bottom:
                none;

        }


        .booking-detail strong {

            display:
                inline-block;

            min-width:
                120px;

            color:
                #343a40;

        }


        /*
|--------------------------------------------------------------------------
| RESOURCE PICTURE
|--------------------------------------------------------------------------
*/

        .booking-resource-picture {

            width:
                100%;

            max-height:
                250px;

            object-fit:
                cover;

            border-radius:
                8px;

            margin-bottom:
                15px;

        }


        /*
|--------------------------------------------------------------------------
| BOOKED BY
|--------------------------------------------------------------------------
*/

        #modalBookedBy {

            font-weight:
                600;

            color:
                #212529;

        }


        /*
|--------------------------------------------------------------------------
| STATUS
|--------------------------------------------------------------------------
*/

        #modalStatus {

            padding:
                6px 12px;

            border-radius:
                6px;

            font-weight:
                600;

            display:
                inline-block;

        }


        /*
|--------------------------------------------------------------------------
| STATUS - PENDING
|--------------------------------------------------------------------------
*/

        #modalStatus.status-pending {

            background-color:
                #f59e0b !important;

            color:
                #212529 !important;

        }


        /*
|--------------------------------------------------------------------------
| STATUS - APPROVED
|--------------------------------------------------------------------------
*/

        #modalStatus.status-approved {

            background-color:
                #198754 !important;

            color:
                #ffffff !important;

        }


        /*
|--------------------------------------------------------------------------
| STATUS - REJECTED
|--------------------------------------------------------------------------
*/

        #modalStatus.status-rejected {

            background-color:
                #dc3545 !important;

            color:
                #ffffff !important;

        }


        /*
|--------------------------------------------------------------------------
| STATUS - CANCELLED
|--------------------------------------------------------------------------
*/

        #modalStatus.status-cancelled {

            background-color:
                #6c757d !important;

            color:
                #ffffff !important;

        }


        /*
|--------------------------------------------------------------------------
| STATUS - OTHER
|--------------------------------------------------------------------------
*/

        #modalStatus.status-other {

            background-color:
                #0d6efd !important;

            color:
                #ffffff !important;

        }


        /*
|--------------------------------------------------------------------------
| MODAL
|--------------------------------------------------------------------------
*/

        .modal {

            z-index:
                1060 !important;

            position:
                fixed !important;

        }


        .modal-backdrop {

            z-index:
                1050 !important;

            opacity:
                0.5 !important;

        }


        .modal-dialog {

            filter:
                none !important;

            backdrop-filter:
                none !important;

        }


        .modal-content {

            background-color:
                #ffffff !important;

            opacity:
                1 !important;

            filter:
                none !important;

            backdrop-filter:
                none !important;

        }


        /*
|--------------------------------------------------------------------------
| MODAL HEADER
|--------------------------------------------------------------------------
*/

        #bookingModal .modal-header {

            border-top:
                5px solid #0d6efd;

            transition:
                border-color 0.2s ease;

        }


        /*
|--------------------------------------------------------------------------
| MOBILE
|--------------------------------------------------------------------------
*/

        @media (max-width: 768px) {

            .calendar-container {

                padding:
                    10px;

            }


            .legend {

                gap:
                    10px;

            }


            .booking-detail strong {

                min-width:
                    100px;

            }


            .fc-toolbar {

                flex-wrap:
                    wrap;

                gap:
                    5px;

            }


            .fc-toolbar-title {

                font-size:
                    1.1rem;

            }


            /*
    |--------------------------------------------------------------------------
    | MOBILE - COMPACT DAY CELLS
    |--------------------------------------------------------------------------
    */

            #calendar .fc-daygrid-day-frame {

                min-height:
                    10px !important;

                height:
                    10px !important;

            }


            #calendar .fc-daygrid-day-number {

                padding:
                    3px !important;

                font-size:
                    10px;

            }


            #calendar .fc-event {

                padding:
                    2px 3px !important;

                margin:
                    1px 2px !important;

            }

        }
    </style>

</head>


<body>


    <!-- =============================================================
     MAIN CONTAINER
============================================================== -->

    <div class="container mt-5">


        <!-- =========================================================
         NAVBAR
    ========================================================== -->

        <?php include 'includes/navbar.php'; ?>


        <!-- =========================================================
         PAGE HEADER
    ========================================================== -->

        <div
            class="d-flex justify-content-between align-items-center booking-page-header">

            <div>

                <h4 class="mb-0">

                    <i class="bi bi-calendar-check"></i>

                    Manage Bookings

                </h4>


                <p class="text-muted mb-0">

                    View all resource bookings and their current status.

                </p>

            </div>

        </div>


        <!-- =========================================================
         CALENDAR
    ========================================================== -->

        <div class="calendar-container">


            <!-- =====================================================
             LEGEND
        ====================================================== -->

            <div class="legend">


                <div class="legend-item">

                    <span
                        class="legend-dot legend-pending"></span>

                    Pending

                </div>


                <div class="legend-item">

                    <span
                        class="legend-dot legend-approved"></span>

                    Approved

                </div>


                <div class="legend-item">

                    <span
                        class="legend-dot legend-rejected"></span>

                    Rejected

                </div>


                <div class="legend-item">

                    <span
                        class="legend-dot legend-cancelled"></span>

                    Cancelled

                </div>


                <div class="legend-item">

                    <span
                        class="legend-dot legend-other"></span>

                    Other

                </div>


            </div>


            <!-- =====================================================
             CALENDAR
        ====================================================== -->

            <div id="calendar"></div>


        </div>


        <br>


        <!-- =========================================================
         FOOTER
    ========================================================== -->

        <?php include 'includes/footer.php'; ?>


    </div>


    <!-- =============================================================
     BOOKING DETAILS MODAL
============================================================== -->



    <div class="modal fade" id="bookingModal" tabindex="-1" aria-labelledby="bookingModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="bookingModalLabel"><i class="bi bi-calendar-check"></i> Booking Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div id="modalPictureContainer" class="text-center mb-3">
                        <img id="modalResourcePicture" src="" alt="Resource picture" class="img-thumbnail booking-resource-picture" style="display:none; max-height:200px;">
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="booking-detail"><strong>Resource:</strong> <span id="modalResourceName"></span></div>
                        </div>
                        <div class="col-md-6">
                            <div class="booking-detail"><strong>Book Date:</strong> <span id="modalBookingDate"></span></div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="booking-detail"><strong>Start Time:</strong> <span id="modalStartTime"></span></div>
                        </div>
                        <div class="col-md-6">
                            <div class="booking-detail"><strong>End Time:</strong> <span id="modalEndTime"></span></div>
                        </div>
                    </div>

                    <div class="booking-detail"><strong>Purpose:</strong> <span id="modalPurpose"></span></div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="booking-detail"><strong>Status:</strong> <span id="modalStatus"></span></div>
                        </div>
                        <div class="col-md-6">
                            <div class="booking-detail"><strong>Booked By:</strong> <span id="modalBookedBy"></span></div>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>


    <!-- =============================================================
     JAVASCRIPT
============================================================== -->

    <script>
        /*
|--------------------------------------------------------------------------
| PHP → JAVASCRIPT
|--------------------------------------------------------------------------
*/

        const bookingEvents = <?= json_encode(
                                    $events,
                                    JSON_HEX_TAG |
                                        JSON_HEX_AMP |
                                        JSON_HEX_APOS |
                                        JSON_HEX_QUOT
                                ) ?>;


        /*
        |--------------------------------------------------------------------------
        | DEBUG
        |--------------------------------------------------------------------------
        */

        console.log(
            'FullCalendar bookings:',
            bookingEvents
        );


        /*
        |--------------------------------------------------------------------------
        | DOCUMENT READY
        |--------------------------------------------------------------------------
        */

        document.addEventListener(
            'DOMContentLoaded',
            function() {


                /*
                |--------------------------------------------------------------------------
                | CALENDAR ELEMENT
                |--------------------------------------------------------------------------
                */

                const calendarEl =
                    document.getElementById(
                        'calendar'
                    );


                if (!calendarEl) {

                    console.error(
                        'Calendar element not found.'
                    );

                    return;

                }


                /*
                |--------------------------------------------------------------------------
                | FULLCALENDAR CHECK
                |--------------------------------------------------------------------------
                */

                if (
                    typeof FullCalendar ===
                    'undefined'
                ) {

                    calendarEl.innerHTML = `

                <div class="alert alert-danger">

                    <strong>
                        FullCalendar is not loaded.
                    </strong>

                    <br>

                    Please check
                    assets/includes/header.php
                    and make sure FullCalendar
                    JavaScript is included.

                </div>

            `;

                    console.error(
                        'FullCalendar is not loaded.'
                    );

                    return;

                }


                /*
                |--------------------------------------------------------------------------
                | CREATE CALENDAR
                |--------------------------------------------------------------------------
                */

                const calendar =
                    new FullCalendar.Calendar(
                        calendarEl, {


                            /*
                            |--------------------------------------------------------------------------
                            | INITIAL VIEW
                            |--------------------------------------------------------------------------
                            */

                            initialView: 'dayGridMonth',


                            /*
                            |--------------------------------------------------------------------------
                            | HEIGHT
                            |--------------------------------------------------------------------------
                            */

                            height: 'auto',


                            /*
                            |--------------------------------------------------------------------------
                            | CURRENT TIME INDICATOR
                            |--------------------------------------------------------------------------
                            */

                            nowIndicator: true,


                            /*
                            |--------------------------------------------------------------------------
                            | NAVIGATION LINKS
                            |--------------------------------------------------------------------------
                            */

                            navLinks: true,


                            /*
                            |--------------------------------------------------------------------------
                            | HEADER TOOLBAR
                            |--------------------------------------------------------------------------
                            */

                            headerToolbar: {

                                left: 'prev,next today',

                                center: 'title',

                                right: 'dayGridMonth,timeGridWeek,timeGridDay'

                            },


                            /*
                            |--------------------------------------------------------------------------
                            | BUTTON TEXT
                            |--------------------------------------------------------------------------
                            */

                            buttonText: {

                                today: 'Today',

                                month: 'Month',

                                week: 'Week',

                                day: 'Day'

                            },


                            /*
                            |--------------------------------------------------------------------------
                            | EVENTS
                            |--------------------------------------------------------------------------
                            */

                            events: bookingEvents,


                            /*
                            |--------------------------------------------------------------------------
                            | EVENT CLASS
                            |--------------------------------------------------------------------------
                            */

                            eventClassNames: function(info) {


                                const status =
                                    String(
                                        info.event
                                        .extendedProps
                                        .status ||
                                        ''
                                    )
                                    .trim()
                                    .toLowerCase();


                                switch (status) {


                                    case 'pending':

                                        return [
                                            'booking-pending'
                                        ];


                                    case 'approved':

                                        return [
                                            'booking-approved'
                                        ];


                                    case 'rejected':

                                        return [
                                            'booking-rejected'
                                        ];


                                    case 'cancelled':

                                        return [
                                            'booking-cancelled'
                                        ];


                                    default:

                                        return [
                                            'booking-other'
                                        ];

                                }

                            },


                            /*
                            |--------------------------------------------------------------------------
                            | FORCE EVENT COLORS
                            |--------------------------------------------------------------------------
                            */

                            eventDidMount: function(info) {


                                const status =
                                    String(
                                        info.event
                                        .extendedProps
                                        .status ||
                                        ''
                                    )
                                    .trim()
                                    .toLowerCase();


                                let color =
                                    '#0d6efd';


                                switch (status) {


                                    case 'pending':

                                        color =
                                            '#f59e0b';

                                        break;


                                    case 'approved':

                                        color =
                                            '#198754';

                                        break;


                                    case 'rejected':

                                        color =
                                            '#dc3545';

                                        break;


                                    case 'cancelled':

                                        color =
                                            '#6c757d';

                                        break;


                                    default:

                                        color =
                                            '#0d6efd';

                                        break;

                                }


                                /*
                                |--------------------------------------------------------------------------
                                | BACKGROUND
                                |--------------------------------------------------------------------------
                                */

                                info.el.style.setProperty(
                                    'background-color',
                                    color,
                                    'important'
                                );


                                /*
                                |--------------------------------------------------------------------------
                                | BORDER
                                |--------------------------------------------------------------------------
                                */

                                info.el.style.setProperty(
                                    'border-color',
                                    color,
                                    'important'
                                );


                                /*
                                |--------------------------------------------------------------------------
                                | TEXT
                                |--------------------------------------------------------------------------
                                */

                                info.el.style.setProperty(
                                    'color',
                                    '#ffffff',
                                    'important'
                                );


                                /*
                                |--------------------------------------------------------------------------
                                | EVENT MAIN
                                |--------------------------------------------------------------------------
                                */

                                const eventMain =
                                    info.el.querySelector(
                                        '.fc-event-main'
                                    );


                                if (eventMain) {

                                    eventMain.style.setProperty(
                                        'color',
                                        '#ffffff',
                                        'important'
                                    );

                                }


                                /*
                                |--------------------------------------------------------------------------
                                | TITLE
                                |--------------------------------------------------------------------------
                                */

                                const title =
                                    info.el.querySelector(
                                        '.fc-event-title'
                                    );


                                if (title) {

                                    title.style.setProperty(
                                        'color',
                                        '#ffffff',
                                        'important'
                                    );

                                }


                                /*
                                |--------------------------------------------------------------------------
                                | TIME
                                |--------------------------------------------------------------------------
                                */

                                const time =
                                    info.el.querySelector(
                                        '.fc-event-time'
                                    );


                                if (time) {

                                    time.style.setProperty(
                                        'color',
                                        '#ffffff',
                                        'important'
                                    );

                                }


                                /*
                                |--------------------------------------------------------------------------
                                | REMOVE DOT
                                |--------------------------------------------------------------------------
                                */

                                const dot =
                                    info.el.querySelector(
                                        '.fc-daygrid-event-dot'
                                    );


                                if (dot) {

                                    dot.style.setProperty(
                                        'display',
                                        'none',
                                        'important'
                                    );

                                }

                            },


                            /*
                            |--------------------------------------------------------------------------
                            | EVENT CLICK
                            |--------------------------------------------------------------------------
                            */

                            eventClick: function(info) {


                                const event =
                                    info.event;


                                const props =
                                    event.extendedProps;


                                /*
                                |--------------------------------------------------------------------------
                                | BOOKED BY
                                |--------------------------------------------------------------------------
                                */

                                document.getElementById(
                                        'modalBookedBy'
                                    ).textContent =
                                    props.booked_by ||
                                    'Unknown Employee';


                                /*
                                |--------------------------------------------------------------------------
                                | RESOURCE
                                |--------------------------------------------------------------------------
                                */

                                document.getElementById(
                                        'modalResourceName'
                                    ).textContent =
                                    props.resource_name ||
                                    'Resource';


                                /*
                                |--------------------------------------------------------------------------
                                | DATE
                                |--------------------------------------------------------------------------
                                */

                                document.getElementById(
                                        'modalBookingDate'
                                    ).textContent =
                                    props.booking_date ||
                                    '';


                                /*
                                |--------------------------------------------------------------------------
                                | START TIME
                                |--------------------------------------------------------------------------
                                */

                                document.getElementById(
                                        'modalStartTime'
                                    ).textContent =
                                    props.start_time ||
                                    '';


                                /*
                                |--------------------------------------------------------------------------
                                | END TIME
                                |--------------------------------------------------------------------------
                                */

                                document.getElementById(
                                        'modalEndTime'
                                    ).textContent =
                                    props.end_time ||
                                    '';


                                /*
                                |--------------------------------------------------------------------------
                                | PURPOSE
                                |--------------------------------------------------------------------------
                                */

                                document.getElementById(
                                        'modalPurpose'
                                    ).textContent =
                                    props.purpose ||
                                    '';


                                /*
                                |--------------------------------------------------------------------------
                                | RESOURCE PICTURE
                                |--------------------------------------------------------------------------
                                */

                                const picture =
                                    String(
                                        props.picture ||
                                        ''
                                    ).trim();


                                const pictureElement =
                                    document.getElementById(
                                        'modalResourcePicture'
                                    );


                                if (
                                    picture !== ''
                                ) {


                                    pictureElement.src =
                                        'uploads/' +
                                        picture;


                                    pictureElement.alt =
                                        props.resource_name ?
                                        props.resource_name :
                                        'Resource picture';


                                    pictureElement.style.display =
                                        'block';


                                    pictureElement.onerror =
                                        function() {

                                            this.style.display =
                                                'none';

                                        };


                                } else {


                                    pictureElement.src =
                                        '';


                                    pictureElement.style.display =
                                        'none';

                                }


                                /*
                                |--------------------------------------------------------------------------
                                | STATUS
                                |--------------------------------------------------------------------------
                                */

                                const statusElement =
                                    document.getElementById(
                                        'modalStatus'
                                    );


                                const status =
                                    String(
                                        props.status ||
                                        ''
                                    )
                                    .trim()
                                    .toLowerCase();


                                /*
                                |--------------------------------------------------------------------------
                                | CLEAR OLD STATUS
                                |--------------------------------------------------------------------------
                                */

                                statusElement.classList.remove(

                                    'status-pending',

                                    'status-approved',

                                    'status-rejected',

                                    'status-cancelled',

                                    'status-other'

                                );


                                /*
                                |--------------------------------------------------------------------------
                                | APPLY STATUS
                                |--------------------------------------------------------------------------
                                */

                                switch (status) {


                                    case 'pending':

                                        statusElement.classList.add(
                                            'status-pending'
                                        );

                                        break;


                                    case 'approved':

                                        statusElement.classList.add(
                                            'status-approved'
                                        );

                                        break;


                                    case 'rejected':

                                        statusElement.classList.add(
                                            'status-rejected'
                                        );

                                        break;


                                    case 'cancelled':

                                        statusElement.classList.add(
                                            'status-cancelled'
                                        );

                                        break;


                                    default:

                                        statusElement.classList.add(
                                            'status-other'
                                        );

                                        break;

                                }


                                /*
                                |--------------------------------------------------------------------------
                                | DISPLAY STATUS
                                |--------------------------------------------------------------------------
                                */

                                statusElement.textContent =
                                    props.status ||
                                    'Unknown';


                                /*
                                |--------------------------------------------------------------------------
                                | MODAL HEADER COLOR
                                |--------------------------------------------------------------------------
                                */

                                const modalHeader =
                                    document.querySelector(
                                        '#bookingModal .modal-header'
                                    );


                                if (modalHeader) {

                                    modalHeader.style.borderTopColor =
                                        event.backgroundColor ||
                                        '#0d6efd';

                                }


                                /*
                                |--------------------------------------------------------------------------
                                | OPEN MODAL
                                |--------------------------------------------------------------------------
                                */

                                const modalElement =
                                    document.getElementById(
                                        'bookingModal'
                                    );


                                if (
                                    typeof bootstrap !==
                                    'undefined' &&
                                    modalElement
                                ) {


                                    const modal =
                                        bootstrap.Modal.getOrCreateInstance(
                                            modalElement, {
                                                backdrop: true,
                                                keyboard: true,
                                                focus: true
                                            }
                                        );


                                    modal.show();

                                }

                            }

                        }
                    );


                /*
                |--------------------------------------------------------------------------
                | RENDER CALENDAR
                |--------------------------------------------------------------------------
                */

                calendar.render();

            }
        );
    </script>


</body>

</html>