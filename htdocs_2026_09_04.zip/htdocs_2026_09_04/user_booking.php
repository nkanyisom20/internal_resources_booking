<?php

require 'config/db.php';


/*
|--------------------------------------------------------------------------
| Session
|--------------------------------------------------------------------------
*/

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}


/*
|--------------------------------------------------------------------------
| Check if user is logged in
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user'])) {

    header("Location: login.php");
    exit;
}


/*
|--------------------------------------------------------------------------
| Timezone
|--------------------------------------------------------------------------
*/

date_default_timezone_set('Africa/Johannesburg');


/*
|--------------------------------------------------------------------------
| Current user
|--------------------------------------------------------------------------
*/

$user_id =
    $_SESSION['user']['employee_id'];


/*
|--------------------------------------------------------------------------
| Fetch bookings
|--------------------------------------------------------------------------
*/

$stmt = $connect->prepare("
    SELECT
        b.*,
        r.resource_name
    FROM bookings b
    JOIN resources r
        ON b.resource_id = r.resource_id
    WHERE b.user_id = ?
    ORDER BY b.booking_date ASC
");

$stmt->execute([
    $user_id
]);


$bookings =
    $stmt->fetchAll(
        PDO::FETCH_ASSOC
    );

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <title>
        Resource Booking : Nkanyiso Consulting
    </title>


    <meta charset="utf-8">


    <meta
        name="viewport"
        content="width=device-width, initial-scale=1">


    <?php
    include 'includes/header.php';
    ?>

</head>


<body>


    <div class="container mt-5">


        <!-- =========================================================
         NAVBAR
    ========================================================== -->

        <?php
        include 'includes/navbar.php';
        ?>


        <!-- =========================================================
         PAGE HEADING
    ========================================================== -->

        <div
            class="d-flex justify-content-between align-items-center mb-3 add-resource">

            <h4 class="mb-0">

                <i class="bi bi-calendar-check"></i>

                Manage Bookings

            </h4>


            <a
                href="resources.php"
                class="btn btn-success">

                <i class="bi bi-calendar-plus"></i>

                Add Booking

            </a>

        </div>


        <!-- =========================================================
         BOOKINGS
    ========================================================== -->

        <?php if (empty($bookings)): ?>


            <div class="card shadow-sm">

                <div class="card-body">

                    <div class="alert alert-info mb-0">

                        You haven't made any bookings yet.

                    </div>

                </div>

            </div>


        <?php else: ?>


            <!-- =====================================================
             WHITE CARD
        ====================================================== -->

            <div class="card shadow-sm">

                <div class="card-body">


                    <!-- =================================================
                     TABLE
                ================================================== -->

                    <div class="table-responsive">

                        <table
                            class="table table-bordered table-striped table-hover align-middle"
                            id="lftable"
                            style="width:100%;">


                            <!-- =================================================
                             COLUMN WIDTHS
                        ================================================== -->

                            <colgroup>

                                <col width="4%">

                                <col width="18%">

                                <col width="10%">

                                <col width="10%">

                                <col width="28%">

                                <col width="10%">

                                <col width="10%">

                            </colgroup>


                            <!-- =================================================
                             TABLE HEADER
                        ================================================== -->

                            <thead class="table-dark">

                                <tr>

                                    <th>
                                        No.
                                    </th>


                                    <th>
                                        Resource Name
                                    </th>


                                    <th>
                                        Date
                                    </th>


                                    <th>
                                        Time
                                    </th>


                                    <th>
                                        Purpose
                                    </th>


                                    <th>
                                        Status
                                    </th>


                                    <th>
                                        Actions
                                    </th>

                                </tr>

                            </thead>


                            <!-- =================================================
                             TABLE BODY
                        ================================================== -->

                            <tbody>


                                <?php

                                $count = 1;

                                foreach (
                                    $bookings
                                    as $b
                                ):

                                ?>


                                    <tr>


                                        <!-- =========================================
                                     NUMBER
                                ========================================== -->

                                        <td>

                                            <strong>

                                                <?= $count++ ?>

                                            </strong>

                                        </td>


                                        <!-- =========================================
                                     RESOURCE
                                ========================================== -->

                                        <td>

                                            <?= htmlspecialchars(
                                                $b['resource_name'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>

                                        </td>


                                        <!-- =========================================
                                     DATE
                                ========================================== -->

                                        <td>

                                            <?= date(
                                                'Y-m-d',
                                                strtotime(
                                                    $b['booking_date']
                                                )
                                            ) ?>

                                        </td>


                                        <!-- =========================================
                                     TIME
                                ========================================== -->

                                        <td>

                                            <?= date(
                                                'H:i',
                                                strtotime(
                                                    $b['start_time']
                                                )
                                            ) ?>

                                            -

                                            <?= date(
                                                'H:i',
                                                strtotime(
                                                    $b['end_time']
                                                )
                                            ) ?>

                                        </td>


                                        <!-- =========================================
                                     PURPOSE
                                ========================================== -->

                                        <td>

                                            <?= htmlspecialchars(
                                                $b['purpose'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>

                                        </td>


                                        <!-- =========================================
                                     STATUS
                                ========================================== -->

                                        <td>


                                            <?php

                                            $status =
                                                strtolower(
                                                    $b['status']
                                                );


                                            $statusText =
                                                ucfirst(
                                                    $status
                                                );


                                            switch ($status) {

                                                case 'pending':

                                                    $badge =
                                                        'warning';

                                                    break;


                                                case 'approved':

                                                    $badge =
                                                        'success';

                                                    break;


                                                case 'rejected':

                                                    $badge =
                                                        'danger';

                                                    break;


                                                case 'cancelled':

                                                    $badge =
                                                        'secondary';

                                                    break;


                                                default:

                                                    $badge =
                                                        'dark';

                                                    break;
                                            }

                                            ?>


                                            <span
                                                class="badge bg-<?= $badge ?>">

                                                <?= htmlspecialchars(
                                                    $statusText,
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>

                                            </span>


                                        </td>


                                        <!-- =========================================
                                     ACTIONS
                                ========================================== -->

                                        <td
                                            class="text-nowrap">


                                            <?php

                                            $canCancel =
                                                in_array(
                                                    $status,
                                                    [
                                                        'pending',
                                                        'approved'
                                                    ],
                                                    true
                                                );


                                            $canEdit =
                                                $status === 'pending';

                                            ?>


                                            <!-- =====================================
                                         CANCEL
                                    ====================================== -->

                                            <?php if ($canCancel): ?>


                                                <form
                                                    action="actions/cancel_booking.php"
                                                    method="post"
                                                    class="d-inline"
                                                    onsubmit="return confirm('Cancel this booking?')">


                                                    <input
                                                        type="hidden"
                                                        name="booking_id"
                                                        value="<?= htmlspecialchars(
                                                                    $b['booking_id'],
                                                                    ENT_QUOTES,
                                                                    'UTF-8'
                                                                ) ?>">


                                                    <button
                                                        type="submit"
                                                        class="btn btn-warning btn-sm"
                                                        title="Cancel booking">

                                                        <i
                                                            class="bi bi-x"></i>

                                                    </button>


                                                </form>


                                            <?php else: ?>


                                                <button
                                                    type="button"
                                                    class="btn btn-secondary btn-sm"
                                                    disabled
                                                    title="No action available">

                                                    <i
                                                        class="bi bi-x"></i>

                                                </button>


                                            <?php endif; ?>


                                            <!-- =====================================
                                         DELETE / EDIT
                                    ====================================== -->

                                            <?php if ($canEdit): ?>


                                                <form
                                                    action="#"
                                                    method="post"
                                                    class="d-inline"
                                                    onsubmit="return confirm('Save this booking update?')">


                                                    <input
                                                        type="hidden"
                                                        name="booking_id"
                                                        value="<?= htmlspecialchars(
                                                                    $b['booking_id'],
                                                                    ENT_QUOTES,
                                                                    'UTF-8'
                                                                ) ?>">


                                                    <button
                                                        type="submit"
                                                        class="btn btn-danger btn-sm"
                                                        title="Delete booking">

                                                        <i
                                                            class="bi bi-trash"></i>

                                                    </button>


                                                </form>


                                            <?php endif; ?>


                                        </td>


                                    </tr>


                                <?php endforeach; ?>


                            </tbody>


                        </table>


                    </div>


                </div>

            </div>


        <?php endif; ?>


        <br>


        <!-- ============================================================
         FOOTER
    ============================================================ -->

        <div class="site-footer">

            <?php
            include 'includes/footer.php';
            ?>

        </div>


    </div>



    <!-- ============================================================
     VIEW MODAL
============================================================ -->

    <div
        class="modal fade"
        id="viewModal"
        tabindex="-1"
        aria-labelledby="viewModalLabel"
        aria-hidden="true">


        <div class="modal-dialog">


            <form
                method="post"
                action="handle_booking.php">


                <input
                    type="hidden"
                    name="booking_id"
                    value="">


                <div class="modal-content">


                    <!-- =================================================
                     MODAL HEADER
                ================================================== -->

                    <div class="modal-header">


                        <h5
                            class="modal-title"
                            id="viewModalLabel">

                        </h5>


                        <button
                            type="button"
                            class="btn-close"
                            data-bs-dismiss="modal"
                            aria-label="Close"></button>


                    </div>


                    <!-- =================================================
                     MODAL BODY
                ================================================== -->

                    <div class="modal-body">


                        <div
                            class="tab-content pt-3"
                            id="modalTabsContent">


                            <!-- =============================================
                             BOOKING TAB
                        ============================================== -->

                            <div
                                class="tab-pane fade"
                                id="book"
                                role="tabpanel">


                                <!-- =========================================
                                 DATE
                            ========================================== -->

                                <div class="mb-3">


                                    <label
                                        class="form-label">

                                        Booking Date

                                    </label>


                                    <input
                                        type="date"
                                        name="booking_date"
                                        class="form-control"
                                        min="<?= date('Y-m-d') ?>"
                                        required>


                                </div>


                                <!-- =========================================
                                 START TIME
                            ========================================== -->

                                <div class="mb-3">


                                    <label
                                        class="form-label">

                                        Starting Time

                                    </label>


                                    <input
                                        type="time"
                                        name="start_time"
                                        id="start_time"
                                        class="form-control"
                                        required>


                                </div>


                                <!-- =========================================
                                 END TIME
                            ========================================== -->

                                <div class="mb-3">


                                    <label
                                        class="form-label">

                                        Ending Time

                                    </label>


                                    <input
                                        type="time"
                                        name="end_time"
                                        id="end_time"
                                        class="form-control"
                                        disabled
                                        required>


                                </div>


                                <!-- =========================================
                                 PURPOSE
                            ========================================== -->

                                <div class="mb-3">


                                    <label
                                        class="form-label">

                                        Purpose

                                    </label>


                                    <textarea
                                        name="purpose"
                                        id="purpose"
                                        class="form-control"
                                        rows="3"
                                        cols="30"
                                        placeholder="We will be hosting our..."
                                        required></textarea>


                                </div>


                            </div>


                        </div>


                    </div>


                    <!-- =================================================
                     MODAL FOOTER
                ================================================== -->

                    <div class="modal-footer">


                        <button
                            type="submit"
                            class="btn btn-primary">

                            Submit Booking

                        </button>


                        <button
                            type="button"
                            class="btn btn-secondary"
                            data-bs-dismiss="modal">

                            Close

                        </button>


                    </div>


                </div>


            </form>


        </div>


    </div>



    <!-- ============================================================
     DATATABLE JAVASCRIPT
============================================================ -->

    <script>
        $(document).ready(function() {


            /*
            |--------------------------------------------------------------------------
            | DataTable
            |--------------------------------------------------------------------------
            |
            | 2 bookings per page.
            |
            | lengthChange: false
            | removes "Show 2 entries".
            |
            | dom: 'rtip'
            | keeps:
            |
            | r = processing
            | t = table
            | i = information
            | p = pagination
            |
            | The search box is automatically displayed by DataTables.
            |
            */

            $('#lftable').DataTable({

                /*
                |--------------------------------------------------------------------------
                | Two records per page
                |--------------------------------------------------------------------------
                */

                pageLength: 10,


                /*
                |--------------------------------------------------------------------------
                | Remove "Show entries"
                |--------------------------------------------------------------------------
                */

                lengthChange: false,


                /*
                |--------------------------------------------------------------------------
                | Disable ordering
                |--------------------------------------------------------------------------
                */

                ordering: false,


                /*
                |--------------------------------------------------------------------------
                | Enable search
                |--------------------------------------------------------------------------
                */

                searching: true,


                /*
                |--------------------------------------------------------------------------
                | Enable pagination
                |--------------------------------------------------------------------------
                */

                paging: true,


                /*
                |--------------------------------------------------------------------------
                | Full pagination
                |--------------------------------------------------------------------------
                */

                pagingType: 'full_numbers',


                /*
                |--------------------------------------------------------------------------
                | Show information
                |--------------------------------------------------------------------------
                */

                info: true,


                /*
                |--------------------------------------------------------------------------
                | DataTables layout
                |--------------------------------------------------------------------------
                */

                dom: 'frtip',


                /*
                |--------------------------------------------------------------------------
                | Language
                |--------------------------------------------------------------------------
                */

                language: {

                    search: 'Search:',

                    zeroRecords: 'No matching records found.',

                    emptyTable: 'No bookings found.',

                    info: 'Showing _START_ to _END_ of _TOTAL_ bookings',

                    infoEmpty: 'Showing 0 to 0 of 0 bookings',

                    paginate: {

                        first: '«',

                        previous: '‹',

                        next: '›',

                        last: '»'

                    }

                },


                /*
                |--------------------------------------------------------------------------
                | Actions column
                |--------------------------------------------------------------------------
                */

                columnDefs: [

                    {
                        orderable: false,
                        targets: 6
                    }

                ]

            });


        });
    </script>



</body>

</html>