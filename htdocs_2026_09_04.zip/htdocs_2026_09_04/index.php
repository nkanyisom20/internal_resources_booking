 <?php
    require 'config/db.php';
    if (!isset($_SESSION['user'])) {
        header("location: login.php");
        exit;
    }
    ?>
 <?php
    $resources = $connect->query("SELECT * FROM resources ORDER BY resource_id DESC LIMIT 3")->fetchAll();
    ?>
 <!DOCTYPE html>
 <html>

 <head>
     <title>Resource Booking : Nkanyiso Consulting</title>
     <meta charset="utf-8">
     <?php include 'includes/header.php' ?>

 </head>

 <body>
     <div class="container mt-5">
         <?php include 'includes/navbar.php'; ?>
         <div class="wrapper">

             <!-- Content -->
             <div class="main-content">
                 <!-- Cards -->
                 <div class="container-fluid mt-4">
                     <div class="row">
                         <div class="col-md-3">
                             <div class="card stat-card">
                                 <div class="card-body">
                                     <i class="fas fa-users"></i>
                                     <h3>15</h3>
                                     <p>Total Resources </p>
                                 </div>
                             </div>
                         </div>

                         <div class="col-md-3">
                             <div class="card stat-card">
                                 <div class="card-body">
                                     <i class="fas fa-box"></i>
                                     <h3>12</h3>
                                     <p>Active Resources</p>
                                 </div>
                             </div>
                         </div>

                         <div class="col-md-3">
                             <div class="card stat-card">
                                 <div class="card-body">
                                     <i class="fas fa-shopping-cart"></i>
                                     <h3>3</h3>
                                     <p>Inactive Resources</p>
                                 </div>
                             </div>
                         </div>

                         <div class="col-md-3">
                             <div class="card stat-card">
                                 <div class="card-body">
                                     <i class="fas fa-money-bill"></i>
                                     <h3>22</h3>
                                     <p>Employees</p>
                                 </div>
                             </div>
                         </div>
                     </div>

                     <!-- Recent Invoices -->
                     <div class="card mt-3">
                         <div class="card-header">
                             Recent Added Resources
                         </div>

                         <div class="card-body">
                             <div class="table-responsive">
                                 <table
                                     id="resources_table"
                                     class="table table-bordered table-striped table-hover align-middle"
                                     style="width:100%;">
                                     <thead>
                                         <tr>
                                             <th>No.</th>
                                             <th>Resource Name</th>
                                             <th>Description</th>
                                             <th>Location</th>
                                             <th>Capacity</th>
                                             <th>Status</th>
                                         </tr>
                                     </thead>

                                     <tbody>
                                         <?php
                                            $count = 1;
                                            foreach ($resources as $res): ?>

                                             <tr>
                                                 <td><b><?php echo $count++; ?></b></td>
                                                 <td><?= htmlspecialchars($res['resource_name']) ?></td>
                                                 <td><?= htmlspecialchars(substr($res['description'], 0, 50)) ?>...</td>
                                                 <td><?= htmlspecialchars($res['location']) ?></td>
                                                 <td><?= htmlspecialchars($res['capacity']) ?></td>
                                                 <td>
                                                     <span class="badge bg-<?= match ($res['status']) {
                                                                                'Active' => 'success',
                                                                                'Inactive' => 'secondary'
                                                                            } ?>">
                                                         <?= ucfirst($res['status']) ?>
                                                     </span>
                                                 </td>

                                             </tr>
                                         <?php endforeach; ?>
                                     </tbody>
                                 </table>
                             </div>
                         </div>
                     </div>
                     <br>
                 </div>
             </div>
         </div>
         <!-- Bootstrap 5.3 JS + Popper (required for dropdowns to work) -->
         <?php include 'includes/footer.php'; ?>
     </div>
 </body>

 </html>